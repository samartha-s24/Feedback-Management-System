import React from 'react';
import { AdminNotification } from '../types';
import { Bell, X, AlertTriangle, CheckCircle2, Info, CheckCheck } from 'lucide-react';

interface NotificationsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AdminNotification[];
  onMarkAllRead: () => void;
}

export const NotificationsDrawer: React.FC<NotificationsDrawerProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex justify-end animate-in fade-in">
      <div className="w-full max-w-sm bg-zinc-900 border-l border-zinc-800 h-full p-4 space-y-4 flex flex-col justify-between overflow-hidden">
        
        {/* Header */}
        <div className="space-y-2">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-orange-400" />
              <h3 className="text-sm font-bold text-white">System Notifications</h3>
            </div>
            <button onClick={onClose} className="p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-400">{notifications.filter(n => !n.read).length} Unread Alerts</span>
            <button
              onClick={onMarkAllRead}
              className="text-orange-400 hover:underline flex items-center gap-1 font-semibold"
            >
              <CheckCheck className="w-3.5 h-3.5" /> Mark all read
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {notifications.map((n) => (
            <div
              key={n.id}
              className={`p-3 rounded-2xl border text-xs space-y-1 transition-all ${
                n.read
                  ? 'bg-zinc-950/40 border-zinc-800/60 opacity-70'
                  : 'bg-zinc-950 border-orange-500/30 shadow-md'
              }`}
            >
              <div className="flex items-start justify-between gap-1">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  {n.type === 'urgent' && <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />}
                  {n.type === 'success' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                  {n.type === 'info' && <Info className="w-3.5 h-3.5 text-cyan-400" />}
                  <span className="leading-snug">{n.title}</span>
                </div>
                {!n.read && <span className="w-2 h-2 rounded-full bg-orange-500 flex-shrink-0 mt-1" />}
              </div>

              <p className="text-zinc-400 leading-relaxed text-[11px]">{n.message}</p>
              <span className="text-[10px] font-mono text-zinc-500 block pt-0.5">{n.time}</span>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-zinc-800">
          <button
            onClick={onClose}
            className="w-full py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs"
          >
            Close Panel
          </button>
        </div>

      </div>
    </div>
  );
};
