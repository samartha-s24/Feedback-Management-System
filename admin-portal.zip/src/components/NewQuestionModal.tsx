import React, { useState } from 'react';
import { QuestionItem, QuestionCategory } from '../types';
import { HelpCircle, X, Check } from 'lucide-react';

interface NewQuestionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateQuestion: (question: QuestionItem) => void;
}

export const NewQuestionModal: React.FC<NewQuestionModalProps> = ({
  isOpen,
  onClose,
  onCreateQuestion,
}) => {
  const [text, setText] = useState('');
  const [category, setCategory] = useState<QuestionCategory>('Faculty & Teaching');
  const [type, setType] = useState<'rating' | 'multiple_choice' | 'text_feedback'>('rating');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;

    const newQ: QuestionItem = {
      id: `QST-${Date.now().toString().slice(-4)}`,
      text,
      category,
      type,
      usageCount: 1,
      addedBy: 'Dr. A. Sharma (Dean)',
    };

    onCreateQuestion(newQ);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Add Question to Repository</h3>
              <p className="text-xs text-zinc-400">Vetted question for feedback forms</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold text-zinc-300 mb-1">Question Text</label>
            <textarea
              required
              rows={3}
              placeholder="e.g. How effectively does the lab instructor assist in practical code debugging?"
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as QuestionCategory)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="Faculty & Teaching">Faculty & Teaching</option>
                <option value="Curriculum & Syllabus">Curriculum & Syllabus</option>
                <option value="Campus & Infrastructure">Campus & Infrastructure</option>
                <option value="Labs & Equipment">Labs & Equipment</option>
                <option value="Hostel & Canteen">Hostel & Canteen</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Response Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as 'rating' | 'multiple_choice' | 'text_feedback')}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="rating">1-5 Rating Scale</option>
                <option value="text_feedback">Text Feedback</option>
                <option value="multiple_choice">Multiple Choice</option>
              </select>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-2 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-zinc-800 text-zinc-300 font-semibold hover:bg-zinc-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-zinc-950 font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-500/20"
            >
              <Check className="w-4 h-4" />
              Save Question
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
