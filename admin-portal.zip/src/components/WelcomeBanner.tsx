import React from 'react';
import { BookOpen, Sparkles } from 'lucide-react';

interface WelcomeBannerProps {
  userName?: string;
}

export const WelcomeBanner: React.FC<WelcomeBannerProps> = ({ userName = "Diego Alonso" }) => {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-[#6366f1] text-white p-6 sm:p-8 shadow-xl shadow-indigo-500/20 my-2">
      {/* Background soft glow accent */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full blur-2xl pointer-events-none" />

      <div className="relative flex items-center gap-4 sm:gap-6 z-10">
        
        {/* Book / Icon in translucent box matching Image 1 */}
        <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center text-white flex-shrink-0 shadow-inner">
          <BookOpen className="w-7 h-7 sm:w-8 sm:h-8" />
        </div>

        {/* Text Content */}
        <div className="space-y-1">
          <h2 className="text-xl sm:text-2xl font-black tracking-tight leading-snug">
            Welcome back, {userName}!
          </h2>
          <p className="text-xs sm:text-sm font-medium text-indigo-100 leading-relaxed max-w-xl">
            Your experience and feedback help us improve our college ecosystem.
          </p>
        </div>

      </div>
    </div>
  );
};
