import React, { useState } from 'react';
import { FeedbackSession } from '../types';
import { Radio, X, Check } from 'lucide-react';

interface NewSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateSession: (session: FeedbackSession) => void;
}

export const NewSessionModal: React.FC<NewSessionModalProps> = ({
  isOpen,
  onClose,
  onCreateSession,
}) => {
  const [title, setTitle] = useState('');
  const [department, setDepartment] = useState('Computer Science & AI');
  const [targetAudience, setTargetAudience] = useState('3rd Year B.Tech');
  const [totalTarget, setTotalTarget] = useState(500);
  const [deadline, setDeadline] = useState('2026-08-10');
  const [questionsCount, setQuestionsCount] = useState(10);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newSession: FeedbackSession = {
      id: `SES-${Date.now().toString().slice(-4)}`,
      title,
      department,
      targetAudience,
      responsesCount: 0,
      totalTarget: Number(totalTarget),
      averageRating: 0,
      positivePercent: 0,
      deadline,
      status: 'active',
      questionsCount: Number(questionsCount),
      createdAt: new Date().toISOString().split('T')[0],
    };

    onCreateSession(newSession);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400">
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">New Feedback Session</h3>
              <p className="text-xs text-zinc-400">Launch a new course evaluation questionnaire</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold text-zinc-300 mb-1">Session Title</label>
            <input
              type="text"
              required
              placeholder="e.g. End-Sem Course Feedback (ECE 2026)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Department</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              >
                <option>Computer Science & AI</option>
                <option>Electronics & Comm.</option>
                <option>Electrical Engineering</option>
                <option>Mechanical & Robotics</option>
                <option>Civil Engineering</option>
                <option>Campus Infrastructure</option>
                <option>Library & Learning Resources</option>
                <option>Student Affairs & Hostel</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Target Batches</label>
              <input
                type="text"
                required
                value={targetAudience}
                onChange={(e) => setTargetAudience(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Target Count</label>
              <input
                type="number"
                required
                min={10}
                value={totalTarget}
                onChange={(e) => setTotalTarget(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Questions</label>
              <input
                type="number"
                required
                min={1}
                max={30}
                value={questionsCount}
                onChange={(e) => setQuestionsCount(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Deadline</label>
              <input
                type="date"
                required
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-2 py-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-2 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-zinc-800 text-zinc-300 font-semibold hover:bg-zinc-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-zinc-950 font-bold flex items-center gap-1.5 shadow-lg shadow-orange-500/20"
            >
              <Check className="w-4 h-4" />
              Launch Session
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
