import { AccentTheme } from '../types';

export const getAccentClasses = (theme: AccentTheme) => {
  switch (theme) {
    case 'teal':
      return {
        bgGradient: 'bg-gradient-to-r from-teal-500 via-teal-600 to-cyan-600',
        badgeBg: 'bg-teal-500/15 text-teal-400 border border-teal-500/20',
        textAccent: 'text-teal-400',
        btnBg: 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 hover:brightness-110',
        ringColor: '#14b8a6',
        activeTabBg: 'bg-teal-500/20 text-teal-300 border-t-2 border-teal-400',
        primaryBtn: 'bg-gradient-to-r from-teal-400 to-teal-600 text-slate-950 font-bold hover:brightness-110 shadow-lg shadow-teal-500/20',
        hexColor: '#14b8a6',
      };
    case 'emerald':
      return {
        bgGradient: 'bg-gradient-to-r from-emerald-500 via-emerald-600 to-teal-600',
        badgeBg: 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20',
        textAccent: 'text-emerald-400',
        btnBg: 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:brightness-110',
        ringColor: '#10b981',
        activeTabBg: 'bg-emerald-500/20 text-emerald-300 border-t-2 border-emerald-400',
        primaryBtn: 'bg-gradient-to-r from-emerald-400 to-emerald-600 text-slate-950 font-bold hover:brightness-110 shadow-lg shadow-emerald-500/20',
        hexColor: '#10b981',
      };
    case 'rose':
      return {
        bgGradient: 'bg-gradient-to-r from-rose-500 via-rose-600 to-pink-600',
        badgeBg: 'bg-rose-500/15 text-rose-400 border border-rose-500/20',
        textAccent: 'text-rose-400',
        btnBg: 'bg-gradient-to-r from-rose-500 to-pink-500 text-white hover:brightness-110',
        ringColor: '#f43f5e',
        activeTabBg: 'bg-rose-500/20 text-rose-300 border-t-2 border-rose-400',
        primaryBtn: 'bg-gradient-to-r from-rose-500 to-pink-600 text-white font-bold hover:brightness-110 shadow-lg shadow-rose-500/20',
        hexColor: '#f43f5e',
      };
    case 'purple':
      return {
        bgGradient: 'bg-gradient-to-r from-purple-500 via-purple-600 to-indigo-600',
        badgeBg: 'bg-purple-500/15 text-purple-400 border border-purple-500/20',
        textAccent: 'text-purple-400',
        btnBg: 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:brightness-110',
        ringColor: '#8b5cf6',
        activeTabBg: 'bg-purple-500/20 text-purple-300 border-t-2 border-purple-400',
        primaryBtn: 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold hover:brightness-110 shadow-lg shadow-purple-500/20',
        hexColor: '#8b5cf6',
      };
    case 'blue':
    default:
      return {
        bgGradient: 'bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600',
        badgeBg: 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/20',
        textAccent: 'text-cyan-400',
        btnBg: 'bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 hover:brightness-110',
        ringColor: '#22c55e', // default green metric
        activeTabBg: 'bg-cyan-500/20 text-cyan-300 border-t-2 border-cyan-400',
        primaryBtn: 'bg-gradient-to-r from-cyan-400 via-sky-500 to-blue-600 text-slate-950 font-bold hover:brightness-110 shadow-lg shadow-cyan-500/20',
        hexColor: '#2f7de1',
      };
  }
};
