import React from 'react';
import { usePortal } from '../context/PortalContext';
import { getAccentClasses } from '../utils/theme';
import { CheckCircle2, Eye, Calendar, FileText } from 'lucide-react';

export const HistoryView: React.FC = () => {
  const { submissions, openViewSubmissionModal, accentTheme } = usePortal();
  const accent = getAccentClasses(accentTheme);

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Header */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 shadow-sm">
        <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span>Submission History</span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Archived log of all feedback submitted for your child's academic institution.
        </p>
      </div>

      {submissions.length === 0 ? (
        <div className="p-8 rounded-2xl bg-slate-900/80 border border-slate-800 text-center space-y-3 shadow-md">
          <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-500 flex items-center justify-center mx-auto text-2xl">
            📋
          </div>
          <p className="text-sm font-bold text-slate-200">No Submissions Yet</p>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            Forms you complete will appear here with detailed responses and timestamps.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {[...submissions].reverse().map((sub) => (
            <div
              key={sub.id}
              className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3 shadow-md"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-slate-100">{sub.title}</h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Parent: <span className="text-slate-200">{sub.parentName}</span> · Ward: <span className="text-slate-200">{sub.studentName}</span>
                  </p>
                </div>
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-bold border border-emerald-500/20 shrink-0">
                  {sub.status}
                </span>
              </div>

              <div className="flex items-center justify-between text-[11px] p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{sub.date}, {sub.time}</span>
                </div>

                <button
                  onClick={() => openViewSubmissionModal(sub.id)}
                  className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 font-bold text-xs flex items-center gap-1 transition-colors active:scale-95"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>View Responses</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
