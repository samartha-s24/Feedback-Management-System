import React from 'react';
import { 
  Radio, 
  MessageSquareText, 
  Star, 
  Smile, 
  FileText, 
  Archive, 
  HelpCircle, 
  Megaphone,
  TrendingUp,
  ChevronRight
} from 'lucide-react';
import { MetricCardData } from '../types';

interface StatCardProps {
  data: MetricCardData;
  onClick?: () => void;
  isActive?: boolean;
}

export const StatCard: React.FC<StatCardProps> = ({ data, onClick, isActive }) => {
  // Color configuration map for dark theme neon style
  const colorMap = {
    orange: {
      border: 'hover:border-orange-500/50',
      activeBorder: 'border-orange-500 ring-1 ring-orange-500/30',
      bgGlow: 'from-orange-500/10 via-orange-500/5 to-transparent',
      iconBg: 'bg-orange-500/15 border-orange-500/30 text-orange-400',
      textAccent: 'text-orange-400',
      badgeBg: 'bg-orange-500/10 text-orange-300',
    },
    cyan: {
      border: 'hover:border-cyan-500/50',
      activeBorder: 'border-cyan-500 ring-1 ring-cyan-500/30',
      bgGlow: 'from-cyan-500/10 via-cyan-500/5 to-transparent',
      iconBg: 'bg-cyan-500/15 border-cyan-500/30 text-cyan-400',
      textAccent: 'text-cyan-400',
      badgeBg: 'bg-cyan-500/10 text-cyan-300',
    },
    purple: {
      border: 'hover:border-purple-500/50',
      activeBorder: 'border-purple-500 ring-1 ring-purple-500/30',
      bgGlow: 'from-purple-500/10 via-purple-500/5 to-transparent',
      iconBg: 'bg-purple-500/15 border-purple-500/30 text-purple-400',
      textAccent: 'text-purple-400',
      badgeBg: 'bg-purple-500/10 text-purple-300',
    },
    green: {
      border: 'hover:border-emerald-500/50',
      activeBorder: 'border-emerald-500 ring-1 ring-emerald-500/30',
      bgGlow: 'from-emerald-500/10 via-emerald-500/5 to-transparent',
      iconBg: 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400',
      textAccent: 'text-emerald-400',
      badgeBg: 'bg-emerald-500/10 text-emerald-300',
    },
    yellow: {
      border: 'hover:border-amber-500/50',
      activeBorder: 'border-amber-500 ring-1 ring-amber-500/30',
      bgGlow: 'from-amber-500/10 via-amber-500/5 to-transparent',
      iconBg: 'bg-amber-500/15 border-amber-500/30 text-amber-400',
      textAccent: 'text-amber-400',
      badgeBg: 'bg-amber-500/10 text-amber-300',
    },
    red: {
      border: 'hover:border-rose-500/50',
      activeBorder: 'border-rose-500 ring-1 ring-rose-500/30',
      bgGlow: 'from-rose-500/10 via-rose-500/5 to-transparent',
      iconBg: 'bg-rose-500/15 border-rose-500/30 text-rose-400',
      textAccent: 'text-rose-400',
      badgeBg: 'bg-rose-500/10 text-rose-300',
    },
    blue: {
      border: 'hover:border-blue-500/50',
      activeBorder: 'border-blue-500 ring-1 ring-blue-500/30',
      bgGlow: 'from-blue-500/10 via-blue-500/5 to-transparent',
      iconBg: 'bg-blue-500/15 border-blue-500/30 text-blue-400',
      textAccent: 'text-blue-400',
      badgeBg: 'bg-blue-500/10 text-blue-300',
    },
    emerald: {
      border: 'hover:border-emerald-500/50',
      activeBorder: 'border-emerald-500 ring-1 ring-emerald-500/30',
      bgGlow: 'from-emerald-500/10 via-emerald-500/5 to-transparent',
      iconBg: 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400',
      textAccent: 'text-emerald-400',
      badgeBg: 'bg-emerald-500/10 text-emerald-300',
    },
  };

  const currentTheme = colorMap[data.color] || colorMap.orange;

  const renderIcon = () => {
    const iconProps = { className: "w-4 h-4" };
    switch (data.icon) {
      case 'Radio': return <Radio {...iconProps} />;
      case 'MessageSquareCheck':
      case 'MessageSquareText': return <MessageSquareText {...iconProps} />;
      case 'Star': return <Star {...iconProps} />;
      case 'Smile': return <Smile {...iconProps} />;
      case 'FileText': return <FileText {...iconProps} />;
      case 'Archive': return <Archive {...iconProps} />;
      case 'HelpCircle': return <HelpCircle {...iconProps} />;
      case 'Megaphone': return <Megaphone {...iconProps} />;
      default: return <Radio {...iconProps} />;
    }
  };

  return (
    <div
      onClick={onClick}
      className={`relative group cursor-pointer overflow-hidden rounded-2xl bg-zinc-900/90 border border-zinc-800/90 p-3.5 transition-all duration-200 active:scale-[0.98] ${
        isActive ? currentTheme.activeBorder : currentTheme.border
      }`}
    >
      {/* Subtle top background glow overlay */}
      <div className={`absolute inset-x-0 top-0 h-16 bg-gradient-to-b ${currentTheme.bgGlow} opacity-60 pointer-events-none`} />

      <div className="relative z-10 flex items-start justify-between gap-2">
        {/* Label & Value */}
        <div className="space-y-1">
          <p className="text-[11px] font-semibold tracking-wide text-zinc-400 uppercase">
            {data.label}
          </p>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-black tracking-tight text-white font-mono">
              {data.value}
            </span>
          </div>
        </div>

        {/* Neon Accent Icon Box */}
        <div className={`flex items-center justify-center w-8 h-8 rounded-xl border ${currentTheme.iconBg} shadow-sm`}>
          {renderIcon()}
        </div>
      </div>

      {/* Footer Info & Trend */}
      <div className="relative z-10 mt-3 pt-2.5 border-t border-zinc-800/60 flex items-center justify-between text-[11px]">
        <span className="text-zinc-400 font-medium truncate max-w-[120px]">
          {data.subtext}
        </span>
        
        <div className="flex items-center gap-1 font-semibold text-[10px]">
          <span className={`px-1.5 py-0.5 rounded-full ${currentTheme.badgeBg} flex items-center gap-0.5`}>
            <TrendingUp className="w-2.5 h-2.5" />
            {data.change}
          </span>
          <ChevronRight className="w-3 h-3 text-zinc-600 group-hover:text-zinc-300 transition-colors" />
        </div>
      </div>
    </div>
  );
};
