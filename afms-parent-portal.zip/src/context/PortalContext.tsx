import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  ParentInfo,
  StudentInfo,
  FeedbackForm,
  SubmissionRecord,
  Announcement,
  AttendanceDetail,
  TabType,
  AccentTheme,
  NotificationSettings,
} from '../types';
import {
  INITIAL_PARENT,
  INITIAL_STUDENT,
  ACTIVE_FORMS,
  ANNOUNCEMENTS,
  INITIAL_ATTENDANCE,
} from '../data/initialData';

interface PortalContextType {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  parent: ParentInfo;
  updateParent: (info: Partial<ParentInfo>) => void;
  student: StudentInfo;
  attendanceDetail: AttendanceDetail;
  activeForms: FeedbackForm[];
  submissions: SubmissionRecord[];
  submittedFormIds: string[];
  announcements: Announcement[];
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  accentTheme: AccentTheme;
  setAccentTheme: (theme: AccentTheme) => void;
  notifications: NotificationSettings;
  updateNotification: (key: keyof NotificationSettings, value: boolean) => void;
  submitFeedback: (form: FeedbackForm, answers: Record<string, { text: string; answer: string | null }>, suggestions: string) => void;
  
  // Modals state
  activeFeedbackForm: FeedbackForm | null;
  openFeedbackModal: (formId: string) => void;
  closeFeedbackModal: () => void;
  
  activeSubmission: SubmissionRecord | null;
  openViewSubmissionModal: (subId: string) => void;
  closeViewSubmissionModal: () => void;
  
  isEditProfileOpen: boolean;
  openEditProfileModal: () => void;
  closeEditProfileModal: () => void;
  
  isLogoutModalOpen: boolean;
  openLogoutModal: () => void;
  closeLogoutModal: () => void;
  isLoggedOut: boolean;
  login: () => void;
  logout: () => void;
  
  infoModal: { isOpen: boolean; title: string; content: string };
  openInfoModal: (title: string, content: string) => void;
  closeInfoModal: () => void;
  
  successModal: { isOpen: boolean; submission: SubmissionRecord | null };
  closeSuccessModal: () => void;

  toastMessage: string | null;
  showToast: (msg: string) => void;
  
  // Desktop mobile wrapper toggle
  isMobileDeviceFrame: boolean;
  toggleMobileDeviceFrame: () => void;
}

const STORAGE_KEY = 'afms_parent_portal_app_state_v2';

const PortalContext = createContext<PortalContextType | undefined>(undefined);

export const PortalProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [parent, setParent] = useState<ParentInfo>(INITIAL_PARENT);
  const [student, setStudent] = useState<StudentInfo>(INITIAL_STUDENT);
  const [attendanceDetail] = useState<AttendanceDetail>(INITIAL_ATTENDANCE);
  const [activeForms] = useState<FeedbackForm[]>(ACTIVE_FORMS);
  const [submissions, setSubmissions] = useState<SubmissionRecord[]>([]);
  const [submittedFormIds, setSubmittedFormIds] = useState<string[]>([]);
  const [announcements] = useState<Announcement[]>(ANNOUNCEMENTS);
  
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [accentTheme, setAccentThemeState] = useState<AccentTheme>('blue');
  const [notifications, setNotifications] = useState<NotificationSettings>({
    feedback: true,
    announcement: true,
    fee: true,
    exam: true,
  });
  
  const [isMobileDeviceFrame, setIsMobileDeviceFrame] = useState<boolean>(true);

  // Modal states
  const [activeFeedbackForm, setActiveFeedbackForm] = useState<FeedbackForm | null>(null);
  const [activeSubmission, setActiveSubmission] = useState<SubmissionRecord | null>(null);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState<boolean>(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState<boolean>(false);
  const [isLoggedOut, setIsLoggedOut] = useState<boolean>(false);
  
  const [infoModal, setInfoModal] = useState<{ isOpen: boolean; title: string; content: string }>({
    isOpen: false,
    title: '',
    content: '',
  });

  const [successModal, setSuccessModal] = useState<{ isOpen: boolean; submission: SubmissionRecord | null }>({
    isOpen: false,
    submission: null,
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load state on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.parent) setParent(parsed.parent);
        if (parsed.student) setStudent(parsed.student);
        if (parsed.submissions) setSubmissions(parsed.submissions);
        if (parsed.submittedFormIds) setSubmittedFormIds(parsed.submittedFormIds);
        if (typeof parsed.isDarkMode === 'boolean') setIsDarkMode(parsed.isDarkMode);
        if (parsed.accentTheme) setAccentThemeState(parsed.accentTheme);
        if (parsed.notifications) setNotifications(parsed.notifications);
        if (typeof parsed.isMobileDeviceFrame === 'boolean') setIsMobileDeviceFrame(parsed.isMobileDeviceFrame);
      }
    } catch (e) {
      console.warn("Failed to parse saved portal state", e);
    }
  }, []);

  // Save state on changes
  useEffect(() => {
    try {
      const stateToSave = {
        parent,
        student,
        submissions,
        submittedFormIds,
        isDarkMode,
        accentTheme,
        notifications,
        isMobileDeviceFrame,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));
    } catch (e) {
      console.warn("Failed to persist state", e);
    }
  }, [parent, student, submissions, submittedFormIds, isDarkMode, accentTheme, notifications, isMobileDeviceFrame]);

  // Sync dark mode body class
  useEffect(() => {
    if (!isDarkMode) {
      document.body.classList.add('light-mode');
    } else {
      document.body.classList.remove('light-mode');
    }
  }, [isDarkMode]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 3000);
  };

  const toggleDarkMode = () => setIsDarkMode((prev) => !prev);

  const setAccentTheme = (theme: AccentTheme) => {
    setAccentThemeState(theme);
    showToast(`Accent theme updated to ${theme.toUpperCase()}`);
  };

  const updateParent = (info: Partial<ParentInfo>) => {
    setParent((prev) => ({ ...prev, ...info }));
    showToast("Profile details updated successfully");
  };

  const updateNotification = (key: keyof NotificationSettings, value: boolean) => {
    setNotifications((prev) => ({ ...prev, [key]: value }));
  };

  const submitFeedback = (
    form: FeedbackForm,
    answers: Record<string, { text: string; answer: string | null }>,
    suggestions: string
  ) => {
    const now = new Date();
    const newSubmission: SubmissionRecord = {
      id: `sub_${Date.now()}`,
      formId: form.id,
      title: form.title,
      parentName: parent.name,
      studentName: student.name,
      date: now.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }),
      time: now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
      status: 'Submitted',
      answers,
      suggestions,
    };

    setSubmittedFormIds((prev) => [...prev, form.id]);
    setSubmissions((prev) => [...prev, newSubmission]);
    setActiveFeedbackForm(null);

    setSuccessModal({
      isOpen: true,
      submission: newSubmission,
    });
  };

  const openFeedbackModal = (formId: string) => {
    const form = activeForms.find((f) => f.id === formId);
    if (form) setActiveFeedbackForm(form);
  };

  const closeFeedbackModal = () => setActiveFeedbackForm(null);

  const openViewSubmissionModal = (subId: string) => {
    const sub = submissions.find((s) => s.id === subId);
    if (sub) setActiveSubmission(sub);
  };

  const closeViewSubmissionModal = () => setActiveSubmission(null);

  const openEditProfileModal = () => setIsEditProfileOpen(true);
  const closeEditProfileModal = () => setIsEditProfileOpen(false);

  const openLogoutModal = () => setIsLogoutModalOpen(true);
  const closeLogoutModal = () => setIsLogoutModalOpen(false);

  const logout = () => {
    setIsLogoutModalOpen(false);
    setIsLoggedOut(true);
  };

  const login = () => {
    setIsLoggedOut(false);
    setActiveTab('dashboard');
  };

  const openInfoModal = (title: string, content: string) => {
    setInfoModal({ isOpen: true, title, content });
  };

  const closeInfoModal = () => {
    setInfoModal({ isOpen: false, title: '', content: '' });
  };

  const closeSuccessModal = () => {
    setSuccessModal({ isOpen: false, submission: null });
  };

  const toggleMobileDeviceFrame = () => {
    setIsMobileDeviceFrame((prev) => !prev);
  };

  return (
    <PortalContext.Provider
      value={{
        activeTab,
        setActiveTab,
        parent,
        updateParent,
        student,
        attendanceDetail,
        activeForms,
        submissions,
        submittedFormIds,
        announcements,
        isDarkMode,
        toggleDarkMode,
        accentTheme,
        setAccentTheme,
        notifications,
        updateNotification,
        submitFeedback,
        activeFeedbackForm,
        openFeedbackModal,
        closeFeedbackModal,
        activeSubmission,
        openViewSubmissionModal,
        closeViewSubmissionModal,
        isEditProfileOpen,
        openEditProfileModal,
        closeEditProfileModal,
        isLogoutModalOpen,
        openLogoutModal,
        closeLogoutModal,
        isLoggedOut,
        login,
        logout,
        infoModal,
        openInfoModal,
        closeInfoModal,
        successModal,
        closeSuccessModal,
        toastMessage,
        showToast,
        isMobileDeviceFrame,
        toggleMobileDeviceFrame,
      }}
    >
      {children}
    </PortalContext.Provider>
  );
};

export const usePortal = (): PortalContextType => {
  const context = useContext(PortalContext);
  if (!context) {
    throw new Error('usePortal must be used within a PortalProvider');
  }
  return context;
};
