import React, { useState } from 'react';
import { Plus, Search, Edit3, BarChart2, Trash2, ChevronDown, CheckCircle2, Download, Eye, X, Save } from 'lucide-react';

interface QuestionnairesViewProps {
  theme?: 'light' | 'dark' | 'system';
}

export const QuestionnairesView: React.FC<QuestionnairesViewProps> = ({ theme = 'light' }) => {
  const isDark = theme === 'dark';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('All Statuses');

  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [previewForm, setPreviewForm] = useState<any | null>(null);

  const [newTitle, setNewTitle] = useState('');
  const [newSubtitle, setNewSubtitle] = useState('');

  const [formsList, setFormsList] = useState([
    {
      id: 'q1',
      title: 'parent questionnaire',
      subtitle: 'parents test',
      status: 'Active',
      questionsCount: 5,
      responsesCount: 14,
      updatedDate: '23 Jul 2026',
      sampleQuestions: [
        'How satisfied are you with academic progress reporting?',
        'Rate campus infrastructure & safety measures.',
        'Are faculty members approachable for academic queries?'
      ]
    },
    {
      id: 'q2',
      title: 'faculty assessment form',
      subtitle: 'for faculty',
      status: 'Active',
      questionsCount: 5,
      responsesCount: 28,
      updatedDate: '23 Jul 2026',
      sampleQuestions: [
        'Evaluate course curriculum relevance & industry alignment.',
        'Availability of research grants & lab equipment.',
        'Support for pedagogical innovation & digital tools.'
      ]
    },
    {
      id: 'q3',
      title: 'Test Questionnaire for Announcement 2',
      subtitle: 'testcase',
      status: 'Active',
      questionsCount: 4,
      responsesCount: 8,
      updatedDate: '22 Jul 2026',
      sampleQuestions: ['Feedback on announcement guidelines.']
    },
    {
      id: 'q4',
      title: 'Test Questionnaire for Announcement',
      subtitle: 'test67',
      status: 'Active',
      questionsCount: 7,
      responsesCount: 12,
      updatedDate: '23 Jul 2026',
      sampleQuestions: ['Rate clarity of institutional policy announcements.']
    },
    {
      id: 'q5',
      title: 'test 3 draft',
      subtitle: 'test 3',
      status: 'Active',
      questionsCount: 6,
      responsesCount: 19,
      updatedDate: '23 Jul 2026',
      sampleQuestions: ['Overall satisfaction with course delivery.']
    },
    {
      id: 'q6',
      title: 'test 5',
      subtitle: 'test 4',
      status: 'Active',
      questionsCount: 3,
      responsesCount: 5,
      updatedDate: '22 Jul 2026',
      sampleQuestions: ['Lab experiment facilities rating.']
    }
  ]);

  const handleDeleteForm = (id: string) => {
    if (confirm('Are you sure you want to delete this questionnaire?')) {
      setFormsList(prev => prev.filter(f => f.id !== id));
    }
  };

  const handleCreateQuestionnaire = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;

    const newForm = {
      id: `q${Date.now()}`,
      title: newTitle,
      subtitle: newSubtitle || 'Custom Campaign',
      status: 'Active',
      questionsCount: 5,
      responsesCount: 0,
      updatedDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      sampleQuestions: ['Sample Question 1', 'Sample Question 2']
    };

    setFormsList([newForm, ...formsList]);
    setNewTitle('');
    setNewSubtitle('');
    setIsNewModalOpen(false);
  };

  const handleExportQuestionnairesCSV = () => {
    const header = ['ID', 'Title', 'Associated Session', 'Status', 'Questions Count', 'Responses Count', 'Last Updated'];
    const rows = formsList.map(f => [f.id, f.title, f.subtitle, f.status, f.questionsCount.toString(), f.responsesCount.toString(), f.updatedDate]);
    const csvContent = [header, ...rows].map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(",")).join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'AFMS_Questionnaires_List.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredForms = formsList.filter((f) => {
    const matchesSearch = 
      f.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.subtitle.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = selectedStatus === 'All Statuses' || f.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-5 max-w-7xl mx-auto animate-in fade-in duration-200">
      
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            Questionnaires
          </h1>
          <p className="text-xs font-semibold text-zinc-500 mt-0.5">
            {formsList.length} feedback questionnaires configured in system.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button 
            onClick={handleExportQuestionnairesCSV}
            className="px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button 
            onClick={() => setIsNewModalOpen(true)}
            className="px-4 py-2.5 rounded-2xl bg-[#ea580c] hover:bg-[#c2410c] text-white font-bold text-xs shadow-lg shadow-orange-500/20 transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>New Questionnaire</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            placeholder="Search questionnaires or sessions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full text-xs rounded-2xl pl-10 pr-4 py-3 border focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
              isDark 
                ? 'bg-[#181210] border-[#2e2623] text-white placeholder-zinc-500' 
                : 'bg-white border-zinc-200 text-zinc-900 placeholder-zinc-400 shadow-xs'
            }`}
          />
        </div>

        <div className="relative w-full sm:w-44">
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className={`w-full appearance-none text-xs font-bold rounded-2xl px-4 py-3 border pr-9 focus:outline-none focus:ring-2 focus:ring-orange-500/50 cursor-pointer ${
              isDark 
                ? 'bg-[#181210] border-[#2e2623] text-zinc-200' 
                : 'bg-white border-zinc-200 text-zinc-800 shadow-xs'
            }`}
          >
            <option value="All Statuses">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Draft">Draft</option>
          </select>
          <ChevronDown className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" />
        </div>
      </div>

      {/* Questionnaire Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredForms.map((form) => (
          <div
            key={form.id}
            className={`rounded-3xl border p-5 transition-all hover:shadow-lg flex flex-col justify-between space-y-4 ${
              isDark 
                ? 'bg-[#181210] border-[#2e2623] text-zinc-100 hover:border-zinc-700' 
                : 'bg-white border-zinc-200 text-zinc-900 shadow-sm hover:border-orange-200'
            }`}
          >
            {/* Top Row: Title + Orange Subtitle + Status Pill */}
            <div className="flex items-start justify-between gap-2">
              <div className="space-y-0.5">
                <h3 className="text-sm font-black leading-snug tracking-tight">
                  {form.title}
                </h3>
                <p className="text-xs font-bold text-amber-500 dark:text-amber-400">
                  {form.subtitle}
                </p>
              </div>

              <span className="px-3 py-1 rounded-full text-[10px] font-extrabold bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 flex items-center gap-1 shrink-0">
                <CheckCircle2 className="w-3 h-3" />
                {form.status}
              </span>
            </div>

            {/* Central Metrics Boxes */}
            <div className={`grid grid-cols-2 gap-2 p-3 rounded-2xl border ${
              isDark ? 'bg-[#120e0d] border-[#221c19]' : 'bg-slate-50 border-slate-200/80'
            }`}>
              <div className="text-center py-1">
                <p className="text-lg font-black tracking-tight">{form.questionsCount}</p>
                <p className="text-[9px] font-extrabold text-zinc-400 tracking-wider uppercase">QUESTIONS</p>
              </div>
              <div className="text-center py-1 border-l border-zinc-200 dark:border-zinc-800">
                <p className="text-lg font-black tracking-tight">{form.responsesCount}</p>
                <p className="text-[9px] font-extrabold text-zinc-400 tracking-wider uppercase">RESPONSES</p>
              </div>
            </div>

            {/* Footer Row: Updated Date + Action Buttons */}
            <div className={`pt-3 border-t flex items-center justify-between text-xs text-zinc-400 ${
              isDark ? 'border-zinc-800/80' : 'border-zinc-100'
            }`}>
              <span className="text-[11px] font-medium">Updated {form.updatedDate}</span>

              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setPreviewForm(form)}
                  className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
                  title="Preview Questions"
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={() => handleDeleteForm(form.id)}
                  className="p-1.5 rounded-lg hover:bg-rose-500/10 text-zinc-400 hover:text-rose-500 transition-colors"
                  title="Delete"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* New Questionnaire Modal */}
      {isNewModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className={`w-full max-w-lg rounded-3xl p-6 border shadow-2xl animate-in zoom-in-95 duration-150 ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-white' : 'bg-white border-zinc-200 text-zinc-900'
          }`}>
            <div className="flex items-center justify-between pb-4 border-b border-zinc-200 dark:border-zinc-800">
              <h3 className="text-base font-black flex items-center gap-2">
                <Plus className="w-4 h-4 text-orange-500" />
                Create New Questionnaire
              </h3>
              <button onClick={() => setIsNewModalOpen(false)} className="p-1.5 rounded-xl hover:bg-zinc-800 text-zinc-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateQuestionnaire} className="space-y-4 pt-4">
              <div>
                <label className="block text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">Questionnaire Title</label>
                <input
                  type="text"
                  placeholder="e.g., Student End-Semester Course Evaluation"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDark ? 'bg-[#120e0d] border-[#221c19] text-white' : 'bg-slate-50 border-zinc-200 text-zinc-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">Associated Session Name</label>
                <input
                  type="text"
                  placeholder="e.g., 2025-2026 Sem 5 CSE"
                  value={newSubtitle}
                  onChange={(e) => setNewSubtitle(e.target.value)}
                  className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDark ? 'bg-[#120e0d] border-[#221c19] text-white' : 'bg-slate-50 border-zinc-200 text-zinc-900'
                  }`}
                />
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewModalOpen(false)}
                  className="px-4 py-2.5 rounded-2xl border border-zinc-300 dark:border-zinc-700 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-2xl bg-[#ea580c] hover:bg-[#c2410c] text-white text-xs font-bold shadow-md shadow-orange-500/20 flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Questionnaire</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Preview Questionnaire Modal */}
      {previewForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className={`w-full max-w-lg rounded-3xl p-6 border shadow-2xl animate-in zoom-in-95 duration-150 ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-white' : 'bg-white border-zinc-200 text-zinc-900'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
              <h3 className="text-sm font-black flex items-center gap-2">
                <Eye className="w-4 h-4 text-orange-500" />
                {previewForm.title}
              </h3>
              <button onClick={() => setPreviewForm(null)} className="p-1 rounded-lg text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-3">
              <p className="text-xs font-bold text-amber-500">Session: {previewForm.subtitle}</p>
              <p className="text-xs text-zinc-400">Total Questions: {previewForm.questionsCount} • Responses: {previewForm.responsesCount}</p>

              <div className="space-y-2 pt-2">
                <p className="text-[10px] font-black uppercase text-zinc-400">Sample Included Questions:</p>
                {previewForm.sampleQuestions?.map((q: string, idx: number) => (
                  <div key={idx} className={`p-3 rounded-2xl text-xs font-medium border ${
                    isDark ? 'bg-[#120e0d] border-[#221c19]' : 'bg-slate-50 border-zinc-200'
                  }`}>
                    {idx + 1}. {q}
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800 flex justify-end">
              <button 
                onClick={() => setPreviewForm(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-white font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
