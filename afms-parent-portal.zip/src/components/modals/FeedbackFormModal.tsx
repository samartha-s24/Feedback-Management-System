import React, { useState } from 'react';
import { usePortal } from '../../context/PortalContext';
import { getAccentClasses } from '../../utils/theme';
import { X, Star, CheckCircle, MessageSquare, AlertCircle } from 'lucide-react';

export const FeedbackFormModal: React.FC = () => {
  const {
    activeFeedbackForm,
    closeFeedbackModal,
    parent,
    student,
    submitFeedback,
    accentTheme,
    showToast,
  } = usePortal();

  const [ratings, setRatings] = useState<Record<string, number>>({});
  const [yesNoAnswers, setYesNoAnswers] = useState<Record<string, string>>({});
  const [suggestions, setSuggestions] = useState('');

  if (!activeFeedbackForm) return null;

  const accent = getAccentClasses(accentTheme);

  const handleStarClick = (qId: string, val: number) => {
    setRatings((prev) => ({ ...prev, [qId]: val }));
  };

  const handleYesNoChange = (qId: string, val: string) => {
    setYesNoAnswers((prev) => ({ ...prev, [qId]: val }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate that every question has an answer
    const formattedAnswers: Record<string, { text: string; answer: string | null }> = {};
    let isComplete = true;

    activeFeedbackForm.questions.forEach((q) => {
      if (q.type === 'star') {
        const val = ratings[q.id];
        if (!val) isComplete = false;
        formattedAnswers[q.id] = { text: q.text, answer: val ? `${val} / 5 ★` : null };
      } else if (q.type === 'yesno') {
        const val = yesNoAnswers[q.id];
        if (!val) isComplete = false;
        formattedAnswers[q.id] = { text: q.text, answer: val || null };
      }
    });

    if (!isComplete) {
      showToast('⚠️ Please rate/answer all questions before submitting.');
      return;
    }

    submitFeedback(activeFeedbackForm, formattedAnswers, suggestions);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-250">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/60 sticky top-0 z-10">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-2xl shrink-0">{activeFeedbackForm.icon}</span>
            <div className="min-w-0">
              <h3 className="font-bold text-sm text-slate-100 truncate leading-tight">
                {activeFeedbackForm.title}
              </h3>
              <p className="text-[11px] text-slate-400">Due: {activeFeedbackForm.dueDate}</p>
            </div>
          </div>
          <button
            onClick={closeFeedbackModal}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Form Body */}
        <form onSubmit={handleSubmit} className="p-4 overflow-y-auto space-y-4 text-xs">
          {/* Auto-filled Student Summary */}
          <div className="grid grid-cols-2 gap-2 p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80">
            <div>
              <span className="text-[10px] text-slate-500 block">Parent Name</span>
              <span className="font-semibold text-slate-200">{parent.name}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">Student Name</span>
              <span className="font-semibold text-slate-200">{student.name}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">PRN Number</span>
              <span className="font-mono font-semibold text-cyan-400">{student.prn}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">Division & Dept</span>
              <span className="font-semibold text-slate-200">{student.division}, {student.department}</span>
            </div>
          </div>

          {/* Dynamic Questions */}
          <div className="space-y-3">
            {activeFeedbackForm.questions.map((q, idx) => (
              <div key={q.id} className="p-3.5 rounded-2xl bg-slate-950/50 border border-slate-800/80 space-y-2">
                <p className="font-semibold text-slate-200 text-xs leading-relaxed">
                  <span className="text-cyan-400 font-bold mr-1">{idx + 1}.</span>
                  {q.text}
                </p>

                {q.type === 'star' && (
                  <div className="flex items-center justify-around py-1">
                    {[1, 2, 3, 4, 5].map((val) => {
                      const currentVal = ratings[q.id] || 0;
                      const isFilled = val <= currentVal;
                      return (
                        <button
                          key={val}
                          type="button"
                          onClick={() => handleStarClick(q.id, val)}
                          className="p-1.5 transition-transform hover:scale-125 focus:outline-none"
                        >
                          <Star
                            className={`w-7 h-7 ${
                              isFilled ? 'text-amber-400 fill-amber-400 drop-shadow-md' : 'text-slate-700 fill-slate-800'
                            }`}
                          />
                        </button>
                      );
                    })}
                  </div>
                )}

                {q.type === 'yesno' && (
                  <div className="flex items-center gap-4 pt-1">
                    {['Yes', 'No'].map((opt) => (
                      <label key={opt} className="flex items-center gap-2 text-slate-300 font-medium cursor-pointer">
                        <input
                          type="radio"
                          name={q.id}
                          value={opt}
                          checked={yesNoAnswers[q.id] === opt}
                          onChange={() => handleYesNoChange(q.id, opt)}
                          className="w-4 h-4 accent-cyan-500"
                        />
                        <span>{opt}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Suggestions Prompt Area */}
          <div className="space-y-1.5 pt-1">
            <label className="font-semibold text-slate-300 text-xs block">
              {activeFeedbackForm.suggestionsPrompt || 'Additional Feedback or Suggestions'}
            </label>
            <textarea
              value={suggestions}
              onChange={(e) => setSuggestions(e.target.value)}
              placeholder="Write your comments or recommendations here..."
              rows={3}
              className="w-full p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
            />
          </div>

          {/* Form Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={closeFeedbackModal}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-5 py-2.5 rounded-xl text-xs font-bold ${accent.primaryBtn} shadow-lg active:scale-98`}
            >
              Submit Feedback
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
