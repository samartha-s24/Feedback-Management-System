import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell
} from 'recharts';
import { SubmissionTrendPoint, SentimentDataPoint } from '../types';
import { TrendingUp, PieChart as PieIcon, BarChart2, Filter } from 'lucide-react';

interface ChartsSectionProps {
  trendData: SubmissionTrendPoint[];
  sentimentData: SentimentDataPoint[];
}

export const ChartsSection: React.FC<ChartsSectionProps> = ({ trendData, sentimentData }) => {
  const [trendRange, setTrendRange] = useState<'daily' | 'weekly'>('daily');

  return (
    <div className="space-y-4">
      {/* 1. Submission Trend Line/Area Chart */}
      <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800/90 p-4 relative overflow-hidden">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-orange-500/15 border border-orange-500/30 text-orange-400">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                Submission Trend
              </h2>
              <p className="text-[11px] text-zinc-400">Daily responses vs target</p>
            </div>
          </div>

          {/* Time range selector */}
          <div className="flex items-center bg-zinc-950 p-1 rounded-xl border border-zinc-800 text-[11px]">
            <button
              onClick={() => setTrendRange('daily')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                trendRange === 'daily' ? 'bg-orange-500 text-zinc-950 font-bold' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Daily
            </button>
            <button
              onClick={() => setTrendRange('weekly')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                trendRange === 'weekly' ? 'bg-orange-500 text-zinc-950 font-bold' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Weekly
            </button>
          </div>
        </div>

        {/* Recharts Area Container */}
        <div className="h-48 w-full mt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
              <defs>
                <linearGradient id="orangeGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f97316" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#f97316" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="cyanGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="date" 
                stroke="#52525b" 
                fontSize={10} 
                tickLine={false} 
                axisLine={false} 
              />
              <YAxis 
                stroke="#52525b" 
                fontSize={10} 
                tickLine={false} 
                axisLine={false} 
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#09090b', 
                  borderColor: '#27272a', 
                  borderRadius: '12px',
                  color: '#fff',
                  fontSize: '12px' 
                }} 
              />
              <Area 
                type="monotone" 
                dataKey="responses" 
                stroke="#f97316" 
                strokeWidth={3} 
                fillOpacity={1} 
                fill="url(#orangeGlow)" 
                name="Responses"
              />
              <Area 
                type="monotone" 
                dataKey="target" 
                stroke="#06b6d4" 
                strokeWidth={1.5} 
                strokeDasharray="3 3" 
                fillOpacity={1} 
                fill="url(#cyanGlow)" 
                name="Target"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Footer legend */}
        <div className="flex items-center justify-center gap-6 mt-2 pt-2 border-t border-zinc-800/80 text-[11px]">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500 shadow-sm shadow-orange-500/50"></span>
            <span className="text-zinc-300 font-medium">Actual Submissions</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 border border-dashed border-cyan-300"></span>
            <span className="text-zinc-400">Target Projection</span>
          </div>
        </div>
      </div>

      {/* 2. Sentiment Distribution Donut Chart */}
      <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800/90 p-4">
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-cyan-500/15 border border-cyan-500/30 text-cyan-400">
              <PieIcon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Sentiment Breakdown</h2>
              <p className="text-[11px] text-zinc-400">AI Analyzed Ratings Index</p>
            </div>
          </div>
          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            89.4% Positive
          </span>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 py-2">
          {/* Donut graphic with center score */}
          <div className="relative w-40 h-40 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sentimentData}
                  cx="50%"
                  cy="50%"
                  innerRadius={48}
                  outerRadius={68}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {sentimentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="#09090b" strokeWidth={2} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#09090b', 
                    borderColor: '#27272a', 
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '11px' 
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
            {/* Center metric */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-xl font-black text-white font-mono">89.4%</span>
              <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">Positive</span>
            </div>
          </div>

          {/* Side Legend */}
          <div className="w-full sm:w-auto space-y-2 text-xs">
            {sentimentData.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between sm:justify-start gap-3 p-1.5 rounded-xl bg-zinc-950/60 border border-zinc-800/60">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-zinc-300 text-[11px] font-medium">{item.name}</span>
                </div>
                <span className="font-mono font-bold text-white text-[11px] ml-2">
                  {item.value}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
