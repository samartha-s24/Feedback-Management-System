import React from 'react';
import { 
  LayoutGrid, 
  User,
  Calendar,
  FileText, 
  HelpCircle,
  MessageSquare,
  BarChart2,
  FileSpreadsheet,
  Megaphone, 
  ClipboardList,
  Settings, 
  LogOut, 
  Shield,
  X
} from 'lucide-react';
import { TabType } from '../types';

interface NavigationSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  onLogout?: () => void;
  theme?: 'light' | 'dark' | 'system';
}

export const NavigationSidebar: React.FC<NavigationSidebarProps> = ({
  isOpen,
  onClose,
  activeTab,
  setActiveTab,
  onLogout,
  theme = 'dark'
}) => {
  if (!isOpen) return null;

  const handleSelectTab = (tab: TabType) => {
    setActiveTab(tab);
    onClose();
  };

  const isDark = theme === 'dark';

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop overlay */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity" 
        onClick={onClose}
      />

      {/* Drawer Container */}
      <div className={`relative w-72 max-w-[80vw] h-full ${
        isDark 
          ? 'bg-[#181210] text-zinc-100 border-r border-[#2e2623]' 
          : 'bg-white text-zinc-900 border-r border-zinc-200'
      } p-4 flex flex-col justify-between z-10 shadow-2xl animate-in slide-in-from-left duration-200 overflow-y-auto`}>
        
        <div className="space-y-4">
          {/* Top Branding Bar */}
          <div className={`flex items-center justify-between pb-3 border-b ${
            isDark ? 'border-zinc-800' : 'border-zinc-200'
          }`}>
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-md shadow-orange-500/20">
                <Shield className="w-4 h-4 text-white fill-white/20" />
              </div>
              <div>
                <p className={`font-black text-sm leading-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
                  AFMS
                </p>
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                  Admin Portal
                </p>
              </div>
            </div>

            <button 
              onClick={onClose}
              className={`p-1.5 rounded-lg transition-colors ${
                isDark ? 'text-zinc-400 hover:text-white hover:bg-zinc-800' : 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100'
              }`}
              title="Close menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-4">
            
            {/* Top Main Section */}
            <div className="space-y-1">
              <button
                onClick={() => handleSelectTab('overview')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'overview'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
                <span>Dashboard</span>
              </button>

              <button
                onClick={() => handleSelectTab('profile')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'profile'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <User className="w-4 h-4" />
                <span>Admin Profile</span>
              </button>
            </div>

            {/* FEEDBACK SECTION */}
            <div className="space-y-1 pt-1">
              <div className="px-3.5 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                FEEDBACK
              </div>

              {/* Sessions */}
              <button
                onClick={() => handleSelectTab('sessions')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'sessions'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Sessions</span>
              </button>

              {/* Questionnaires */}
              <button
                onClick={() => handleSelectTab('questionnaires')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'questionnaires'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Questionnaires</span>
              </button>

              {/* Question Bank */}
              <button
                onClick={() => handleSelectTab('questions')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'questions'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <HelpCircle className="w-4 h-4" />
                <span>Question Bank</span>
              </button>

              {/* Responses */}
              <button
                onClick={() => handleSelectTab('responses')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'responses' || activeTab === 'my_submissions'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>Responses</span>
              </button>
            </div>

            {/* INSIGHTS SECTION */}
            <div className="space-y-1 pt-1">
              <div className="px-3.5 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                INSIGHTS
              </div>

              {/* Analytics */}
              <button
                onClick={() => handleSelectTab('analytics')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'analytics'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <BarChart2 className="w-4 h-4" />
                <span>Analytics</span>
              </button>

              {/* Reports */}
              <button
                onClick={() => handleSelectTab('reports')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'reports'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Reports</span>
              </button>
            </div>

            {/* SYSTEM SECTION */}
            <div className="space-y-1 pt-1">
              <div className="px-3.5 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                SYSTEM
              </div>

              {/* Announcements */}
              <button
                onClick={() => handleSelectTab('announcements')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'announcements'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <Megaphone className="w-4 h-4" />
                <span>Announcements</span>
              </button>

              {/* Audit Log */}
              <button
                onClick={() => handleSelectTab('audit_log')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'audit_log'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <ClipboardList className="w-4 h-4" />
                <span>Audit Log</span>
              </button>

              {/* Settings */}
              <button
                onClick={() => handleSelectTab('settings')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm transition-all ${
                  activeTab === 'settings'
                    ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 font-bold'
                    : isDark 
                      ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/50 font-medium'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 font-medium'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </button>
            </div>

          </nav>
        </div>

        {/* Bottom Logout Area */}
        <div className={`pt-4 mt-6 border-t ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button
            onClick={() => {
              if (onLogout) onLogout();
              onClose();
            }}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl font-bold text-sm text-rose-500 hover:bg-rose-500/10 transition-all"
          >
            <LogOut className="w-4 h-4 text-rose-500" />
            <span>Logout</span>
          </button>
        </div>

      </div>
    </div>
  );
};

