import React, { useState } from 'react';
import { Plus, Search, QrCode, Eye, Trash2, Filter, Download, X, Check, Copy, RefreshCw } from 'lucide-react';
import { FeedbackSession } from '../types';

interface SessionsViewProps {
  sessions?: FeedbackSession[];
  onOpenNewSessionModal: () => void;
  searchQuery?: string;
  theme?: 'light' | 'dark' | 'system';
}

export const SessionsView: React.FC<SessionsViewProps> = ({
  sessions = [],
  onOpenNewSessionModal,
  searchQuery = '',
  theme = 'light'
}) => {
  const isDark = theme === 'dark';

  const [search, setSearch] = useState(searchQuery);
  const [statusFilter, setStatusFilter] = useState('All Statuses');
  const [selectedQrSession, setSelectedQrSession] = useState<any | null>(null);
  const [selectedDetailSession, setSelectedDetailSession] = useState<any | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  const defaultSessions = [
    {
      id: 's1',
      title: 'parents test',
      yearSem: '2025-2026 / Sem 5',
      formsCount: 1,
      dateRange: 'Jul 23, 2026 – Jul 31, 2026',
      status: 'Active',
      description: 'Parent feedback collection for 5th semester academic performance & campus facilities.'
    },
    {
      id: 's2',
      title: 'for faculty',
      yearSem: '2025-2026 / Sem 5',
      formsCount: 1,
      dateRange: 'Jul 22, 2026 – Jul 30, 2026',
      status: 'Active',
      description: 'Internal faculty self-assessment & peer evaluation campaign.'
    },
    {
      id: 's3',
      title: 'test 3',
      yearSem: '2025-2026 / Sem 1',
      formsCount: 1,
      dateRange: 'Jul 22, 2026 – Jul 23, 2026',
      status: 'Active',
      description: 'Semester 1 initial orientation survey.'
    },
    {
      id: 's4',
      title: 'test67',
      yearSem: '2025-2026 / -',
      formsCount: 1,
      dateRange: 'Jul 22, 2026 – Jul 23, 2026',
      status: 'Draft',
      description: 'Draft configuration for CSE mid-term review.'
    },
    {
      id: 's5',
      title: 'testcase',
      yearSem: '2025-2026 / -',
      formsCount: 1,
      dateRange: 'Jul 20, 2026 – Jul 25, 2026',
      status: 'Active',
      description: 'General campus experience test case survey.'
    }
  ];

  // Combine parent sessions state with local defaults
  const formattedPropSessions = sessions.map(s => ({
    id: s.id,
    title: s.title,
    yearSem: `${s.department} (${s.targetAudience})`,
    formsCount: s.questionsCount || 1,
    dateRange: `Until ${s.deadline}`,
    status: s.status === 'urgent' ? 'Active' : s.status === 'active' ? 'Active' : s.status === 'closed' ? 'Closed' : 'Draft',
    description: `Targeting ${s.targetAudience}. Total responses: ${s.responsesCount}`
  }));

  const allSessions = [...formattedPropSessions, ...defaultSessions.filter(ds => !formattedPropSessions.some(ps => ps.id === ds.id))];

  const [deletedIds, setDeletedIds] = useState<string[]>([]);
  const [overriddenStatuses, setOverriddenStatuses] = useState<Record<string, string>>({});

  const activeSessionsList = allSessions
    .filter(s => !deletedIds.includes(s.id))
    .map(s => overriddenStatuses[s.id] ? { ...s, status: overriddenStatuses[s.id] } : s);

  const handleDeleteSession = (id: string) => {
    if (confirm('Are you sure you want to delete this session?')) {
      setDeletedIds(prev => [...prev, id]);
    }
  };

  const handleToggleStatus = (id: string) => {
    setOverriddenStatuses(prev => {
      const current = activeSessionsList.find(s => s.id === id)?.status || 'Active';
      return {
        ...prev,
        [id]: current === 'Active' ? 'Closed' : 'Active'
      };
    });
  };

  const handleExportSessionsCSV = () => {
    const header = ['Session ID', 'Title', 'Year / Semester', 'Forms Count', 'Date Range', 'Status', 'Description'];
    const rows = activeSessionsList.map(s => [s.id, s.title, s.yearSem, s.formsCount.toString(), s.dateRange, s.status, s.description]);
    const csvContent = [header, ...rows].map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(",")).join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'AFMS_Feedback_Sessions.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filtered = activeSessionsList.filter(s => {
    const matchesSearch = s.title.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'All Statuses' || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCopySessionLink = (id: string) => {
    navigator.clipboard.writeText(`https://afms.edu.in/feedback/session/${id}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="space-y-5 max-w-7xl mx-auto animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            Feedback Sessions
          </h1>
          <p className="text-xs font-semibold text-zinc-500 mt-0.5">
            Manage active feedback collection campaigns, access QR codes, and export records.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button 
            onClick={handleExportSessionsCSV}
            className="px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button 
            onClick={onOpenNewSessionModal}
            className="px-4 py-2.5 rounded-2xl bg-[#ea580c] hover:bg-[#c2410c] text-white font-bold text-xs shadow-lg shadow-orange-500/20 transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>New Session</span>
          </button>
        </div>
      </div>

      {/* Stat Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className={`p-4 rounded-3xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black">{sessionsList.length}</p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">TOTAL SESSIONS</p>
        </div>

        <div className={`p-4 rounded-3xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black text-emerald-500">
            {sessionsList.filter(s => s.status === 'Active').length}
          </p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">ACTIVE</p>
        </div>

        <div className={`p-4 rounded-3xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black text-amber-500">
            {sessionsList.filter(s => s.status !== 'Active').length}
          </p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">DRAFT / CLOSED</p>
        </div>
      </div>

      {/* Filter Row */}
      <div className="flex flex-col sm:flex-row items-center gap-2.5">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            placeholder="Search sessions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={`w-full text-xs rounded-2xl pl-10 pr-4 py-2.5 border focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
              isDark 
                ? 'bg-[#181210] border-[#2e2623] text-white placeholder-zinc-500' 
                : 'bg-white border-zinc-200 text-zinc-900 placeholder-zinc-400 shadow-xs'
            }`}
          />
        </div>

        <select 
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className={`text-xs font-bold rounded-2xl px-4 py-2.5 border cursor-pointer w-full sm:w-auto ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-200' : 'bg-white border-zinc-200 text-zinc-800 shadow-xs'
          }`}
        >
          <option value="All Statuses">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Draft">Draft</option>
          <option value="Closed">Closed</option>
        </select>
      </div>

      {/* Sessions Table */}
      <div className={`rounded-3xl border overflow-hidden ${
        isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
      }`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className={`text-[10px] font-black uppercase tracking-wider border-b ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-400' : 'bg-slate-50 border-zinc-200 text-zinc-500'
              }`}>
                <th className="py-3.5 px-4">SESSION</th>
                <th className="py-3.5 px-4">YEAR / SEM</th>
                <th className="py-3.5 px-4">FORMS</th>
                <th className="py-3.5 px-4">DATE RANGE</th>
                <th className="py-3.5 px-4">STATUS</th>
                <th className="py-3.5 px-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800/60 text-xs">
              {filtered.map((sessionItem) => (
                <tr key={sessionItem.id} className="hover:bg-zinc-500/5 transition-colors">
                  <td className="py-4 px-4 font-extrabold text-sm">{sessionItem.title}</td>

                  <td className="py-4 px-4 font-medium text-zinc-400">{sessionItem.yearSem}</td>

                  <td className="py-4 px-4 font-bold">{sessionItem.formsCount}</td>

                  <td className="py-4 px-4 font-medium text-zinc-400 text-[11px]">{sessionItem.dateRange}</td>

                  <td className="py-4 px-4">
                    <button 
                      onClick={() => handleToggleStatus(sessionItem.id)}
                      title="Click to toggle status"
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold inline-flex items-center gap-1 cursor-pointer transition-all ${
                        sessionItem.status === 'Active'
                          ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 hover:bg-emerald-500/20'
                          : 'bg-amber-500/10 text-amber-500 border border-amber-500/20 hover:bg-amber-500/20'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${sessionItem.status === 'Active' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                      {sessionItem.status}
                    </button>
                  </td>

                  <td className="py-4 px-4 text-right">
                    <div className="flex items-center justify-end gap-1 text-zinc-400">
                      <button 
                        onClick={() => setSelectedQrSession(sessionItem)}
                        className="p-1.5 rounded-lg hover:bg-orange-500/10 hover:text-orange-500" 
                        title="View QR Code"
                      >
                        <QrCode className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => setSelectedDetailSession(sessionItem)}
                        className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-white" 
                        title="View Details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDeleteSession(sessionItem.id)}
                        className="p-1.5 rounded-lg hover:bg-rose-500/10 hover:text-rose-500" 
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* QR Code Modal */}
      {selectedQrSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className={`w-full max-w-sm rounded-3xl p-6 border shadow-2xl animate-in zoom-in-95 duration-150 text-center ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-white' : 'bg-white border-zinc-200 text-zinc-900'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
              <h3 className="text-sm font-black flex items-center gap-2">
                <QrCode className="w-4 h-4 text-orange-500" />
                Session QR Code
              </h3>
              <button onClick={() => setSelectedQrSession(null)} className="p-1 rounded-lg text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-5 space-y-4">
              <p className="text-xs font-bold text-orange-500">{selectedQrSession.title}</p>
              
              <div className="w-48 h-48 mx-auto bg-white p-3 rounded-2xl border-4 border-orange-500/30 flex items-center justify-center shadow-lg">
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=https://afms.edu.in/feedback/${selectedQrSession.id}`} 
                  alt="QR Code" 
                  className="w-full h-full object-contain"
                />
              </div>

              <div className="flex items-center justify-center gap-2 pt-2">
                <button 
                  onClick={() => handleCopySessionLink(selectedQrSession.id)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'Copied' : 'Copy Link'}</span>
                </button>

                <a 
                  href={`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=https://afms.edu.in/feedback/${selectedQrSession.id}`}
                  target="_blank"
                  rel="noreferrer"
                  download={`QR_${selectedQrSession.title}.png`}
                  className="px-3.5 py-2 rounded-xl bg-[#ea580c] hover:bg-[#c2410c] text-white font-bold text-xs flex items-center gap-1.5 shadow-md"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download QR</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Session Details Modal */}
      {selectedDetailSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className={`w-full max-w-md rounded-3xl p-6 border shadow-2xl animate-in zoom-in-95 duration-150 ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-white' : 'bg-white border-zinc-200 text-zinc-900'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
              <h3 className="text-sm font-black flex items-center gap-2">
                <Eye className="w-4 h-4 text-orange-500" />
                Session Details
              </h3>
              <button onClick={() => setSelectedDetailSession(null)} className="p-1 rounded-lg text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-3 text-xs">
              <div>
                <p className="text-[10px] font-bold text-zinc-400 uppercase">Title</p>
                <p className="text-sm font-extrabold">{selectedDetailSession.title}</p>
              </div>

              <div>
                <p className="text-[10px] font-bold text-zinc-400 uppercase">Academic Year / Semester</p>
                <p className="font-bold text-orange-500">{selectedDetailSession.yearSem}</p>
              </div>

              <div>
                <p className="text-[10px] font-bold text-zinc-400 uppercase">Active Duration</p>
                <p className="font-semibold">{selectedDetailSession.dateRange}</p>
              </div>

              <div>
                <p className="text-[10px] font-bold text-zinc-400 uppercase">Description</p>
                <p className="text-zinc-400 leading-relaxed">{selectedDetailSession.description}</p>
              </div>
            </div>

            <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800 flex justify-end">
              <button 
                onClick={() => setSelectedDetailSession(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-white font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
