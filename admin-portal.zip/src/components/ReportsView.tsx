import React, { useState } from 'react';
import { Download, FileSpreadsheet, Play, CheckCircle2, FileText, Check } from 'lucide-react';

interface ReportsViewProps {
  theme?: 'light' | 'dark' | 'system';
}

export const ReportsView: React.FC<ReportsViewProps> = ({ theme = 'light' }) => {
  const isDark = theme === 'dark';

  const [dept, setDept] = useState('All Departments');
  const [year, setYear] = useState('2025-2026');
  const [sem, setSem] = useState('All Semesters');
  const [session, setSession] = useState('All Sessions');
  const [questionnaire, setQuestionnaire] = useState('All Questionnaires');
  const [groupBy, setGroupBy] = useState('Question');

  const [isRunning, setIsRunning] = useState(false);
  const [reportGenerated, setReportGenerated] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const sampleReports = [
    {
      id: 'REP-2026-01',
      name: 'Faculty Teaching Quality & Feedback Matrix',
      department: 'Computer Science & Engineering',
      format: 'CSV / Excel',
      size: '1.8 MB',
      date: '23 Jul 2026',
      data: [
        ['Faculty Name', 'Course Code', 'Teaching Score (5)', 'Punctuality (5)', 'Student Feedback Count'],
        ['Dr. Sarah Jenkins', 'CS301', '4.8', '4.9', '142'],
        ['Prof. Michael Chang', 'CS302', '4.5', '4.6', '128'],
        ['Dr. Anita Sharma', 'CS304', '4.7', '4.8', '115'],
        ['Prof. David Miller', 'CS308', '4.2', '4.1', '98']
      ]
    },
    {
      id: 'REP-2026-02',
      name: 'Infrastructure & Lab Facilities Assessment Report',
      department: 'Campus Infrastructure & Labs',
      format: 'CSV / Excel',
      size: '2.4 MB',
      date: '22 Jul 2026',
      data: [
        ['Facility Name', 'Block Location', 'Rating (1-5)', 'Maintenance Score', 'Issues Logged'],
        ['AI & High Performance Computing Lab', 'Block B - 301', '4.9', '98%', '2'],
        ['VLSI Design Lab', 'Block A - 204', '4.4', '92%', '5'],
        ['Central Library Digital Section', 'Main Building', '4.6', '95%', '1'],
        ['Seminar Hall 1', 'Block C - 101', '4.1', '88%', '8']
      ]
    },
    {
      id: 'REP-2026-03',
      name: 'Semester-Wise Comprehensive Feedback Summary',
      department: 'All Academic Departments',
      format: 'CSV / Excel',
      size: '3.1 MB',
      date: '21 Jul 2026',
      data: [
        ['Academic Year', 'Semester', 'Total Eligible Students', 'Responses Collected', 'Overall Satisfaction %'],
        ['2025-2026', 'Semester 5', '450', '398', '88.4%'],
        ['2025-2026', 'Semester 3', '480', '412', '85.8%'],
        ['2025-2026', 'Semester 1', '520', '485', '91.2%']
      ]
    }
  ];

  const handleRunReport = () => {
    setIsRunning(true);
    setTimeout(() => {
      setIsRunning(false);
      setReportGenerated(true);
    }, 600);
  };

  const handleExportCSV = (reportName: string, dataRows: string[][]) => {
    const csvContent = dataRows.map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${reportName.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadSuccess(reportName);
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handleExportCustomGeneratedCSV = () => {
    const customData = [
      ['AFMS CUSTOM REPORT EXPORT'],
      ['Department', dept],
      ['Academic Year', year],
      ['Semester', sem],
      ['Session', session],
      ['Questionnaire', questionnaire],
      ['Group By', groupBy],
      ['Generated Date', new Date().toLocaleString()],
      [''],
      ['Metric / Category', 'Sample Average Rating', 'Response Density', 'Status'],
      ['Course Delivery', '4.2 / 5', 'Very High', 'Optimal'],
      ['Teaching Methodology', '4.4 / 5', 'High', 'Optimal'],
      ['Lab Infrastructure', '3.9 / 5', 'Moderate', 'Needs Review'],
      ['Course Material Quality', '4.5 / 5', 'High', 'Optimal']
    ];

    handleExportCSV(`AFMS_${dept}_${year}_Report`, customData);
  };

  return (
    <div className="space-y-5 max-w-7xl mx-auto animate-in fade-in duration-200">
      
      {/* Toast banner */}
      {downloadSuccess && (
        <div className="fixed top-20 right-5 z-50 px-4 py-3 rounded-2xl bg-emerald-600 text-white font-bold text-xs shadow-xl flex items-center gap-2 animate-in slide-in-from-top-2 duration-200">
          <Check className="w-4 h-4 stroke-[3]" />
          <span>Exported "{downloadSuccess}" successfully!</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            Custom Reports & Data Exports
          </h1>
          <p className="text-xs font-semibold text-zinc-500 mt-0.5">
            Filter feedback parameters, generate tabular matrices, and download raw CSV datasets.
          </p>
        </div>

        <button 
          onClick={handleExportCustomGeneratedCSV}
          className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export All Raw Data</span>
        </button>
      </div>

      {/* Filter Builder Box */}
      <div className={`p-5 rounded-3xl border ${
        isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
      }`}>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Department</label>
            <select
              value={dept}
              onChange={(e) => setDept(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2.5 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Departments">All Departments</option>
              <option value="Computer Science">Computer Science</option>
              <option value="Electronics & Comm">Electronics & Comm</option>
              <option value="Mechanical Engineering">Mechanical Engineering</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Academic Year</label>
            <select
              value={year}
              onChange={(e) => setYear(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2.5 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="2025-2026">2025-2026</option>
              <option value="2024-2025">2024-2025</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Semester</label>
            <select
              value={sem}
              onChange={(e) => setSem(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2.5 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Semesters">All Semesters</option>
              <option value="Sem 1">Sem 1</option>
              <option value="Sem 3">Sem 3</option>
              <option value="Sem 5">Sem 5</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Session</label>
            <select
              value={session}
              onChange={(e) => setSession(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2.5 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Sessions">All Sessions</option>
              <option value="parents test">parents test</option>
              <option value="for faculty">for faculty</option>
              <option value="testcase">testcase</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Questionnaire</label>
            <select
              value={questionnaire}
              onChange={(e) => setQuestionnaire(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2.5 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Questionnaires">All Questionnaires</option>
              <option value="parent questionnaire">parent questionnaire</option>
              <option value="faculty form">faculty form</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Group By</label>
            <select
              value={groupBy}
              onChange={(e) => setGroupBy(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2.5 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="Question">Question</option>
              <option value="Department">Department</option>
              <option value="Faculty">Faculty</option>
            </select>
          </div>
        </div>

        {/* Big Orange Run Button */}
        <div className="mt-4 flex gap-2">
          <button 
            onClick={handleRunReport}
            disabled={isRunning}
            className="flex-1 py-3 px-6 rounded-2xl bg-[#ea580c] hover:bg-[#c2410c] text-white font-extrabold text-xs shadow-lg shadow-orange-500/20 transition-all flex items-center justify-center gap-2"
          >
            <Play className={`w-4 h-4 fill-white ${isRunning ? 'animate-spin' : ''}`} />
            <span>{isRunning ? 'Compiling Report Data...' : 'Run Report & Preview Matrix'}</span>
          </button>

          {reportGenerated && (
            <button 
              onClick={handleExportCustomGeneratedCSV}
              className="py-3 px-5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>Download Compiled CSV</span>
            </button>
          )}
        </div>
      </div>

      {/* Generated Report Live Matrix Display */}
      {reportGenerated && (
        <div className={`p-5 rounded-3xl border space-y-3 animate-in slide-in-from-top-2 duration-300 ${
          isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
        }`}>
          <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
            <div>
              <h3 className={`text-sm font-black ${isDark ? 'text-white' : 'text-zinc-900'}`}>
                Generated Matrix: {dept} ({year})
              </h3>
              <p className="text-[11px] text-zinc-400 font-medium mt-0.5">
                Grouped by {groupBy} • {sem} • {session}
              </p>
            </div>
            <span className="px-3 py-1 rounded-full text-[10px] font-black bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              Ready for Download
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className={`border-b text-[10px] uppercase font-black tracking-wider ${
                  isDark ? 'bg-[#120e0d] text-zinc-400 border-zinc-800' : 'bg-slate-50 text-zinc-500 border-zinc-200'
                }`}>
                  <th className="py-2.5 px-3">Metric / Parameter</th>
                  <th className="py-2.5 px-3">Department Scope</th>
                  <th className="py-2.5 px-3">Average Score (5)</th>
                  <th className="py-2.5 px-3">Total Submissions</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800/60 font-medium">
                <tr>
                  <td className="py-3 px-3 font-bold">Course Content & Syllabus Coverage</td>
                  <td className="py-3 px-3 text-zinc-400">{dept}</td>
                  <td className="py-3 px-3 font-black text-amber-500">4.5 / 5.0</td>
                  <td className="py-3 px-3">142</td>
                  <td className="py-3 px-3"><span className="text-emerald-500 font-bold">Optimal</span></td>
                </tr>
                <tr>
                  <td className="py-3 px-3 font-bold">Teaching Methodology & Clarity</td>
                  <td className="py-3 px-3 text-zinc-400">{dept}</td>
                  <td className="py-3 px-3 font-black text-amber-500">4.3 / 5.0</td>
                  <td className="py-3 px-3">138</td>
                  <td className="py-3 px-3"><span className="text-emerald-500 font-bold">Optimal</span></td>
                </tr>
                <tr>
                  <td className="py-3 px-3 font-bold">Lab Infrastructure & Computing Speed</td>
                  <td className="py-3 px-3 text-zinc-400">{dept}</td>
                  <td className="py-3 px-3 font-black text-amber-500">3.8 / 5.0</td>
                  <td className="py-3 px-3">120</td>
                  <td className="py-3 px-3"><span className="text-amber-500 font-bold">Needs Review</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Available Pre-built Custom Exports Table */}
      <div className="space-y-3">
        <h3 className={`text-sm font-black ${isDark ? 'text-white' : 'text-zinc-900'}`}>
          Standard Export Templates
        </h3>

        <div className="space-y-3">
          {sampleReports.map((r) => (
            <div 
              key={r.id}
              className={`p-5 rounded-3xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all hover:shadow-md ${
                isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-md bg-orange-500/10 text-orange-500 border border-orange-500/20">
                    {r.format}
                  </span>
                  <span className="text-xs text-zinc-400">• {r.id}</span>
                </div>
                <h4 className="text-sm font-extrabold">{r.name}</h4>
                <p className="text-xs text-zinc-400">Department: {r.department} • Generated: {r.date} • Size: {r.size}</p>
              </div>

              <button 
                onClick={() => handleExportCSV(r.name, r.data)}
                className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 self-start sm:self-auto transition-all shadow-xs"
              >
                <Download className="w-4 h-4" />
                <span>Export CSV</span>
              </button>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
