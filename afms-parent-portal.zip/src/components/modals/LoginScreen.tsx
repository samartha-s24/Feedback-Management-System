import React from 'react';
import { usePortal } from '../../context/PortalContext';
import { getAccentClasses } from '../../utils/theme';
import { LogOut, GraduationCap, Lock, ArrowRight, ShieldCheck } from 'lucide-react';

export const LoginScreen: React.FC = () => {
  const {
    isLogoutModalOpen,
    closeLogoutModal,
    logout,
    isLoggedOut,
    login,
    parent,
    accentTheme,
  } = usePortal();

  const accent = getAccentClasses(accentTheme);

  return (
    <>
      {/* Logout Confirmation Dialog */}
      {isLogoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center shadow-2xl space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/15 text-rose-400 flex items-center justify-center mx-auto border border-rose-500/20">
              <LogOut className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-100">Logout Confirmation</h3>
              <p className="text-xs text-slate-400">
                Are you sure you want to end your Parent Portal session?
              </p>
            </div>

            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={closeLogoutModal}
                className="w-1/2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={logout}
                className="w-1/2 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/20"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Screen Login Backdrop when Logged Out */}
      {isLoggedOut && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md animate-in fade-in duration-300">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center shadow-2xl space-y-5">
            <div className={`w-16 h-16 rounded-3xl ${accent.bgGradient} flex items-center justify-center mx-auto text-3xl shadow-lg`}>
              🎓
            </div>

            <div className="space-y-1">
              <h2 className="text-xl font-black text-slate-100">AFMS Parent Portal</h2>
              <p className="text-xs text-slate-400">Autonomous College · Student Progress & Feedback</p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-left text-xs space-y-1">
              <p className="font-semibold text-slate-200">Logged Out Account:</p>
              <p className="text-cyan-400 font-bold">{parent.name} ({parent.id})</p>
            </div>

            <button
              onClick={login}
              className={`w-full py-3 rounded-2xl text-xs font-bold ${accent.primaryBtn} flex items-center justify-center gap-2 shadow-xl active:scale-98`}
            >
              <span>Sign In to Parent Portal</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};
