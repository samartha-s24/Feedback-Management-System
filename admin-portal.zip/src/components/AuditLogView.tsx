import React, { useState } from 'react';
import { Search, Download, ShieldAlert, FileText, Activity } from 'lucide-react';

interface AuditLogViewProps {
  theme?: 'light' | 'dark' | 'system';
}

export const AuditLogView: React.FC<AuditLogViewProps> = ({ theme = 'light' }) => {
  const isDark = theme === 'dark';

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedAction, setSelectedAction] = useState('All Actions');

  const logsData = [
    {
      id: 'log-1',
      timestamp: 'Jul 23, 2026, 02:44',
      user: 'Diego Alonso (ADMIN)',
      email: 'admin.alonso@afms.edu.in',
      action: 'UPDATE',
      target: 'parent questionnaire',
      category: 'QUESTIONNAIRE',
      details: 'Updated questionnaire questions & criteria'
    },
    {
      id: 'log-2',
      timestamp: 'Jul 23, 2026, 02:40',
      user: 'Diego Alonso (ADMIN)',
      email: 'admin.alonso@afms.edu.in',
      action: 'CREATE',
      target: 'parents test',
      category: 'SESSION',
      details: 'Created new feedback session campaign'
    },
    {
      id: 'log-3',
      timestamp: 'Jul 22, 2026, 18:12',
      user: 'Diego Alonso (ADMIN)',
      email: 'admin.alonso@afms.edu.in',
      action: 'CREATE',
      target: 'welcome faculty',
      category: 'ANNOUNCEMENT',
      details: 'Published system-wide faculty announcement'
    },
    {
      id: 'log-4',
      timestamp: 'Jul 22, 2026, 14:05',
      user: 'Diego Alonso (ADMIN)',
      email: 'admin.alonso@afms.edu.in',
      action: 'EXPORT',
      target: 'CSV Analytical Summary',
      category: 'REPORTS',
      details: 'Downloaded semester performance dataset'
    }
  ];

  const handleExportLogsCSV = () => {
    const header = ['Log ID', 'Timestamp', 'User', 'Email', 'Action', 'Target', 'Category', 'Details'];
    const rows = logsData.map(l => [l.id, l.timestamp, l.user, l.email, l.action, l.target, l.category, l.details]);
    const csvContent = [header, ...rows].map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(",")).join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'AFMS_System_Audit_Logs.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filtered = logsData.filter(log => {
    const matchesSearch = log.target.toLowerCase().includes(search.toLowerCase()) ||
      log.user.toLowerCase().includes(search.toLowerCase()) ||
      log.details.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === 'All Categories' || log.category === selectedCategory;
    const matchesAction = selectedAction === 'All Actions' || log.action === selectedAction;
    return matchesSearch && matchesCategory && matchesAction;
  });

  return (
    <div className="space-y-5 max-w-7xl mx-auto animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            Audit Logs
          </h1>
          <p className="text-xs font-semibold text-zinc-500 mt-0.5">
            System event tracking, authentication events, and administrative action history.
          </p>
        </div>

        <button 
          onClick={handleExportLogsCSV}
          className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export Logs CSV</span>
        </button>
      </div>

      {/* 3 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className={`p-4 rounded-3xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black">{logsData.length}</p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">TOTAL LOGGED EVENTS</p>
        </div>

        <div className={`p-4 rounded-3xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black text-amber-500">3</p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">ADMIN ACTIONS</p>
        </div>

        <div className={`p-4 rounded-3xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black text-emerald-500">1</p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">ACTIVE SUPER ADMIN</p>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            placeholder="Search logs by user, action, target, or details..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={`w-full text-xs rounded-2xl pl-10 pr-4 py-2.5 border focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
              isDark 
                ? 'bg-[#181210] border-[#2e2623] text-white placeholder-zinc-500' 
                : 'bg-white border-zinc-200 text-zinc-900 placeholder-zinc-400 shadow-xs'
            }`}
          />
        </div>

        <select 
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className={`text-xs font-bold rounded-2xl px-4 py-2.5 border cursor-pointer w-full sm:w-auto ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-200' : 'bg-white border-zinc-200 text-zinc-800 shadow-xs'
          }`}
        >
          <option value="All Categories">All Categories</option>
          <option value="QUESTIONNAIRE">QUESTIONNAIRE</option>
          <option value="SESSION">SESSION</option>
          <option value="ANNOUNCEMENT">ANNOUNCEMENT</option>
          <option value="REPORTS">REPORTS</option>
        </select>

        <select 
          value={selectedAction}
          onChange={(e) => setSelectedAction(e.target.value)}
          className={`text-xs font-bold rounded-2xl px-4 py-2.5 border cursor-pointer w-full sm:w-auto ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-200' : 'bg-white border-zinc-200 text-zinc-800 shadow-xs'
          }`}
        >
          <option value="All Actions">All Actions</option>
          <option value="CREATE">CREATE</option>
          <option value="UPDATE">UPDATE</option>
          <option value="EXPORT">EXPORT</option>
        </select>
      </div>

      {/* Audit Log Table */}
      <div className={`rounded-3xl border overflow-hidden ${
        isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
      }`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className={`text-[10px] font-black uppercase tracking-wider border-b ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-400' : 'bg-slate-50 border-zinc-200 text-zinc-500'
              }`}>
                <th className="py-3 px-4">TIMESTAMP</th>
                <th className="py-3 px-4">USER</th>
                <th className="py-3 px-4">ACTION</th>
                <th className="py-3 px-4">TARGET</th>
                <th className="py-3 px-4">CATEGORY</th>
                <th className="py-3 px-4">DETAILS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800/60 text-xs">
              {filtered.map((log) => (
                <tr key={log.id} className="hover:bg-zinc-500/5 transition-colors">
                  <td className="py-3.5 px-4 font-mono text-[11px] text-zinc-400 whitespace-nowrap">
                    {log.timestamp}
                  </td>

                  <td className="py-3.5 px-4">
                    <p className="font-extrabold">{log.user}</p>
                    <p className="text-[10px] text-zinc-400">{log.email}</p>
                  </td>

                  <td className="py-3.5 px-4">
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-black uppercase ${
                      log.action === 'CREATE'
                        ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                        : log.action === 'EXPORT'
                        ? 'bg-blue-500/10 text-blue-500 border border-blue-500/20'
                        : 'bg-amber-500/10 text-amber-500 border border-amber-500/20'
                    }`}>
                      {log.action}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 font-bold">{log.target}</td>

                  <td className="py-3.5 px-4 font-semibold text-zinc-400 text-[11px]">
                    {log.category}
                  </td>

                  <td className="py-3.5 px-4 text-zinc-400 font-medium">
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
