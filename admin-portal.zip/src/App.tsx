import React, { useState, useEffect } from 'react';
import { 
  TabType, 
  FeedbackSession, 
  QuestionItem, 
  Announcement, 
  MetricCardData, 
  SubmissionTrendPoint, 
  SentimentDataPoint, 
  DepartmentRating, 
  AdminNotification 
} from './types';
import { 
  initialMetrics, 
  initialSessions, 
  initialQuestions, 
  initialAnnouncements, 
  initialTrendData, 
  initialSentimentData, 
  departmentRatings, 
  initialNotifications 
} from './data/mockData';
import { Header } from './components/Header';
import { NavigationSidebar } from './components/NavigationSidebar';
import { WelcomeBanner } from './components/WelcomeBanner';
import { ProfileView } from './components/ProfileView';
import { SettingsView } from './components/SettingsView';
import { MySubmissionsView } from './components/MySubmissionsView';
import { StatCard } from './components/StatCard';
import { ChartsSection } from './components/ChartsSection';
import { BottomNav } from './components/BottomNav';
import { SessionsView } from './components/SessionsView';
import { QuestionBankView } from './components/QuestionBankView';
import { AnnouncementsView } from './components/AnnouncementsView';
import { QuestionnairesView } from './components/QuestionnairesView';
import { ReportsView } from './components/ReportsView';
import { AuditLogView } from './components/AuditLogView';
import { AiAnalyticsView } from './components/AiAnalyticsView';
import { NewSessionModal } from './components/NewSessionModal';
import { NewAnnouncementModal } from './components/NewAnnouncementModal';
import { NewQuestionModal } from './components/NewQuestionModal';
import { NotificationsDrawer } from './components/NotificationsDrawer';
import { FloatingActionButton } from './components/FloatingActionButton';
import { Radio, ChevronRight, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Settings & Theme State - read saved theme from localStorage or default to 'light'
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>(() => {
    const saved = localStorage.getItem('afms_theme');
    if (saved === 'light' || saved === 'dark' || saved === 'system') {
      return saved;
    }
    return 'light';
  });
  const [accentColor, setAccentColor] = useState<'indigo' | 'teal' | 'emerald' | 'rose'>('indigo');
  const [emailNotifications, setEmailNotifications] = useState<boolean>(true);

  // Sync dark class on documentElement so Tailwind dark: classes never auto-switch unexpectedly
  useEffect(() => {
    localStorage.setItem('afms_theme', theme);
    const root = document.documentElement;

    const updateDarkClass = (isDarkActive: boolean) => {
      if (isDarkActive) {
        root.classList.add('dark');
        root.style.colorScheme = 'dark';
      } else {
        root.classList.remove('dark');
        root.style.colorScheme = 'light';
      }
    };

    if (theme === 'dark') {
      updateDarkClass(true);
    } else if (theme === 'light') {
      updateDarkClass(false);
    } else if (theme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      updateDarkClass(mediaQuery.matches);
      const listener = (e: MediaQueryListEvent) => updateDarkClass(e.matches);
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    }
  }, [theme]);

  // Main state collections
  const [metrics, setMetrics] = useState<MetricCardData[]>(initialMetrics);
  const [sessions, setSessions] = useState<FeedbackSession[]>(initialSessions);
  const [questions, setQuestions] = useState<QuestionItem[]>(initialQuestions);
  const [announcements, setAnnouncements] = useState<Announcement[]>(initialAnnouncements);
  const [trendData, setTrendData] = useState<SubmissionTrendPoint[]>(initialTrendData);
  const [sentimentData] = useState<SentimentDataPoint[]>(initialSentimentData);
  const [depts] = useState<DepartmentRating[]>(departmentRatings);
  const [notifications, setNotifications] = useState<AdminNotification[]>(initialNotifications);

  // Modals state
  const [isNewSessionOpen, setIsNewSessionOpen] = useState(false);
  const [isNewAnnouncementOpen, setIsNewAnnouncementOpen] = useState(false);
  const [isNewQuestionOpen, setIsNewQuestionOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Live Response Simulation function
  const handleSimulateResponse = (sessionId?: string) => {
    const increment = 5;

    // Update session
    setSessions((prev) =>
      prev.map((s) => {
        if (!sessionId || s.id === sessionId) {
          const newCount = s.responsesCount + increment;
          return {
            ...s,
            responsesCount: newCount,
            positivePercent: Math.min(98, s.positivePercent + 1),
          };
        }
        return s;
      })
    );

    // Update trend data
    setTrendData((prev) => {
      const last = prev[prev.length - 1];
      const updated = [...prev];
      updated[updated.length - 1] = {
        ...last,
        responses: last.responses + increment,
      };
      return updated;
    });

    // Update metrics
    setMetrics((prev) =>
      prev.map((m) => {
        if (m.id === 'total_responses') {
          const numeric = parseInt((m.value as string).replace(/,/g, '')) + increment;
          return { ...m, value: numeric.toLocaleString() };
        }
        return m;
      })
    );

    // Add Notification
    const newNotif: AdminNotification = {
      id: `NOTIF-${Date.now()}`,
      title: 'Simulated Responses Logged',
      message: `+${increment} student submissions logged in real-time.`,
      time: 'Just now',
      read: false,
      type: 'success',
    };
    setNotifications((prev) => [newNotif, ...prev]);

    showToast(`+${increment} Live Student Feedback Submissions Logged!`);
  };

  // Handler functions for adding items
  const handleCreateSession = (newSession: FeedbackSession) => {
    setSessions((prev) => [newSession, ...prev]);
    setMetrics((prev) =>
      prev.map((m) => (m.id === 'active_sessions' ? { ...m, value: (m.value as number) + 1 } : m))
    );
    showToast(`New feedback session "${newSession.title}" launched successfully!`);
  };

  const handleCreateAnnouncement = (newAnnouncement: Announcement) => {
    setAnnouncements((prev) => [newAnnouncement, ...prev]);
    setMetrics((prev) =>
      prev.map((m) => (m.id === 'announcements' ? { ...m, value: (m.value as number) + 1 } : m))
    );
    showToast(`Announcement "${newAnnouncement.title}" published!`);
  };

  const handleCreateQuestion = (newQuestion: QuestionItem) => {
    setQuestions((prev) => [newQuestion, ...prev]);
    setMetrics((prev) =>
      prev.map((m) => (m.id === 'question_bank' ? { ...m, value: (m.value as number) + 1 } : m))
    );
    showToast(`Question added to ${newQuestion.category}!`);
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast('All notifications marked as read');
  };

  // Main content depending on activeTab
  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Top Welcome Banner matching Image 1 */}
            <WelcomeBanner userName="Diego Alonso" />

            {/* Compact Metric Cards Grid */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
                  Summary Metrics
                </h3>
                <span className="text-[10px] text-zinc-400 font-medium">Tap card to inspect</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {metrics.map((card) => (
                  <StatCard
                    key={card.id}
                    data={card}
                    onClick={() => {
                      if (card.category !== 'all' && card.category !== 'overview') {
                        setActiveTab(card.category);
                      }
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Analytics Section (Charts) */}
            <ChartsSection trendData={trendData} sentimentData={sentimentData} />

            {/* Quick Active Sessions List Preview */}
            <div className={`rounded-3xl border p-5 space-y-4 shadow-sm ${
              theme === 'dark' 
                ? 'bg-[#0f172a] border-zinc-800 text-zinc-100' 
                : 'bg-white border-zinc-200 text-zinc-900'
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-extrabold flex items-center gap-2">
                    <Radio className="w-4 h-4 text-indigo-500 animate-pulse" />
                    Urgent & Active Sessions
                  </h3>
                  <p className="text-[11px] text-zinc-400">Requires Dean or IQAC action</p>
                </div>
                <button
                  onClick={() => setActiveTab('sessions')}
                  className="text-xs text-indigo-500 hover:underline flex items-center gap-0.5 font-bold"
                >
                  View All ({sessions.length}) <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="space-y-2.5">
                {sessions.slice(0, 3).map((s) => (
                  <div
                    key={s.id}
                    onClick={() => setActiveTab('sessions')}
                    className={`p-3.5 rounded-2xl border cursor-pointer flex items-center justify-between gap-3 transition-all ${
                      theme === 'dark'
                        ? 'bg-zinc-900/80 border-zinc-800 hover:border-zinc-700'
                        : 'bg-zinc-50 border-zinc-200/80 hover:border-indigo-200'
                    }`}
                  >
                    <div>
                      <span className="text-[10px] text-indigo-500 font-bold uppercase">{s.department}</span>
                      <h4 className="text-xs font-bold truncate max-w-[200px] sm:max-w-xs">{s.title}</h4>
                      <p className="text-[10px] text-zinc-400">{s.responsesCount} / {s.totalTarget} responses</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-mono font-extrabold text-amber-500">{s.averageRating} ★</span>
                      <span className="block text-[10px] text-zinc-400">{s.deadline}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'profile':
        return <ProfileView theme={theme} />;

      case 'settings':
        return (
          <SettingsView
            theme={theme}
            setTheme={setTheme}
            emailNotifications={emailNotifications}
            setEmailNotifications={setEmailNotifications}
            showToast={showToast}
          />
        );

      case 'my_submissions':
      case 'responses':
        return <MySubmissionsView theme={theme} />;

      case 'questionnaires':
        return <QuestionnairesView theme={theme} />;

      case 'reports':
        return <ReportsView theme={theme} />;

      case 'audit_log':
        return <AuditLogView theme={theme} />;

      case 'sessions':
        return (
          <div className="animate-in fade-in duration-200">
            <SessionsView
              sessions={sessions}
              onOpenNewSessionModal={() => setIsNewSessionOpen(true)}
              theme={theme}
            />
          </div>
        );

      case 'questions':
        return (
          <div className="animate-in fade-in duration-200">
            <QuestionBankView
              questions={questions}
              onOpenNewQuestionModal={() => setIsNewQuestionOpen(true)}
              searchQuery={searchQuery}
              theme={theme}
            />
          </div>
        );

      case 'announcements':
        return (
          <div className="animate-in fade-in duration-200">
            <AnnouncementsView
              announcements={announcements}
              onOpenNewAnnouncementModal={() => setIsNewAnnouncementOpen(true)}
              searchQuery={searchQuery}
              theme={theme}
            />
          </div>
        );

      case 'analytics':
        return (
          <div className="animate-in fade-in duration-200">
            <AiAnalyticsView
              theme={theme}
            />
          </div>
        );
    }
  };

  const isDark = theme === 'dark';

  return (
    <div className={`min-h-screen font-sans transition-colors duration-200 pb-24 ${
      isDark 
        ? 'bg-[#120e0d] text-zinc-100 selection:bg-orange-500/30 selection:text-orange-200' 
        : 'bg-white text-zinc-900 selection:bg-orange-500/20 selection:text-orange-900'
    }`}>
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-16 inset-x-4 z-50 max-w-md mx-auto bg-emerald-500 text-zinc-950 font-bold px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 text-xs animate-in slide-in-from-top-4 duration-200">
          <CheckCircle2 className="w-4 h-4 text-zinc-950 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Navigation Drawer Sidebar */}
      <NavigationSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLogout={() => showToast('Logged out of Admin Portal')}
        theme={theme}
      />

      {/* Top Header */}
      <Header
        notifications={notifications}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onToggleSidebar={() => setIsSidebarOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        theme={theme}
        onLogout={() => showToast('Logged out of Admin Portal')}
      />

      {/* Main Page Container */}
      <main className="max-w-5xl mx-auto px-4 py-6">
        {renderTabContent()}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        unreadAnnouncementsCount={notifications.filter(n => !n.read).length}
        theme={theme}
      />

      {/* Floating Speed Dial Action Button */}
      <FloatingActionButton
        onOpenNewSession={() => setIsNewSessionOpen(true)}
        onOpenNewQuestion={() => setIsNewQuestionOpen(true)}
        onOpenNewAnnouncement={() => setIsNewAnnouncementOpen(true)}
        onSimulateResponse={() => handleSimulateResponse()}
      />

      {/* Modals & Drawers */}
      <NewSessionModal
        isOpen={isNewSessionOpen}
        onClose={() => setIsNewSessionOpen(false)}
        onCreateSession={handleCreateSession}
      />

      <NewAnnouncementModal
        isOpen={isNewAnnouncementOpen}
        onClose={() => setIsNewAnnouncementOpen(false)}
        onCreateAnnouncement={handleCreateAnnouncement}
      />

      <NewQuestionModal
        isOpen={isNewQuestionOpen}
        onClose={() => setIsNewQuestionOpen(false)}
        onCreateQuestion={handleCreateQuestion}
      />

      <NotificationsDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllRead={handleMarkAllNotificationsRead}
      />
    </div>
  );
}
