import React from 'react';
import { 
  LayoutDashboard, 
  Radio, 
  HelpCircle, 
  Megaphone, 
  Sparkles 
} from 'lucide-react';
import { TabType } from '../types';

interface BottomNavProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  unreadAnnouncementsCount?: number;
  theme?: 'light' | 'dark' | 'system';
}

export const BottomNav: React.FC<BottomNavProps> = ({ 
  activeTab, 
  setActiveTab,
  unreadAnnouncementsCount = 0,
  theme = 'dark'
}) => {
  const isDark = theme === 'dark';

  const tabs = [
    { id: 'overview' as TabType, label: 'Overview', icon: LayoutDashboard },
    { id: 'sessions' as TabType, label: 'Sessions', icon: Radio },
    { id: 'questions' as TabType, label: 'Bank', icon: HelpCircle },
    { id: 'announcements' as TabType, label: 'Notices', icon: Megaphone, badge: unreadAnnouncementsCount },
    { id: 'analytics' as TabType, label: 'Insights', icon: Sparkles },
  ];

  return (
    <div className={`fixed bottom-0 inset-x-0 z-40 backdrop-blur-lg border-t px-2 py-2 transition-colors ${
      isDark 
        ? 'bg-[#181210]/95 border-[#2e2623] text-zinc-100' 
        : 'bg-white/95 border-zinc-200 text-zinc-900 shadow-lg'
    }`}>
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`relative flex flex-col items-center justify-center py-1.5 px-3 rounded-2xl transition-all duration-200 min-w-[60px] ${
                isActive 
                  ? 'bg-[#ea580c] text-white shadow-md shadow-orange-500/20 scale-105 font-bold' 
                  : isDark 
                    ? 'text-zinc-400 hover:text-zinc-200' 
                    : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1 -right-2 w-4 h-4 bg-rose-500 text-white font-extrabold text-[9px] rounded-full flex items-center justify-center">
                    {tab.badge}
                  </span>
                ) : null}
              </div>
              <span className={`text-[10px] font-bold mt-1 tracking-tight ${isActive ? 'text-white' : 'text-zinc-500'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
