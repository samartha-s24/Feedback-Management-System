import React from 'react';
import { usePortal } from '../context/PortalContext';
import { TopHeader } from './TopHeader';
import { BottomNav } from './BottomNav';
import { DashboardView } from './DashboardView';
import { FeedbackView } from './FeedbackView';
import { AttendanceView } from './AttendanceView';
import { HistoryView } from './HistoryView';
import { AnnouncementsView } from './AnnouncementsView';
import { ProfileView } from './ProfileView';
import { SettingsView } from './SettingsView';
import { FeedbackFormModal } from './modals/FeedbackFormModal';
import { ViewSubmissionModal } from './modals/ViewSubmissionModal';
import { EditProfileModal } from './modals/EditProfileModal';
import { SuccessModal } from './modals/SuccessModal';
import { InfoModal } from './modals/InfoModal';
import { LoginScreen } from './modals/LoginScreen';
import { Sparkles } from 'lucide-react';

export const AppContent: React.FC = () => {
  const { activeTab, toastMessage } = usePortal();

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'forms':
        return <FeedbackView />;
      case 'attendance':
        return <AttendanceView />;
      case 'announcements':
        return <AnnouncementsView />;
      case 'history':
        return <HistoryView />;
      case 'profile':
        return <ProfileView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-full flex flex-col bg-slate-950 text-slate-100">
      {/* Top Header */}
      <TopHeader />

      {/* Main View Area */}
      <main className="flex-1 p-3.5 sm:p-4 max-w-lg mx-auto w-full">
        {renderTabContent()}
      </main>

      {/* Bottom Navigation */}
      <BottomNav />

      {/* Toast Notification Alert Banner */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 max-w-xs w-full px-4 py-2.5 rounded-2xl bg-cyan-500 text-slate-950 font-bold text-xs shadow-2xl flex items-center justify-center gap-2 animate-in fade-in slide-in-from-top-3 duration-200 border border-cyan-400">
          <Sparkles className="w-4 h-4 shrink-0" />
          <span className="truncate">{toastMessage}</span>
        </div>
      )}

      {/* Modal Dialog Overlay Components */}
      <FeedbackFormModal />
      <ViewSubmissionModal />
      <EditProfileModal />
      <SuccessModal />
      <InfoModal />
      <LoginScreen />
    </div>
  );
};
