import React, { ReactNode } from 'react';
import { usePortal } from '../context/PortalContext';
import { Smartphone, Maximize2, Minimize2, Wifi, Battery, Signal } from 'lucide-react';

interface MobileFrameProps {
  children: ReactNode;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({ children }) => {
  const { isMobileDeviceFrame, toggleMobileDeviceFrame } = usePortal();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start sm:py-6 sm:px-4 font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Desktop Mode Toggle Bar */}
      <div className="hidden sm:flex items-center justify-between w-full max-w-lg mb-3 px-2 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-cyan-400" />
          <span className="font-semibold text-slate-300">AFMS Parent Portal</span>
          <span className="text-[10px] bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full text-cyan-400 font-mono">
            Mobile Screen View
          </span>
        </div>

        <button
          onClick={toggleMobileDeviceFrame}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
          title={isMobileDeviceFrame ? "Switch to Full Screen View" : "Wrap in Mobile Device Shell"}
        >
          {isMobileDeviceFrame ? (
            <>
              <Maximize2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Full Screen</span>
            </>
          ) : (
            <>
              <Minimize2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Mobile Shell</span>
            </>
          )}
        </button>
      </div>

      {/* Main Container */}
      <div
        className={`w-full transition-all duration-300 ${
          isMobileDeviceFrame
            ? 'max-w-[420px] sm:border-[8px] sm:border-slate-800 sm:rounded-[40px] sm:shadow-[0_0_60px_rgba(0,0,0,0.8)] overflow-hidden bg-slate-950 min-h-screen sm:min-h-[840px] sm:max-h-[90vh] flex flex-col relative'
            : 'max-w-2xl min-h-screen bg-slate-950 flex flex-col relative'
        }`}
      >
        {/* Simulated Mobile Status Bar (Visible in Device Shell Mode) */}
        {isMobileDeviceFrame && (
          <div className="hidden sm:flex items-center justify-between px-6 pt-3 pb-1 text-[11px] text-slate-400 font-medium select-none bg-slate-950 shrink-0 z-30">
            <span>9:41</span>
            {/* Dynamic Island / Camera Notch */}
            <div className="w-20 h-4 bg-slate-900 border border-slate-800/80 rounded-full flex items-center justify-center">
              <div className="w-2.5 h-2.5 rounded-full bg-slate-950 border border-slate-800" />
            </div>
            <div className="flex items-center gap-1.5">
              <Signal className="w-3 h-3 text-slate-300" />
              <Wifi className="w-3 h-3 text-slate-300" />
              <Battery className="w-3.5 h-3.5 text-slate-300" />
            </div>
          </div>
        )}

        {/* Dynamic App Content */}
        <div className="flex-1 overflow-y-auto relative scrollbar-none">
          {children}
        </div>

        {/* Simulated iOS Home Bar Indicator */}
        {isMobileDeviceFrame && (
          <div className="hidden sm:flex items-center justify-center py-1.5 bg-slate-950 shrink-0">
            <div className="w-32 h-1 bg-slate-700/80 rounded-full" />
          </div>
        )}
      </div>
    </div>
  );
};
