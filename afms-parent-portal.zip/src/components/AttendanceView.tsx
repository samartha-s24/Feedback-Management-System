import React from 'react';
import { usePortal } from '../context/PortalContext';
import { getAccentClasses } from '../utils/theme';
import { CheckCircle2, XCircle, Calendar, BookOpen, Percent } from 'lucide-react';

export const AttendanceView: React.FC = () => {
  const { student, attendanceDetail, accentTheme } = usePortal();
  const accent = getAccentClasses(accentTheme);

  const { present, absent, total, monthly, subjects } = attendanceDetail;
  const overallPercent = total === 0 ? 0 : Math.round((present / total) * 100);

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Page Heading */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 shadow-sm">
        <h1 className="text-lg font-bold text-slate-100">Child Attendance Record</h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Detailed academic attendance log for <span className="text-slate-200 font-semibold">{student.name}</span> ({student.prn})
        </p>
      </div>

      {/* Overview Stat Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="p-3.5 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/15 text-teal-400 flex items-center justify-center shrink-0">
            <Percent className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium block">Overall</span>
            <span className="text-xl font-extrabold text-teal-400">{overallPercent}%</span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium block">Present</span>
            <span className="text-xl font-extrabold text-emerald-400">{present}</span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center shrink-0">
            <XCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium block">Absent</span>
            <span className="text-xl font-extrabold text-rose-400">{absent}</span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center shrink-0">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium block">Total Conducted</span>
            <span className="text-xl font-extrabold text-indigo-400">{total}</span>
          </div>
        </div>
      </div>

      {/* Subject-Wise Progress Section */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-3 shadow-md">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-cyan-400" />
            <span>Subject-wise Breakdown</span>
          </h2>
          <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
            {subjects.length} Subjects
          </span>
        </div>

        <div className="space-y-3">
          {subjects.map((sub) => (
            <div key={sub.name} className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-200">{sub.name}</span>
                  {sub.code && <span className="text-[10px] text-slate-500 ml-1.5 font-mono">({sub.code})</span>}
                </div>
                <span className={`font-extrabold text-xs ${sub.percent >= 90 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {sub.percent}%
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    sub.percent >= 90 ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}
                  style={{ width: `${sub.percent}%` }}
                />
              </div>

              {sub.faculty && (
                <p className="text-[10px] text-slate-400">Faculty: {sub.faculty}</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Monthly Attendance Table */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-3 shadow-md overflow-hidden">
        <h2 className="text-sm font-bold text-slate-100">Monthly Attendance History</h2>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[10px] text-slate-400 uppercase tracking-wider bg-slate-950/80 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Month</th>
                <th className="py-2.5 px-2 text-center">Present</th>
                <th className="py-2.5 px-2 text-center">Absent</th>
                <th className="py-2.5 px-2 text-center">Total</th>
                <th className="py-2.5 px-3 text-right">% Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {monthly.map((m) => {
                const pct = m.total === 0 ? 0 : Math.round((m.present / m.total) * 100);
                return (
                  <tr key={m.month} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-semibold text-slate-200">{m.month}</td>
                    <td className="py-2.5 px-2 text-center font-medium text-emerald-400">{m.present}</td>
                    <td className="py-2.5 px-2 text-center font-medium text-rose-400">{m.absent}</td>
                    <td className="py-2.5 px-2 text-center font-medium text-slate-400">{m.total}</td>
                    <td className="py-2.5 px-3 text-right">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        pct >= 90 ? 'bg-emerald-500/15 text-emerald-400' : 'bg-amber-500/15 text-amber-400'
                      }`}>
                        {pct}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
