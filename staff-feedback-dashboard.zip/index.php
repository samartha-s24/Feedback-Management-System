<?php
/**
 * Staff Feedback Dashboard - AFMS Staff Portal
 * PHP Version
 */

session_start();

// Page routing
$validPages = ['dashboard', 'profile', 'forms', 'history', 'announcements', 'settings'];
$currentPage = isset($_GET['page']) && in_array($_GET['page'], $validPages) ? $_GET['page'] : 'dashboard';

// Initialize session state if not set
if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = [
        'name' => 'Alex Carter',
        'staff_id' => 'STAF001',
        'department' => 'Operations',
        'email' => 'lionel.messi@zeal.edu',
        'phone' => '+123 456 7890',
        'courses_assigned' => 6
    ];
}

// Site Data Array
$siteData = [
    'dashboard' => [
        'pageTitle' => 'Welcome to Zeal',
        'pageSubtitle' => 'Staff Dashboard',
        'pageDescription' => 'Keep your staff feedback on track with the latest pending forms, announcements, and priority notifications.',
        'pendingForms' => 1,
        'formsSubmitted' => 6,
        'announcements' => 3,
        'priorityTitle' => 'Teacher Communication Feedback',
        'priorityDue' => '26 Jul 2026',
        'priorityMessage' => 'This is your highest-priority feedback item to review and complete.',
        'deadlines' => [
            'Midterm Survey - due 26 Jul 2026',
            'Project Review - due 02 Aug 2026',
            'Course Evaluation - due 05 Aug 2026'
        ],
        'adminNotification' => 'Admin assigned a new feedback form. Please review and submit by the due date.'
    ],
    'forms' => [
        ['id' => 1, 'course' => 'Advanced AI', 'form' => 'Midterm Survey', 'due' => '26 Jul 2026', 'priority' => 'High'],
        ['id' => 2, 'course' => 'Database Systems', 'form' => 'Project Review', 'due' => '02 Aug 2026', 'priority' => 'Medium'],
        ['id' => 3, 'course' => 'Software Engineering', 'form' => 'Course Evaluation', 'due' => '05 Aug 2026', 'priority' => 'Normal']
    ],
    'history' => [
        ['course' => 'Advanced AI', 'form' => 'Pre-final Feedback', 'status' => 'Submitted', 'submitted' => '20 Jul 2026'],
        ['course' => 'Database Systems', 'form' => 'Lab Feedback', 'status' => 'Submitted', 'submitted' => '18 Jul 2026'],
        ['course' => 'Software Engineering', 'form' => 'Assignment Review', 'status' => 'Submitted', 'submitted' => '16 Jul 2026']
    ],
    'announcements' => [
        ['title' => 'New feedback form available', 'body' => 'A staff feedback form has been released for review and completion soon.', 'date' => '22 Jul 2026'],
        ['title' => 'Policy update', 'body' => 'Review the updated feedback submission guidelines before the next team check-in.', 'date' => '20 Jul 2026'],
        ['title' => 'System maintenance', 'body' => 'The portal will be unavailable on 28 July from 10PM to 12AM.', 'date' => '18 Jul 2026']
    ]
];

// Handle Settings Update POST Request
$toastMessage = null;
$toastType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'save_settings') {
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!$email) {
            $toastMessage = 'Please enter a valid email address.';
            $toastType = 'error';
        } elseif (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $toastMessage = 'All password fields are required.';
            $toastType = 'error';
        } elseif ($newPassword !== $confirmPassword) {
            $toastMessage = 'New password and confirm password do not match.';
            $toastType = 'error';
        } elseif (strlen($newPassword) < 6) {
            $toastMessage = 'New password must be at least 6 characters long.';
            $toastType = 'error';
        } else {
            $_SESSION['user']['email'] = $email;
            $toastMessage = 'Profile and password updated successfully!';
            $toastType = 'success';
        }
    } elseif ($action === 'submit_form') {
        $formId = $_POST['form_id'] ?? '';
        $toastMessage = 'Feedback form submitted successfully! Thank you.';
        $toastType = 'success';
    } elseif ($action === 'logout') {
        session_destroy();
        header('Location: index.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo htmlspecialchars($siteData['dashboard']['pageSubtitle']); ?> - Staff Feedback Portal</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            brand: {
              50: '#f0f9ff',
              100: '#e0f2fe',
              500: '#0ea5e9',
              600: '#0284c7',
            }
          }
        }
      }
    }
  </script>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen font-sans antialiased transition-colors duration-200">
  <div class="flex min-h-screen">
    
    <!-- Sidebar Navigation -->
    <aside class="w-72 bg-slate-900 border-r border-slate-800 p-6 hidden md:flex flex-col justify-between">
      <div>
        <div class="mb-8 rounded-[24px] bg-slate-950 p-4 border border-slate-800">
          <div class="flex items-center gap-4">
            <div>
              <p class="text-xs uppercase tracking-[0.35em] text-slate-500 font-bold">AFMS</p>
              <div class="flex items-center gap-2 mt-1">
                <span class="inline-flex h-7 w-7 items-center justify-center rounded-full bg-cyan-400 text-xs font-bold text-slate-950">A</span>
                <h2 class="text-lg font-semibold text-white">Staff Portal</h2>
              </div>
            </div>
          </div>
        </div>

        <nav class="space-y-2 text-sm text-slate-300">
          <a href="?page=dashboard" class="flex w-full items-center gap-3 rounded-[24px] <?php echo $currentPage === 'dashboard' ? 'bg-cyan-500/15 text-cyan-300 font-medium' : 'hover:bg-slate-950 text-slate-400'; ?> px-4 py-3 text-left transition-all">
            <span class="text-base">🏠</span><span>Dashboard</span>
          </a>
          <a href="?page=profile" class="flex w-full items-center gap-3 rounded-[24px] <?php echo $currentPage === 'profile' ? 'bg-cyan-500/15 text-cyan-300 font-medium' : 'hover:bg-slate-950 text-slate-400'; ?> px-4 py-3 text-left transition-all">
            <span class="text-base">👤</span><span>My Profile</span>
          </a>

          <div class="pt-6 uppercase tracking-[0.35em] text-xs font-bold text-slate-600 px-2">Feedback</div>
          <a href="?page=forms" class="flex w-full items-center gap-3 rounded-[24px] <?php echo $currentPage === 'forms' ? 'bg-cyan-500/15 text-cyan-300 font-medium' : 'hover:bg-slate-950 text-slate-400'; ?> px-4 py-3 text-left transition-all">
            <span class="text-base">📋</span><span>Available Forms</span>
          </a>
          <a href="?page=history" class="flex w-full items-center gap-3 rounded-[24px] <?php echo $currentPage === 'history' ? 'bg-cyan-500/15 text-cyan-300 font-medium' : 'hover:bg-slate-950 text-slate-400'; ?> px-4 py-3 text-left transition-all">
            <span class="text-base">📜</span><span>Submission History</span>
          </a>

          <div class="pt-6 uppercase tracking-[0.35em] text-xs font-bold text-slate-600 px-2">Updates</div>
          <a href="?page=announcements" class="flex w-full items-center gap-3 rounded-[24px] <?php echo $currentPage === 'announcements' ? 'bg-cyan-500/15 text-cyan-300 font-medium' : 'hover:bg-slate-950 text-slate-400'; ?> px-4 py-3 text-left transition-all">
            <span class="text-base">📢</span><span>Announcements</span>
          </a>

          <div class="pt-6 uppercase tracking-[0.35em] text-xs font-bold text-slate-600 px-2">System</div>
          <a href="?page=settings" class="flex w-full items-center gap-3 rounded-[24px] <?php echo $currentPage === 'settings' ? 'bg-cyan-500/15 text-cyan-300 font-medium' : 'hover:bg-slate-950 text-slate-400'; ?> px-4 py-3 text-left transition-all">
            <span class="text-base">⚙️</span><span>Settings</span>
          </a>
        </nav>
      </div>

      <form method="POST" class="mt-8">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="flex w-full items-center justify-center gap-2 rounded-[24px] bg-slate-950 border border-slate-800 px-4 py-3 text-sm text-rose-400 hover:bg-rose-500/10 hover:border-rose-500/30 transition-all font-medium">
          <span>Logout</span>
        </button>
      </form>
    </aside>

    <!-- Main Content Area -->
    <main class="flex-1 flex flex-col min-w-0">
      
      <!-- Top Navigation Header -->
      <header class="flex items-center justify-between px-6 md:px-10 py-4 bg-slate-900 border-b border-slate-800">
        <div class="flex items-center gap-3">
          <span class="text-sm font-semibold text-white tracking-wide">Autonomous College</span>
          <span class="text-slate-600">/</span>
          <span class="text-xs px-2.5 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 uppercase tracking-wider font-semibold">Staff Portal</span>
        </div>

        <div class="flex items-center gap-3">
          <button id="notifBtn" onclick="alert('You have 3 high priority notifications.')" class="relative rounded-2xl bg-slate-800 px-4 py-2 text-slate-100 hover:bg-slate-700 transition-all">
            <span class="text-lg">🔔</span>
            <span class="absolute -right-1 -top-1 inline-flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-rose-500 px-1.5 text-[11px] font-bold text-white">3</span>
          </button>
          <button id="themeToggleBtn" onclick="document.documentElement.classList.toggle('dark')" class="rounded-2xl bg-slate-800 px-4 py-2 text-slate-100 hover:bg-slate-700 text-sm transition-all">
            ☀️ Theme
          </button>
        </div>
      </header>

      <!-- PHP Banner Message -->
      <?php if ($toastMessage): ?>
        <div class="mx-6 md:mx-10 mt-6 p-4 rounded-2xl border <?php echo $toastType === 'success' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-rose-500/10 border-rose-500/30 text-rose-300'; ?> flex items-center justify-between">
          <span><?php echo htmlspecialchars($toastMessage); ?></span>
          <button onclick="this.parentElement.remove()" class="text-sm font-bold opacity-70 hover:opacity-100">&times;</button>
        </div>
      <?php endif; ?>

      <!-- Welcome Hero Section -->
      <div class="bg-slate-900 border-b border-slate-800 px-6 md:px-10 py-8">
        <div class="rounded-[32px] bg-gradient-to-r from-cyan-500/10 via-sky-500/10 to-transparent border border-cyan-500/20 p-6 text-slate-100">
          <div class="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div class="flex items-center gap-6">
              <div>
                <div class="flex items-center gap-3">
                  <span class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-cyan-400 text-sm font-bold text-slate-950">A</span>
                  <h1 class="text-3xl md:text-4xl font-bold text-slate-100">Welcome Back, <?php echo htmlspecialchars($_SESSION['user']['name']); ?></h1>
                </div>
                <p class="mt-3 text-slate-300 max-w-3xl leading-relaxed">
                  <?php echo htmlspecialchars($siteData['dashboard']['pageDescription']); ?>
                </p>
              </div>
            </div>
          </div>
        </div>

        <div class="mt-8 grid gap-4 sm:grid-cols-3">
          <div class="rounded-[24px] bg-slate-950 p-5 border border-slate-800">
            <div class="flex items-center gap-4">
              <div class="grid h-12 w-12 place-items-center rounded-2xl bg-cyan-500/10 text-cyan-300 text-xl">
                <span>📝</span>
              </div>
              <div>
                <p class="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Pending feedback</p>
                <p class="mt-1 text-3xl font-bold text-white"><?php echo $siteData['dashboard']['pendingForms']; ?></p>
              </div>
            </div>
          </div>

          <div class="rounded-[24px] bg-slate-950 p-5 border border-slate-800">
            <div class="flex items-center gap-4">
              <div class="grid h-12 w-12 place-items-center rounded-2xl bg-emerald-500/10 text-emerald-300 text-xl">
                <span>✅</span>
              </div>
              <div>
                <p class="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Forms submitted</p>
                <p class="mt-1 text-3xl font-bold text-white"><?php echo $siteData['dashboard']['formsSubmitted']; ?></p>
              </div>
            </div>
          </div>

          <div class="rounded-[24px] bg-slate-950 p-5 border border-slate-800">
            <div class="flex items-center gap-4">
              <div class="grid h-12 w-12 place-items-center rounded-2xl bg-rose-500/10 text-rose-300 text-xl">
                <span>📢</span>
              </div>
              <div>
                <p class="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Announcements</p>
                <p class="mt-1 text-3xl font-bold text-white"><?php echo count($siteData['announcements']); ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Dynamic Content Views -->
      <div class="p-6 md:p-10 space-y-6">

        <?php if ($currentPage === 'dashboard'): ?>
          <!-- DASHBOARD VIEW -->
          <div class="grid gap-6 xl:grid-cols-[1.7fr_1fr]">
            <div class="rounded-[32px] bg-slate-950 p-6 shadow-xl border border-slate-800 space-y-6">
              <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-6">
                <div>
                  <p class="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Priority Parent Feedback</p>
                  <h2 class="mt-2 text-2xl font-bold text-white"><?php echo htmlspecialchars($siteData['dashboard']['priorityTitle']); ?></h2>
                  <p class="mt-1 text-sm text-slate-400">Due: <?php echo htmlspecialchars($siteData['dashboard']['priorityDue']); ?></p>
                </div>
                <a href="?page=forms" class="rounded-full bg-cyan-500 px-6 py-2.5 text-sm font-semibold text-slate-950 hover:bg-cyan-400 transition-all shadow-lg shadow-cyan-500/20">
                  Start Now
                </a>
              </div>

              <p class="text-slate-300 text-sm leading-relaxed">
                <?php echo htmlspecialchars($siteData['dashboard']['priorityMessage']); ?>
              </p>

              <div class="rounded-[24px] bg-slate-900 p-5 border border-slate-800">
                <p class="text-xs font-bold uppercase tracking-[0.2em] text-slate-500">Deadline Status</p>
                <ul class="mt-4 space-y-3 text-slate-300 text-sm">
                  <?php foreach ($siteData['dashboard']['deadlines'] as $deadline): ?>
                    <li class="flex items-center gap-3">
                      <span class="h-2 w-2 rounded-full bg-cyan-400"></span>
                      <span><?php echo htmlspecialchars($deadline); ?></span>
                    </li>
                  <?php endforeach; ?>
                </ul>
              </div>

              <?php if (!empty($siteData['dashboard']['adminNotification'])): ?>
                <div class="rounded-[24px] bg-emerald-500/10 p-5 text-slate-100 border border-emerald-500/30">
                  <p class="text-xs font-bold uppercase tracking-[0.2em] text-emerald-400">Admin Notification</p>
                  <p class="mt-2 text-sm text-emerald-200"><?php echo htmlspecialchars($siteData['dashboard']['adminNotification']); ?></p>
                </div>
              <?php endif; ?>

              <div class="rounded-[28px] bg-slate-900 p-5 border border-slate-800">
                <div class="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p class="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">New Feedback Form</p>
                    <p class="mt-2 text-white font-semibold">School Facilities & Parent Experience Feedback</p>
                  </div>
                  <a href="?page=forms" class="rounded-full bg-cyan-500 px-5 py-2 text-sm font-semibold text-slate-950 hover:bg-cyan-400 transition-all">
                    Start Now
                  </a>
                </div>
                <p class="mt-3 text-xs text-slate-400">Due: 30 Jul 2026</p>
              </div>
            </div>

            <!-- Right Column -->
            <div class="space-y-6">
              <div class="rounded-[32px] bg-slate-950 p-6 shadow-xl border border-slate-800">
                <p class="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Feedback Completion</p>
                <h2 class="mt-2 text-2xl font-bold text-white">Completion Progress</h2>
                <div class="mt-6 flex items-center justify-center rounded-[28px] bg-slate-900 p-8 border border-slate-800">
                  <div class="text-center">
                    <div class="relative inline-flex items-center justify-center">
                      <span class="text-5xl font-extrabold text-white">14%</span>
                    </div>
                    <p class="mt-3 text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">6 of 7 Forms Done</p>
                  </div>
                </div>
              </div>

              <div class="rounded-[32px] bg-slate-950 p-6 shadow-xl border border-slate-800">
                <div class="flex items-center justify-between">
                  <div>
                    <p class="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Latest Announcements</p>
                    <h2 class="mt-1 text-xl font-bold text-white">Updates</h2>
                  </div>
                  <a href="?page=announcements" class="rounded-full bg-slate-800 px-4 py-1.5 text-xs font-semibold text-slate-300 hover:bg-slate-700">View All</a>
                </div>
                <div class="mt-4 space-y-3">
                  <?php foreach (array_slice($siteData['announcements'], 0, 2) as $item): ?>
                    <div class="rounded-[20px] bg-slate-900 p-4 border border-slate-800">
                      <h3 class="text-sm font-semibold text-white"><?php echo htmlspecialchars($item['title']); ?></h3>
                      <p class="mt-1 text-xs text-slate-400 leading-relaxed"><?php echo htmlspecialchars($item['body']); ?></p>
                    </div>
                  <?php endforeach; ?>
                </div>
              </div>
            </div>
          </div>

        <?php elseif ($currentPage === 'profile'): ?>
          <!-- PROFILE VIEW -->
          <div class="rounded-[32px] bg-slate-950 p-8 shadow-xl border border-slate-800 space-y-6">
            <div>
              <p class="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">My Profile</p>
              <h2 class="mt-2 text-3xl font-bold text-white"><?php echo htmlspecialchars($_SESSION['user']['name']); ?></h2>
              <p class="mt-1 text-slate-400 text-sm">Staff ID: <?php echo htmlspecialchars($_SESSION['user']['staff_id']); ?> • <?php echo htmlspecialchars($_SESSION['user']['department']); ?></p>
            </div>

            <div class="grid gap-4 sm:grid-cols-2 pt-4">
              <div class="rounded-[24px] bg-slate-900 p-5 border border-slate-800">
                <p class="text-xs font-bold uppercase tracking-[0.1em] text-slate-400">Email Address</p>
                <p class="mt-2 text-white font-medium"><?php echo htmlspecialchars($_SESSION['user']['email']); ?></p>
              </div>
              <div class="rounded-[24px] bg-slate-900 p-5 border border-slate-800">
                <p class="text-xs font-bold uppercase tracking-[0.1em] text-slate-400">Phone Number</p>
                <p class="mt-2 text-white font-medium"><?php echo htmlspecialchars($_SESSION['user']['phone']); ?></p>
              </div>
              <div class="rounded-[24px] bg-slate-900 p-5 border border-slate-800">
                <p class="text-xs font-bold uppercase tracking-[0.1em] text-slate-400">Assigned Courses</p>
                <p class="mt-2 text-white font-medium"><?php echo htmlspecialchars($_SESSION['user']['courses_assigned']); ?> Active Courses</p>
              </div>
              <div class="rounded-[24px] bg-slate-900 p-5 border border-slate-800">
                <p class="text-xs font-bold uppercase tracking-[0.1em] text-slate-400">Pending Feedback Tasks</p>
                <p class="mt-2 text-cyan-400 font-medium"><?php echo $siteData['dashboard']['pendingForms']; ?> Pending</p>
              </div>
            </div>
          </div>

        <?php elseif ($currentPage === 'forms'): ?>
          <!-- FORMS VIEW -->
          <div class="rounded-[32px] bg-slate-950 p-8 shadow-xl border border-slate-800">
            <p class="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Available Forms</p>
            <h2 class="mt-2 text-3xl font-bold text-white">Open Feedback Surveys</h2>
            <div class="mt-6 overflow-x-auto">
              <table class="min-w-full divide-y divide-slate-800 text-left text-slate-100">
                <thead class="bg-slate-900 text-xs font-bold uppercase text-slate-400">
                  <tr>
                    <th class="px-6 py-4">Course</th>
                    <th class="px-6 py-4">Form Title</th>
                    <th class="px-6 py-4">Due Date</th>
                    <th class="px-6 py-4">Action</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60 bg-slate-950">
                  <?php foreach ($siteData['forms'] as $form): ?>
                    <tr class="hover:bg-slate-900/50 transition-colors">
                      <td class="px-6 py-4 font-semibold text-white"><?php echo htmlspecialchars($form['course']); ?></td>
                      <td class="px-6 py-4 text-slate-300"><?php echo htmlspecialchars($form['form']); ?></td>
                      <td class="px-6 py-4 text-slate-400 text-sm"><?php echo htmlspecialchars($form['due']); ?></td>
                      <td class="px-6 py-4">
                        <form method="POST">
                          <input type="hidden" name="action" value="submit_form">
                          <input type="hidden" name="form_id" value="<?php echo $form['id']; ?>">
                          <button type="submit" class="rounded-full bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 px-4 py-1.5 text-xs font-semibold hover:bg-cyan-500 hover:text-slate-950 transition-all">
                            Fill Form
                          </button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>

        <?php elseif ($currentPage === 'history'): ?>
          <!-- HISTORY VIEW -->
          <div class="rounded-[32px] bg-slate-950 p-8 shadow-xl border border-slate-800">
            <p class="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Submission History</p>
            <h2 class="mt-2 text-3xl font-bold text-white">Recent Feedback Submissions</h2>
            <div class="mt-6 overflow-x-auto">
              <table class="min-w-full divide-y divide-slate-800 text-left text-slate-100">
                <thead class="bg-slate-900 text-xs font-bold uppercase text-slate-400">
                  <tr>
                    <th class="px-6 py-4">Course</th>
                    <th class="px-6 py-4">Form</th>
                    <th class="px-6 py-4">Status</th>
                    <th class="px-6 py-4">Submitted Date</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60 bg-slate-950">
                  <?php foreach ($siteData['history'] as $item): ?>
                    <tr class="hover:bg-slate-900/50 transition-colors">
                      <td class="px-6 py-4 font-semibold text-white"><?php echo htmlspecialchars($item['course']); ?></td>
                      <td class="px-6 py-4 text-slate-300"><?php echo htmlspecialchars($item['form']); ?></td>
                      <td class="px-6 py-4">
                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          ✓ <?php echo htmlspecialchars($item['status']); ?>
                        </span>
                      </td>
                      <td class="px-6 py-4 text-slate-400 text-sm"><?php echo htmlspecialchars($item['submitted']); ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>

        <?php elseif ($currentPage === 'announcements'): ?>
          <!-- ANNOUNCEMENTS VIEW -->
          <div class="rounded-[32px] bg-slate-950 p-8 shadow-xl border border-slate-800">
            <p class="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Announcements</p>
            <h2 class="mt-2 text-3xl font-bold text-white">Official Notifications & Updates</h2>
            <div class="mt-6 space-y-4">
              <?php foreach ($siteData['announcements'] as $item): ?>
                <div class="rounded-[24px] bg-slate-900 p-6 border border-slate-800">
                  <div class="flex items-center justify-between">
                    <h3 class="text-lg font-bold text-white"><?php echo htmlspecialchars($item['title']); ?></h3>
                    <span class="text-xs text-slate-500 font-mono"><?php echo htmlspecialchars($item['date']); ?></span>
                  </div>
                  <p class="mt-3 text-slate-300 text-sm leading-relaxed"><?php echo htmlspecialchars($item['body']); ?></p>
                </div>
              <?php endforeach; ?>
            </div>
          </div>

        <?php elseif ($currentPage === 'settings'): ?>
          <!-- SETTINGS VIEW -->
          <div class="rounded-[32px] bg-slate-950 p-8 shadow-xl border border-slate-800">
            <p class="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Settings</p>
            <h2 class="mt-2 text-3xl font-bold text-white">Account & Password Security</h2>
            
            <form method="POST" class="mt-8 space-y-6 max-w-2xl">
              <input type="hidden" name="action" value="save_settings">
              
              <label class="block rounded-[24px] bg-slate-900 p-5 border border-slate-800">
                <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Email Address <span class="text-rose-400">*</span></span>
                <input type="email" name="email" required value="<?php echo htmlspecialchars($_SESSION['user']['email']); ?>" class="mt-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-500 transition-colors" />
              </label>

              <label class="block rounded-[24px] bg-slate-900 p-5 border border-slate-800">
                <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Current Password <span class="text-rose-400">*</span></span>
                <input type="password" name="current_password" required placeholder="Enter current password" class="mt-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-500 transition-colors" />
              </label>

              <div class="grid gap-6 sm:grid-cols-2">
                <label class="block rounded-[24px] bg-slate-900 p-5 border border-slate-800">
                  <span class="text-xs font-bold uppercase tracking-wider text-slate-400">New Password <span class="text-rose-400">*</span></span>
                  <input type="password" name="new_password" required placeholder="Enter new password" class="mt-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-500 transition-colors" />
                </label>

                <label class="block rounded-[24px] bg-slate-900 p-5 border border-slate-800">
                  <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Confirm New Password <span class="text-rose-400">*</span></span>
                  <input type="password" name="confirm_password" required placeholder="Confirm new password" class="mt-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-500 transition-colors" />
                </label>
              </div>

              <button type="submit" class="mt-4 inline-flex items-center justify-center rounded-[24px] bg-cyan-500 px-8 py-3.5 text-sm font-semibold text-slate-950 hover:bg-cyan-400 transition-all shadow-lg shadow-cyan-500/20">
                Save Changes
              </button>
            </form>
          </div>
        <?php endif; ?>

      </div>
    </main>
  </div>
</body>
</html>
