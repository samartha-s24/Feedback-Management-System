import React from 'react';
import { usePortal } from '../context/PortalContext';
import { getAccentClasses } from '../utils/theme';
import { COMING_SOON_FORMS } from '../data/initialData';
import { ClipboardCheck, Clock, ShieldAlert, Sparkles, ArrowRight } from 'lucide-react';

export const FeedbackView: React.FC = () => {
  const { activeForms, submissions, openFeedbackModal, accentTheme } = usePortal();
  const accent = getAccentClasses(accentTheme);

  const pendingForms = activeForms.filter((f) => !submissions.some((s) => s.formId === f.id));
  const completedForms = activeForms.filter((f) => submissions.some((s) => s.formId === f.id));

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Header */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 shadow-sm">
        <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <ClipboardCheck className="w-5 h-5 text-cyan-400" />
          <span>Available Feedback Forms</span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Your feedback directly drives improvements in teaching and school facilities.
        </p>
      </div>

      {/* Active Pending Forms */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
          Active Forms ({pendingForms.length})
        </h2>

        {pendingForms.length === 0 ? (
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 text-center space-y-2">
            <span className="text-3xl">✅</span>
            <p className="text-sm font-bold text-slate-200">All Assigned Feedback Submitted</p>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              You have completed all active forms. Thank you! Check your Submission History for records.
            </p>
          </div>
        ) : (
          pendingForms.map((form) => (
            <div
              key={form.id}
              className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3 shadow-md"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-xl shrink-0">
                    {form.icon}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-100 leading-snug">{form.title}</h3>
                    <p className="text-[11px] text-slate-400">By: {form.assignedBy}</p>
                  </div>
                </div>
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-bold border border-emerald-500/20 shrink-0">
                  New
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
                <div>
                  <span className="text-slate-500 block">Due Date</span>
                  <span className="font-semibold text-slate-200">{form.dueDate}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Est. Time</span>
                  <span className="font-semibold text-slate-200">{form.estTime}</span>
                </div>
              </div>

              <button
                onClick={() => openFeedbackModal(form.id)}
                className={`w-full py-2.5 rounded-xl text-xs font-bold ${accent.primaryBtn} flex items-center justify-center gap-2 active:scale-98`}
              >
                <span>Give Feedback</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Completed Active Forms */}
      {completedForms.length > 0 && (
        <div className="space-y-3 pt-2">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
            Completed Active Forms ({completedForms.length})
          </h2>
          {completedForms.map((form) => (
            <div
              key={form.id}
              className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 opacity-75 flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3">
                <span className="text-xl">{form.icon}</span>
                <div>
                  <p className="text-xs font-semibold text-slate-300 line-through">{form.title}</p>
                  <p className="text-[10px] text-emerald-400 font-medium">✓ Feedback Submitted</p>
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-bold">
                Done
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Coming Soon Forms */}
      <div className="space-y-3 pt-2">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
          Upcoming Feedback Surveys
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {COMING_SOON_FORMS.map((item) => (
            <div
              key={item.id}
              className="p-3.5 rounded-xl bg-slate-900/40 border border-slate-800/60 flex items-center justify-between gap-3 opacity-60"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Clock className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-slate-300 truncate">{item.title}</p>
                  <p className="text-[10px] text-slate-500">Scheduled: {item.est}</p>
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 shrink-0">
                Soon
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
