export type Priority = 'high' | 'medium' | 'low';

export interface ParentInfo {
  name: string;
  id: string;
  email: string;
  mobile: string;
  address: string;
  relationship: string;
}

export interface StudentInfo {
  name: string;
  prn: string;
  yearLevel: string;
  division: string;
  department: string;
  academicYear: string;
  attendance: string;
}

export interface Question {
  id: string;
  type: 'star' | 'yesno';
  text: string;
}

export interface FeedbackForm {
  id: string;
  icon: string;
  title: string;
  assignedBy: string;
  dueDate: string;
  estTime: string;
  autofill: (keyof ParentInfo | keyof StudentInfo)[];
  questions: Question[];
  suggestionsPrompt: string;
}

export interface SubmissionAnswer {
  text: string;
  answer: string | null;
}

export interface SubmissionRecord {
  id: string;
  formId: string;
  title: string;
  parentName: string;
  studentName: string;
  date: string;
  time: string;
  status: 'Submitted' | 'Under Review';
  answers: Record<string, SubmissionAnswer>;
  suggestions: string;
}

export interface Announcement {
  id: string;
  icon: string;
  title: string;
  date: string;
  priority: Priority;
  desc: string;
  pdf?: boolean;
}

export interface MonthlyAttendance {
  month: string;
  present: number;
  absent: number;
  total: number;
}

export interface SubjectAttendance {
  name: string;
  percent: number;
  code?: string;
  faculty?: string;
}

export interface AttendanceDetail {
  present: number;
  absent: number;
  total: number;
  monthly: MonthlyAttendance[];
  subjects: SubjectAttendance[];
}

export type TabType = 'dashboard' | 'forms' | 'attendance' | 'announcements' | 'history' | 'profile' | 'settings';

export type AccentTheme = 'blue' | 'teal' | 'emerald' | 'rose' | 'purple';

export interface NotificationSettings {
  feedback: boolean;
  announcement: boolean;
  fee: boolean;
  exam: boolean;
}
