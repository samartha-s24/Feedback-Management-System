import React, { useState } from 'react';
import { usePortal } from '../../context/PortalContext';
import { getAccentClasses } from '../../utils/theme';
import { X, UserCheck } from 'lucide-react';

export const EditProfileModal: React.FC = () => {
  const { isEditProfileOpen, closeEditProfileModal, parent, updateParent, accentTheme } = usePortal();

  const [name, setName] = useState(parent.name);
  const [email, setEmail] = useState(parent.email);
  const [mobile, setMobile] = useState(parent.mobile);
  const [address, setAddress] = useState(parent.address);

  if (!isEditProfileOpen) return null;

  const accent = getAccentClasses(accentTheme);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateParent({ name, email, mobile, address });
    closeEditProfileModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/60">
          <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-cyan-400" />
            <span>Edit Parent Profile</span>
          </h3>
          <button
            onClick={closeEditProfileModal}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-3 text-xs">
          <div>
            <label className="text-slate-400 font-medium block mb-1">Parent Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Mobile Phone Number</label>
            <input
              type="tel"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              required
              className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Residential Address</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              required
              className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={closeEditProfileModal}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-5 py-2 rounded-xl font-bold ${accent.primaryBtn}`}
            >
              Save Profile
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
