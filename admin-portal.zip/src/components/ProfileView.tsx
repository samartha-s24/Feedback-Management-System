import React, { useState } from 'react';
import { 
  User, 
  Mail, 
  Phone, 
  Building2, 
  Briefcase, 
  Calendar, 
  MapPin, 
  UserCheck, 
  Award,
  CheckCircle2,
  ShieldCheck,
  Shield,
  Key,
  Lock,
  Download,
  Copy,
  Check,
  Edit3,
  Activity,
  FileSpreadsheet,
  Save,
  X
} from 'lucide-react';

interface ProfileViewProps {
  theme?: 'light' | 'dark' | 'system';
}

export const ProfileView: React.FC<ProfileViewProps> = ({ theme = 'light' }) => {
  const isDark = theme === 'dark';

  const [copiedToken, setCopiedToken] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Editable Admin details state
  const [adminDetails, setAdminDetails] = useState({
    name: 'Diego Alonso',
    adminId: 'ADM-2024-9901',
    role: 'Chief System Administrator & Quality Controller',
    email: 'admin.alonso@afms.edu.in',
    phone: '+91 98765 43210',
    dept: 'Office of Academic Quality & Accreditation',
    accessLevel: 'Tier-1 Super Admin (Full Read/Write)',
    office: 'Administrative Block A - Room 101',
    emergencyContact: 'Dr. Sarah Jenkins (Dean of Academic Affairs)',
    lastLogin: '23 Jul 2026, 21:30 PST (IP: 192.168.1.104)'
  });

  const [editForm, setEditForm] = useState({ ...adminDetails });

  const handleCopyToken = () => {
    navigator.clipboard.writeText('AFMS-SYS-KEY-9901-X8F92A-SECURE');
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  const handleDownloadProfilePDF = () => {
    const content = `AFMS ADMIN PROFILE SUMMARY
=========================================
Admin Name: ${adminDetails.name}
Admin ID: ${adminDetails.adminId}
Role: ${adminDetails.role}
Email: ${adminDetails.email}
Phone: ${adminDetails.phone}
Department: ${adminDetails.dept}
Access Level: ${adminDetails.accessLevel}
Office Location: ${adminDetails.office}
2FA Status: Enforced (Hardware Key + TOTP)
Last Authentication: ${adminDetails.lastLogin}
Generated On: ${new Date().toLocaleString()}
=========================================`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `AFMS_Admin_Profile_${adminDetails.adminId}.txt`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminDetails({ ...editForm });
    setIsEditModalOpen(false);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-in fade-in duration-200">
      
      {/* Top Header & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            Admin Profile & Access Control
          </h1>
          <p className="text-xs font-semibold text-zinc-500 mt-0.5">
            Essential administrative credentials, system access privileges, and security details.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button 
            onClick={() => setIsEditModalOpen(true)}
            className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Edit Admin Details</span>
          </button>

          <button 
            onClick={handleDownloadProfilePDF}
            className="px-4 py-2.5 rounded-2xl bg-[#ea580c] hover:bg-[#c2410c] text-white font-bold text-xs shadow-lg shadow-orange-500/20 transition-all flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>Export Profile Summary</span>
          </button>
        </div>
      </div>

      {/* Main Administrative Profile Card */}
      <div className={`rounded-3xl border p-6 sm:p-8 shadow-2xl relative overflow-hidden ${
        isDark 
          ? 'bg-[#181210] border-[#2e2623] text-zinc-100' 
          : 'bg-white border-zinc-200 text-zinc-900'
      }`}>
        
        {/* Subtle accent backdrop glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-orange-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header Row with Avatar & Title */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 sm:gap-6 pb-6 border-b border-zinc-200 dark:border-zinc-800/80">
          
          {/* Admin Avatar Image */}
          <div className="relative shrink-0">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300"
              alt={adminDetails.name}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl object-cover border-4 border-orange-500/40 shadow-xl"
            />
            <span className="absolute -bottom-1 -right-1 p-1 bg-emerald-500 border-2 border-white dark:border-[#181210] rounded-full text-white" title="Active Admin Session">
              <ShieldCheck className="w-4 h-4" />
            </span>
          </div>

          {/* User Main Title Info */}
          <div className="space-y-2 text-center sm:text-left flex-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
                {adminDetails.name}
              </h1>
              <span className="px-3 py-1 rounded-full text-[10px] font-black bg-orange-500/10 text-orange-500 border border-orange-500/20 flex items-center gap-1">
                <Shield className="w-3 h-3 fill-orange-500/20" />
                SYSTEM SUPER ADMIN
              </span>
            </div>

            <p className="text-xs sm:text-sm font-extrabold text-orange-500 flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <span>{adminDetails.role}</span>
              <span className="text-zinc-400">•</span>
              <span className="font-mono">{adminDetails.adminId}</span>
            </p>

            {/* Quick Security Badge row */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
              <span className="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                2FA Hardware Authenticated
              </span>
              <span className="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-blue-500/10 text-blue-500 border border-blue-500/20 flex items-center gap-1">
                <Key className="w-3 h-3" />
                Root API Access
              </span>
            </div>
          </div>
        </div>

        {/* Section Title */}
        <div className="pt-6 pb-4">
          <div className="flex items-center gap-2 text-orange-500 text-xs font-black uppercase tracking-wider">
            <User className="w-4 h-4" />
            <span>ESSENTIAL ADMINISTRATIVE CREDENTIALS & INFORMATION</span>
          </div>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-8 pt-2">
          
          {/* Full Name */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-zinc-400" />
              ADMINISTRATOR NAME
            </p>
            <p className={`text-sm font-extrabold ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {adminDetails.name}
            </p>
          </div>

          {/* Employee / Admin ID */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-zinc-400" />
              SYSTEM ADMIN ID
            </p>
            <p className="text-sm font-black text-orange-500 font-mono">
              {adminDetails.adminId}
            </p>
          </div>

          {/* Official Email */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-zinc-400" />
              OFFICIAL EMAIL
            </p>
            <p className={`text-sm font-bold underline decoration-zinc-400 underline-offset-4 ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {adminDetails.email}
            </p>
          </div>

          {/* Phone Number */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-zinc-400" />
              DIRECT PHONE NUMBER
            </p>
            <p className={`text-sm font-bold ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {adminDetails.phone}
            </p>
          </div>

          {/* Department */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-zinc-400" />
              ADMINISTRATIVE DEPARTMENT
            </p>
            <p className={`text-sm font-bold ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {adminDetails.dept}
            </p>
          </div>

          {/* Designation & Access Scope */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-zinc-400" />
              DESIGNATION & ROLE
            </p>
            <p className={`text-sm font-bold ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {adminDetails.role}
            </p>
          </div>

          {/* Access Level */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-zinc-400" />
              ACCESS CLEARANCE LEVEL
            </p>
            <p className="text-sm font-extrabold text-emerald-500 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              {adminDetails.accessLevel}
            </p>
          </div>

          {/* Office Location */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-zinc-400" />
              OFFICE LOCATION
            </p>
            <p className={`text-sm font-bold ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {adminDetails.office}
            </p>
          </div>

          {/* Emergency Contact */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-zinc-400" />
              EMERGENCY ESCALATION CONTACT
            </p>
            <p className={`text-sm font-bold ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {adminDetails.emergencyContact}
            </p>
          </div>

          {/* Active Session Token */}
          <div className="space-y-1 border-b border-zinc-200 dark:border-zinc-800/60 pb-3">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-zinc-400" />
              SECURITY TOKEN
            </p>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold bg-slate-100 dark:bg-zinc-800 px-2.5 py-1 rounded-lg text-zinc-600 dark:text-zinc-300">
                AFMS-SYS-KEY-9901-X8F92A
              </span>
              <button 
                onClick={handleCopyToken}
                className="p-1 rounded bg-slate-200 dark:bg-zinc-800 hover:bg-slate-300 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-200 transition-colors"
                title="Copy Token"
              >
                {copiedToken ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* Security & Access Privilege Table */}
      <div className={`p-6 rounded-3xl border space-y-4 ${
        isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
      }`}>
        <div className="flex items-center justify-between">
          <h3 className={`text-sm font-black flex items-center gap-2 ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            <Shield className="w-4 h-4 text-orange-500" />
            <span>Administrative Privileges Matrix</span>
          </h3>
          <span className="text-[11px] font-bold text-emerald-500 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
            All Systems Operational
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { module: 'Questionnaire Builder', status: 'Full Control', desc: 'Create, edit, publish & delete questionnaires' },
            { module: 'Feedback Campaigns', status: 'Full Control', desc: 'Manage active sessions, generate QR codes' },
            { module: 'Question Bank', status: 'Full Control', desc: 'Add/Remove questions across all categories' },
            { module: 'AI Analytics & Reports', status: 'Full Control', desc: 'Generate custom CSV/PDF reports & insights' },
            { module: 'Audit Logging', status: 'Full Control', desc: 'View complete system activity logs' },
            { module: 'System Settings', status: 'Full Control', desc: 'Configure academic years, departments & security' }
          ].map((item, idx) => (
            <div key={idx} className={`p-3.5 rounded-2xl border ${
              isDark ? 'bg-[#120e0d] border-[#221c19]' : 'bg-slate-50 border-zinc-200/80'
            }`}>
              <div className="flex items-center justify-between mb-1">
                <span className={`text-xs font-black ${isDark ? 'text-white' : 'text-zinc-900'}`}>{item.module}</span>
                <span className="text-[9px] font-black uppercase tracking-wider text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded">
                  {item.status}
                </span>
              </div>
              <p className="text-[10px] text-zinc-400 font-medium">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Edit Admin Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className={`w-full max-w-lg rounded-3xl p-6 border shadow-2xl animate-in zoom-in-95 duration-150 ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-white' : 'bg-white border-zinc-200 text-zinc-900'
          }`}>
            <div className="flex items-center justify-between pb-4 border-b border-zinc-200 dark:border-zinc-800">
              <h3 className="text-base font-black flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-orange-500" />
                Edit Admin Information
              </h3>
              <button 
                onClick={() => setIsEditModalOpen(false)}
                className="p-1.5 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3 pt-4">
              <div>
                <label className="block text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">Full Name</label>
                <input
                  type="text"
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDark ? 'bg-[#120e0d] border-[#221c19] text-white' : 'bg-slate-50 border-zinc-200 text-zinc-900'
                  }`}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">Admin ID</label>
                  <input
                    type="text"
                    value={editForm.adminId}
                    onChange={(e) => setEditForm({ ...editForm, adminId: e.target.value })}
                    className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border focus:outline-none ${
                      isDark ? 'bg-[#120e0d] border-[#221c19] text-orange-400' : 'bg-slate-50 border-zinc-200 text-orange-600'
                    }`}
                    required
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">Phone</label>
                  <input
                    type="text"
                    value={editForm.phone}
                    onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                    className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border focus:outline-none ${
                      isDark ? 'bg-[#120e0d] border-[#221c19] text-white' : 'bg-slate-50 border-zinc-200 text-zinc-900'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">Official Email</label>
                <input
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border focus:outline-none ${
                    isDark ? 'bg-[#120e0d] border-[#221c19] text-white' : 'bg-slate-50 border-zinc-200 text-zinc-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">Role Title</label>
                <input
                  type="text"
                  value={editForm.role}
                  onChange={(e) => setEditForm({ ...editForm, role: e.target.value })}
                  className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border focus:outline-none ${
                    isDark ? 'bg-[#120e0d] border-[#221c19] text-white' : 'bg-slate-50 border-zinc-200 text-zinc-900'
                  }`}
                />
              </div>

              <div>
                <label className="block text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">Department</label>
                <input
                  type="text"
                  value={editForm.dept}
                  onChange={(e) => setEditForm({ ...editForm, dept: e.target.value })}
                  className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border focus:outline-none ${
                    isDark ? 'bg-[#120e0d] border-[#221c19] text-white' : 'bg-slate-50 border-zinc-200 text-zinc-900'
                  }`}
                />
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2.5 rounded-2xl border border-zinc-300 dark:border-zinc-700 text-xs font-bold hover:bg-zinc-100 dark:hover:bg-zinc-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-2xl bg-[#ea580c] hover:bg-[#c2410c] text-white text-xs font-bold shadow-md shadow-orange-500/20 flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
