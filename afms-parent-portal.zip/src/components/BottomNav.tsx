import React from 'react';
import { usePortal } from '../context/PortalContext';
import { getAccentClasses } from '../utils/theme';
import {
  LayoutDashboard,
  ClipboardList,
  CalendarCheck,
  Megaphone,
  UserCheck,
} from 'lucide-react';
import { TabType } from '../types';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, activeForms, submissions, announcements, accentTheme } = usePortal();
  const accent = getAccentClasses(accentTheme);

  const pendingFormsCount = activeForms.filter((f) => !submissions.some((s) => s.formId === f.id)).length;

  const tabs: { id: TabType; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'dashboard', label: 'Home', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'forms', label: 'Forms', icon: <ClipboardList className="w-5 h-5" />, badge: pendingFormsCount },
    { id: 'attendance', label: 'Attendance', icon: <CalendarCheck className="w-5 h-5" /> },
    { id: 'announcements', label: 'Notices', icon: <Megaphone className="w-5 h-5" />, badge: announcements.length },
    { id: 'profile', label: 'Profile', icon: <UserCheck className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800/80 px-2 py-1.5 transition-colors">
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-200 min-w-[60px] ${
                isActive
                  ? `${accent.textAccent} font-semibold scale-105`
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                {tab.icon}
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-4 px-1 rounded-full bg-cyan-500 text-[10px] font-bold text-slate-950 flex items-center justify-center shadow-sm animate-pulse">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-1 font-medium tracking-tight">
                {tab.label}
              </span>

              {isActive && (
                <div className={`absolute -bottom-1 w-8 h-1 rounded-full ${accent.bgGradient}`} />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
