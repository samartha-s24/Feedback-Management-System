import React from 'react';
import { usePortal } from '../../context/PortalContext';
import { getAccentClasses } from '../../utils/theme';
import { CheckCircle2, Sparkles } from 'lucide-react';

export const SuccessModal: React.FC = () => {
  const { successModal, closeSuccessModal, accentTheme, setActiveTab } = usePortal();

  if (!successModal.isOpen || !successModal.submission) return null;

  const { submission } = successModal;
  const accent = getAccentClasses(accentTheme);

  const handleDone = () => {
    closeSuccessModal();
    setActiveTab('history');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center shadow-2xl space-y-4 animate-in zoom-in-95 duration-200">
        <div className="w-16 h-16 rounded-3xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center mx-auto shadow-inner border border-emerald-500/20">
          <CheckCircle2 className="w-9 h-9" />
        </div>

        <div className="space-y-1">
          <h3 className="text-lg font-extrabold text-slate-100">Feedback Submitted!</h3>
          <p className="text-xs text-slate-400">
            Thank you for sharing your valuable input with Autonomous College.
          </p>
        </div>

        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 text-left text-xs space-y-1.5">
          <div className="flex justify-between">
            <span className="text-slate-500">Form Title:</span>
            <span className="font-bold text-slate-200 truncate max-w-[180px]">{submission.title}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Parent Name:</span>
            <span className="font-semibold text-slate-200">{submission.parentName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Student Name:</span>
            <span className="font-semibold text-slate-200">{submission.studentName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Submitted:</span>
            <span className="font-semibold text-slate-200">{submission.date}, {submission.time}</span>
          </div>
        </div>

        <button
          onClick={handleDone}
          className={`w-full py-3 rounded-2xl text-xs font-bold ${accent.primaryBtn} shadow-lg active:scale-98`}
        >
          View Submission History
        </button>
      </div>
    </div>
  );
};
