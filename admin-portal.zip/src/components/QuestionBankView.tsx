import React, { useState } from 'react';
import { Plus, Search, Star, Edit3, Trash2, Download, Check, X, Save } from 'lucide-react';
import { QuestionItem } from '../types';

interface QuestionBankViewProps {
  questions: QuestionItem[];
  onOpenNewQuestionModal: () => void;
  searchQuery?: string;
  theme?: 'light' | 'dark' | 'system';
}

export const QuestionBankView: React.FC<QuestionBankViewProps> = ({
  questions = [],
  onOpenNewQuestionModal,
  searchQuery: externalSearch = '',
  theme = 'light'
}) => {
  const isDark = theme === 'dark';

  const [search, setSearch] = useState(externalSearch);
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedType, setSelectedType] = useState('All Types');
  const [activeOnly, setActiveOnly] = useState(false);

  const defaultQuestions = [
    {
      id: 'q1',
      question: 'How effectively does the instructor communicate core concepts and syllabus topics?',
      addedBy: 'ADMIN',
      date: 'Jul 20, 2026',
      type: 'Rating (1-5)',
      category: 'course delivery',
      usage: 3,
      status: 'Active'
    },
    {
      id: 'q2',
      question: 'Rate the availability and quality of supplementary learning materials provided.',
      addedBy: 'ADMIN',
      date: 'Jul 20, 2026',
      type: 'Rating (1-5)',
      category: 'course delivery',
      usage: 4,
      status: 'Active'
    },
    {
      id: 'q3',
      question: 'Which teaching methodology proved most effective during this course?',
      addedBy: 'ADMIN',
      date: 'Jul 19, 2026',
      type: 'MCQ',
      category: 'course delivery',
      usage: 2,
      status: 'Active'
    },
    {
      id: 'q4',
      question: 'Rate the timeliness and fairness of assignment grading and continuous feedback.',
      addedBy: 'ADMIN',
      date: 'Jul 19, 2026',
      type: 'Rating (1-5)',
      category: 'course delivery',
      usage: 6,
      status: 'Active'
    },
    {
      id: 'q5',
      question: 'Are lab equipment and computing infrastructure adequate for practical experiments?',
      addedBy: 'ADMIN',
      date: 'Jul 18, 2026',
      type: 'Rating (1-5)',
      category: 'infrastructure',
      usage: 5,
      status: 'Active'
    }
  ];

  const formattedPropQuestions = questions.map(q => ({
    id: q.id,
    question: q.text,
    addedBy: q.addedBy || 'ADMIN',
    date: 'Jul 23, 2026',
    type: q.type === 'rating' ? 'Rating (1-5)' : q.type === 'mcq' ? 'MCQ' : 'Text Feedback',
    category: q.category.toLowerCase(),
    usage: q.usageCount || 1,
    status: 'Active'
  }));

  const allQuestions = [...formattedPropQuestions, ...defaultQuestions.filter(dq => !formattedPropQuestions.some(pq => pq.id === dq.id))];

  const [deletedIds, setDeletedIds] = useState<string[]>([]);

  const activeQuestionList = allQuestions.filter(q => !deletedIds.includes(q.id));

  const handleDeleteQuestion = (id: string) => {
    if (confirm('Delete this question from the question bank?')) {
      setDeletedIds(prev => [...prev, id]);
    }
  };

  const handleExportQuestionsCSV = () => {
    const header = ['ID', 'Question Text', 'Type', 'Category', 'Usage Count', 'Status', 'Added Date'];
    const rows = activeQuestionList.map(q => [q.id, q.question, q.type, q.category, q.usage.toString(), q.status, q.date]);
    const csvContent = [header, ...rows].map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(",")).join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'AFMS_Question_Bank.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filtered = activeQuestionList.filter(q => {
    const matchesSearch = q.question.toLowerCase().includes(search.toLowerCase());
    const matchesCat = selectedCategory === 'All Categories' || q.category === selectedCategory;
    const matchesType = selectedType === 'All Types' || q.type === selectedType;
    const matchesActive = !activeOnly || q.status === 'Active';
    return matchesSearch && matchesCat && matchesType && matchesActive;
  });

  return (
    <div className="space-y-5 max-w-7xl mx-auto animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            Question Bank
          </h1>
          <p className="text-xs font-semibold text-zinc-500 mt-0.5">
            {questionList.length} active questions available for questionnaires.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button 
            onClick={handleExportQuestionsCSV}
            className="px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button 
            onClick={onOpenNewQuestionModal}
            className="px-4 py-2.5 rounded-2xl bg-[#ea580c] hover:bg-[#c2410c] text-white font-bold text-xs shadow-lg shadow-orange-500/20 transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>New Question</span>
          </button>
        </div>
      </div>

      {/* 4 Stat Summary Metric Boxes */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className={`p-4 rounded-2xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black tracking-tight">{questionList.length}</p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">Total Questions</p>
        </div>

        <div className={`p-4 rounded-2xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black tracking-tight text-amber-500">
            {questionList.filter(q => q.status === 'Active').length}
          </p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">Active</p>
        </div>

        <div className={`p-4 rounded-2xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black tracking-tight">
            {questionList.filter(q => q.type.includes('Rating')).length}
          </p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">Rating Type</p>
        </div>

        <div className={`p-4 rounded-2xl border ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-2xl font-black tracking-tight">2</p>
          <p className="text-[11px] font-bold text-zinc-400 mt-0.5">Categories</p>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="flex flex-col md:flex-row items-center gap-2.5">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            placeholder="Search questions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={`w-full text-xs rounded-2xl pl-10 pr-4 py-2.5 border focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
              isDark 
                ? 'bg-[#181210] border-[#2e2623] text-white placeholder-zinc-500' 
                : 'bg-white border-zinc-200 text-zinc-900 placeholder-zinc-400 shadow-xs'
            }`}
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 w-full md:w-auto">
          <select 
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className={`text-xs font-bold rounded-2xl px-3 py-2.5 border cursor-pointer ${
              isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-300' : 'bg-white border-zinc-200 text-zinc-800'
            }`}
          >
            <option value="All Categories">All Categories</option>
            <option value="course delivery">course delivery</option>
            <option value="infrastructure">infrastructure</option>
          </select>

          <select 
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className={`text-xs font-bold rounded-2xl px-3 py-2.5 border cursor-pointer ${
              isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-300' : 'bg-white border-zinc-200 text-zinc-800'
            }`}
          >
            <option value="All Types">All Types</option>
            <option value="Rating (1-5)">Rating (1-5)</option>
            <option value="MCQ">MCQ</option>
          </select>

          <button 
            onClick={() => setActiveOnly(!activeOnly)}
            className={`text-xs font-bold rounded-2xl px-3 py-2.5 border transition-all ${
              activeOnly 
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' 
                : isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-300' : 'bg-white border-zinc-200 text-zinc-800'
            }`}
          >
            {activeOnly ? '✓ Active Only' : 'Show All'}
          </button>
        </div>
      </div>

      {/* Data Table */}
      <div className={`rounded-3xl border overflow-hidden ${
        isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
      }`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className={`text-[10px] font-black uppercase tracking-wider border-b ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-400' : 'bg-slate-50 border-zinc-200 text-zinc-500'
              }`}>
                <th className="py-3 px-4">QUESTION</th>
                <th className="py-3 px-4">TYPE</th>
                <th className="py-3 px-4">CATEGORY</th>
                <th className="py-3 px-4">USAGE</th>
                <th className="py-3 px-4">STATUS</th>
                <th className="py-3 px-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800/60 text-xs">
              {filtered.map((item) => (
                <tr key={item.id} className="hover:bg-zinc-500/5 transition-colors">
                  <td className="py-3.5 px-4">
                    <p className="font-extrabold text-sm">{item.question}</p>
                    <p className="text-[10px] text-zinc-400 mt-0.5">
                      Added by {item.addedBy} on {item.date}
                    </p>
                  </td>

                  <td className="py-3.5 px-4 font-bold">
                    {item.type === 'MCQ' ? (
                      <span className="text-indigo-500 flex items-center gap-1 text-xs">
                        ≡ MCQ
                      </span>
                    ) : (
                      <span className="text-amber-500 flex items-center gap-1 text-xs">
                        ★ Rating (1-5)
                      </span>
                    )}
                  </td>

                  <td className="py-3.5 px-4 font-medium text-zinc-400 capitalize">
                    {item.category}
                  </td>

                  <td className="py-3.5 px-4">
                    <span className="px-2.5 py-1 rounded-md bg-zinc-800 text-zinc-200 font-mono text-xs font-bold">
                      {item.usage}
                    </span>
                  </td>

                  <td className="py-3.5 px-4">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 inline-flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      Active
                    </span>
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-1 text-zinc-400">
                      <button 
                        onClick={() => handleDeleteQuestion(item.id)}
                        className="p-1.5 rounded-lg hover:bg-rose-500/10 hover:text-rose-500"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
