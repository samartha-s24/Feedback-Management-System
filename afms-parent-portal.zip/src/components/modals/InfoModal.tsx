import React from 'react';
import { usePortal } from '../../context/PortalContext';
import { X, Info } from 'lucide-react';

export const InfoModal: React.FC = () => {
  const { infoModal, closeInfoModal } = usePortal();

  if (!infoModal.isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <Info className="w-4 h-4 text-cyan-400" />
            <span>{infoModal.title}</span>
          </h3>
          <button
            onClick={closeInfoModal}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80">
          {infoModal.content}
        </p>

        <div className="text-right pt-1">
          <button
            onClick={closeInfoModal}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
