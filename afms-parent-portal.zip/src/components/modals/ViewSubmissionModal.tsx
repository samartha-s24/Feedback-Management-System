import React from 'react';
import { usePortal } from '../../context/PortalContext';
import { X, CheckCircle2, Calendar, User } from 'lucide-react';

export const ViewSubmissionModal: React.FC = () => {
  const { activeSubmission, closeViewSubmissionModal } = usePortal();

  if (!activeSubmission) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/60 sticky top-0 z-10">
          <div>
            <h3 className="font-bold text-sm text-slate-100">{activeSubmission.title}</h3>
            <p className="text-[11px] text-emerald-400 font-medium">✓ Feedback Submitted</p>
          </div>
          <button
            onClick={closeViewSubmissionModal}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-3 text-xs">
          {/* Metadata Grid */}
          <div className="grid grid-cols-2 gap-2 p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80">
            <div>
              <span className="text-[10px] text-slate-500 block">Parent</span>
              <span className="font-semibold text-slate-200">{activeSubmission.parentName}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">Student</span>
              <span className="font-semibold text-slate-200">{activeSubmission.studentName}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">Date & Time</span>
              <span className="font-semibold text-slate-200">{activeSubmission.date}, {activeSubmission.time}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">Status</span>
              <span className="font-bold text-emerald-400">{activeSubmission.status}</span>
            </div>
          </div>

          {/* Answers list */}
          <div className="space-y-2.5">
            <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Submitted Responses</h4>
            {Object.entries(activeSubmission.answers).map(([key, val], idx) => (
              <div key={key} className="p-3 rounded-xl bg-slate-950/50 border border-slate-800/80 space-y-1">
                <p className="font-medium text-slate-300 text-xs">
                  <span className="text-cyan-400 font-bold mr-1">{idx + 1}.</span>
                  {val.text}
                </p>
                <p className="font-extrabold text-cyan-400 text-xs pl-4">{val.answer || 'N/A'}</p>
              </div>
            ))}
          </div>

          {activeSubmission.suggestions && (
            <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800/80 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Comments & Suggestions</span>
              <p className="text-slate-200 italic">{activeSubmission.suggestions}</p>
            </div>
          )}
        </div>

        <div className="p-3 border-t border-slate-800 bg-slate-950/40 text-right">
          <button
            onClick={closeViewSubmissionModal}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
