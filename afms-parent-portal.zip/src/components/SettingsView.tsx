import React, { useState } from 'react';
import { usePortal } from '../context/PortalContext';
import { getAccentClasses } from '../utils/theme';
import { AccentTheme } from '../types';
import {
  Settings,
  Lock,
  Bell,
  Palette,
  Shield,
  HelpCircle,
  ChevronRight,
  Sun,
  Moon,
  Smartphone,
  Check,
  Globe,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    openEditProfileModal,
    isDarkMode,
    toggleDarkMode,
    accentTheme,
    setAccentTheme,
    notifications,
    updateNotification,
    openInfoModal,
    showToast,
    isMobileDeviceFrame,
    toggleMobileDeviceFrame,
  } = usePortal();

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [language, setLanguage] = useState('English');

  const accent = getAccentClasses(accentTheme);

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword || !newPassword || !confirmPassword) {
      showToast('⚠️ Please fill in all password fields');
      return;
    }
    if (newPassword !== confirmPassword) {
      showToast('⚠️ New passwords do not match');
      return;
    }
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    showToast('🔒 Account password updated successfully!');
  };

  const themes: { id: AccentTheme; name: string; color: string }[] = [
    { id: 'blue', name: 'Blue (Default)', color: '#2f7de1' },
    { id: 'teal', name: 'Teal', color: '#14b8a6' },
    { id: 'emerald', name: 'Emerald', color: '#10b981' },
    { id: 'rose', name: 'Rose', color: '#f43f5e' },
    { id: 'purple', name: 'Purple', color: '#8b5cf6' },
  ];

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Header */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 shadow-sm">
        <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <Settings className="w-5 h-5 text-cyan-400" />
          <span>App Preferences & Settings</span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Configure account security, accent colors, theme preferences, and notifications.
        </p>
      </div>

      {/* Account Settings */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-2 shadow-md">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Account Info</h2>

        <button
          onClick={openEditProfileModal}
          className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:bg-slate-800/60 transition-colors text-xs text-slate-200 font-medium"
        >
          <span>Edit Parent Profile</span>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={openEditProfileModal}
          className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:bg-slate-800/60 transition-colors text-xs text-slate-200 font-medium"
        >
          <span>Update Email Address</span>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={openEditProfileModal}
          className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:bg-slate-800/60 transition-colors text-xs text-slate-200 font-medium"
        >
          <span>Update Mobile Phone</span>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>
      </div>

      {/* Account Security Password Form */}
      <form onSubmit={handlePasswordSubmit} className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-3 shadow-md">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Lock className="w-3.5 h-3.5 text-cyan-400" />
          <span>Account Security</span>
        </h2>

        <div className="space-y-2">
          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1">Current Password</label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
            />
          </div>

          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1">New Password</label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
            />
          </div>

          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1">Confirm Password</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
            />
          </div>
        </div>

        <button
          type="submit"
          className={`w-full py-2.5 rounded-xl text-xs font-bold ${accent.primaryBtn} active:scale-98`}
        >
          Save Password
        </button>
      </form>

      {/* Notifications Panel */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-3 shadow-md">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Bell className="w-3.5 h-3.5 text-indigo-400" />
          <span>Notification Alerts</span>
        </h2>

        <div className="space-y-2 text-xs">
          {[
            { key: 'feedback', label: 'Feedback Reminders' },
            { key: 'announcement', label: 'Announcement & Circular Alerts' },
            { key: 'fee', label: 'Fee Payment Reminders' },
            { key: 'exam', label: 'Examination Timetable Alerts' },
          ].map((item) => {
            const key = item.key as keyof typeof notifications;
            const isChecked = notifications[key];
            return (
              <div key={key} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
                <span className="text-slate-200 font-medium">{item.label}</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={(e) => {
                      updateNotification(key, e.target.checked);
                      showToast(`${item.label} ${e.target.checked ? 'enabled' : 'disabled'}`);
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>
            );
          })}
        </div>
      </div>

      {/* Appearance & Theme Picker */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-3 shadow-md">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Palette className="w-3.5 h-3.5 text-rose-400" />
          <span>Appearance & Theme</span>
        </h2>

        {/* Dark Mode Toggle */}
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs">
          <div className="flex items-center gap-2">
            {isDarkMode ? <Moon className="w-4 h-4 text-amber-400" /> : <Sun className="w-4 h-4 text-sky-400" />}
            <span className="text-slate-200 font-medium">Dark Theme Mode</span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={isDarkMode}
              onChange={toggleDarkMode}
              className="sr-only peer"
            />
            <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
          </label>
        </div>

        {/* Mobile Device Frame toggle for desktop presentation */}
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-200 font-medium">Mobile Device Shell Frame</span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={isMobileDeviceFrame}
              onChange={toggleMobileDeviceFrame}
              className="sr-only peer"
            />
            <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
          </label>
        </div>

        {/* Language Selection */}
        <div className="space-y-1 text-xs">
          <label className="text-slate-400 font-medium block">Portal Language</label>
          <div className="relative">
            <select
              value={language}
              onChange={(e) => {
                setLanguage(e.target.value);
                showToast(`Language changed to ${e.target.value}`);
              }}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-cyan-500"
            >
              <option value="English">English (United States)</option>
              <option value="Hindi">Hindi (हिंदी)</option>
              <option value="Marathi">Marathi (मराठी)</option>
            </select>
          </div>
        </div>

        {/* Accent Swatches */}
        <div className="space-y-1.5 pt-1">
          <span className="text-slate-400 text-xs font-medium block">Accent Theme Color</span>
          <div className="flex items-center gap-3">
            {themes.map((t) => {
              const isSelected = accentTheme === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setAccentTheme(t.id)}
                  style={{ backgroundColor: t.color }}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-transform ${
                    isSelected ? 'ring-2 ring-white scale-110 shadow-lg' : 'opacity-80 hover:opacity-100 hover:scale-105'
                  }`}
                  title={t.name}
                >
                  {isSelected && <Check className="w-4 h-4 text-white font-black" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Privacy & Policies */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-2 shadow-md">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-1">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span>Privacy & Terms</span>
        </h2>

        {['Privacy Policy', 'Terms & Conditions'].map((item) => (
          <button
            key={item}
            onClick={() =>
              openInfoModal(
                item,
                item === 'Privacy Policy'
                  ? 'Autonomous College is committed to protecting the privacy of parents and students. Personal information collected through this portal is used solely for academic communication, attendance logging, and feedback collection.'
                  : 'By using the AFMS Parent Portal, you agree to provide accurate information and to use the feedback system responsibly and respectfully.'
              )
            }
            className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:bg-slate-800/60 transition-colors text-xs text-slate-200 font-medium"
          >
            <span>{item}</span>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>
        ))}
      </div>

      {/* Support & Help */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-2 shadow-md">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-1">
          <HelpCircle className="w-3.5 h-3.5 text-teal-400" />
          <span>Help & Support</span>
        </h2>

        {[
          {
            title: 'FAQs',
            content: 'Common questions about the Parent Portal, feedback submission, attendance calculation, and account credentials are answered in the school help centre.',
          },
          {
            title: 'Contact School',
            content: 'You can reach the school administration office at contact@autonomouscollege.edu or call +91 (022) 2870-0000 during working hours (9 AM - 5 PM).',
          },
          {
            title: 'Report an Issue',
            content: 'If you experience technical glitches with the portal, please contact the IT Helpdesk at support@autonomouscollege.edu.',
          },
        ].map((item) => (
          <button
            key={item.title}
            onClick={() => openInfoModal(item.title, item.content)}
            className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:bg-slate-800/60 transition-colors text-xs text-slate-200 font-medium"
          >
            <span>{item.title}</span>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>
        ))}
      </div>
    </div>
  );
};
