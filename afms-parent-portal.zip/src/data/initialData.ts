import { FeedbackForm, Announcement, ParentInfo, StudentInfo, AttendanceDetail } from '../types';

export const INITIAL_PARENT: ParentInfo = {
  name: "Mr. Siddiqui",
  id: "PAR1208",
  email: "siddiqui.parent@gmail.com",
  mobile: "+91 98765 43210",
  address: "Mumbai, Maharashtra",
  relationship: "Father",
};

export const INITIAL_STUDENT: StudentInfo = {
  name: "Iram Siddiqui",
  prn: "125UIT1208",
  yearLevel: "First Year (FY B.Tech)",
  division: "A",
  department: "Information Technology (IT)",
  academicYear: "2025–2026",
  attendance: "92%",
};

export const ACTIVE_FORMS: FeedbackForm[] = [
  {
    id: "teacher-comm",
    icon: "👨‍🏫",
    title: "Teacher Communication Feedback",
    assignedBy: "School Administration",
    dueDate: "26 July 2026",
    estTime: "5 Minutes",
    autofill: ["name", "prn", "yearLevel", "division", "department", "academicYear"],
    questions: [
      { id: "q1", type: "star", text: "How satisfied are you with the communication from your child's teacher regarding academic progress?" },
      { id: "q2", type: "star", text: "Does the teacher regularly update you about your child's performance?" },
      { id: "q3", type: "star", text: "Are your concerns or queries addressed promptly by the teacher?" },
      { id: "q4", type: "star", text: "Are parent-teacher meetings helpful in understanding your child's progress?" },
      { id: "q5", type: "star", text: "Do you feel the teacher provides appropriate guidance and support for your child's learning?" },
      { id: "q6", type: "star", text: "Overall, how satisfied are you with the teacher's communication and support?" },
    ],
    suggestionsPrompt: "Please provide any suggestions or comments to improve communication between teachers and parents.",
  },
  {
    id: "school-facilities",
    icon: "🏫",
    title: "School Facilities & Parent Experience Feedback",
    assignedBy: "School Administration",
    dueDate: "30 July 2026",
    estTime: "5 Minutes",
    autofill: ["name", "prn", "yearLevel", "division", "department", "academicYear"],
    questions: [
      { id: "q1", type: "star", text: "How satisfied are you with the cleanliness and maintenance of the school?" },
      { id: "q2", type: "star", text: "Do you feel the school provides a safe and secure environment for your child?" },
      { id: "q3", type: "star", text: "How satisfied are you with the communication from the school regarding important announcements and events?" },
      { id: "q4", type: "star", text: "Are you satisfied with the school's facilities and learning environment?" },
      { id: "q5", type: "star", text: "Do you believe the school supports your child's overall growth and well-being?" },
      { id: "q6", type: "star", text: "Overall, how satisfied are you with your experience as a parent?" },
    ],
    suggestionsPrompt: "Please share any suggestions or recommendations to improve the school's services.",
  },
];

export const COMING_SOON_FORMS = [
  { id: "cs-1", title: "Parent-School Communication Survey", est: "August 2026" },
  { id: "cs-2", title: "Student Well-being & Mental Health Feedback", est: "August 2026" },
  { id: "cs-3", title: "School Safety & Security Infrastructure Audit", est: "September 2026" },
  { id: "cs-4", title: "Transport Service & Route Optimization Feedback", est: "September 2026" },
];

export const ANNOUNCEMENTS: Announcement[] = [
  {
    id: "a1",
    icon: "📢",
    title: "Teacher Communication Feedback Released",
    date: "20 Jul 2026",
    priority: "high",
    desc: "Parents are requested to complete the teacher communication feedback form before the due date of 26th July.",
    pdf: false,
  },
  {
    id: "a2",
    icon: "📢",
    title: "Mid-Term Examination Schedule Released",
    date: "19 Jul 2026",
    priority: "high",
    desc: "The mid-term examination timetable for all classes has been published. Please review the attached schedule with your ward.",
    pdf: true,
  },
  {
    id: "a3",
    icon: "📢",
    title: "Regional Holiday Notice",
    date: "17 Jul 2026",
    priority: "medium",
    desc: "The school will remain closed on account of a regional holiday. Regular classes resume the following working day.",
    pdf: false,
  },
  {
    id: "a4",
    icon: "💳",
    title: "Term 2 Fee Payment Reminder",
    date: "15 Jul 2026",
    priority: "high",
    desc: "This is a friendly reminder that Term 2 tuition fees are due by the end of this month. Late payments may incur a nominal surcharge.",
    pdf: true,
  },
  {
    id: "a5",
    icon: "🎭",
    title: "Annual Cultural Day Registration Open",
    date: "12 Jul 2026",
    priority: "low",
    desc: "Registration is now open for the Annual Day cultural program performances. Interested students may sign up via their class teacher.",
    pdf: false,
  },
  {
    id: "a6",
    icon: "👥",
    title: "Parent Workshop: Supporting STEM Learning at Home",
    date: "10 Jul 2026",
    priority: "medium",
    desc: "An interactive workshop on supporting problem-solving and technical learning at home will be held this Saturday. Seats are limited.",
    pdf: false,
  },
  {
    id: "a7",
    icon: "🚌",
    title: "School Circular: Updated Pickup Timings",
    date: "08 Jul 2026",
    priority: "low",
    desc: "General circular regarding updated bus pickup and drop-off timings for the new academic semester.",
    pdf: true,
  },
];

export const INITIAL_ATTENDANCE: AttendanceDetail = {
  present: 184,
  absent: 16,
  total: 200,
  monthly: [
    { month: "July 2026", present: 9, absent: 1, total: 10 },
    { month: "June 2026", present: 32, absent: 2, total: 34 },
    { month: "May 2026", present: 33, absent: 3, total: 36 },
    { month: "April 2026", present: 35, absent: 3, total: 38 },
    { month: "March 2026", present: 37, absent: 3, total: 40 },
    { month: "February 2026", present: 38, absent: 4, total: 42 },
  ],
  subjects: [
    { name: "Mathematics", percent: 95, code: "BS-101", faculty: "Dr. Sharma" },
    { name: "Physics", percent: 90, code: "BS-102", faculty: "Prof. Kulkarni" },
    { name: "Programming Fundamentals", percent: 93, code: "CS-101", faculty: "Prof. Verma" },
    { name: "English Communication", percent: 88, code: "HS-101", faculty: "Mrs. Deshmukh" },
    { name: "Engineering Graphics", percent: 91, code: "ME-101", faculty: "Prof. Patil" },
    { name: "Environmental Studies", percent: 94, code: "ES-101", faculty: "Dr. Joshi" },
  ],
};

export const INFO_CONTENT: Record<string, string> = {
  "Privacy Policy": "Autonomous College is committed to protecting the privacy of parents and students. Personal information collected through this portal is used solely for academic communication, performance tracking, and feedback collection.",
  "Terms & Conditions": "By using the AFMS Parent Portal, you agree to provide accurate information and to use the feedback system responsibly and respectfully.",
  "FAQs": "Common questions about the Parent Portal, feedback submissions, report cards, fee receipts, and account settings are answered in the school help centre.",
  "Contact School": "You can reach the school administration office at contact@autonomouscollege.edu or call +91 (022) 2870-0000 during office hours (9 AM - 5 PM).",
  "Report an Issue": "If you experience any technical issues with the portal or bug reports, please describe the problem or contact IT Support at support@autonomouscollege.edu.",
};
