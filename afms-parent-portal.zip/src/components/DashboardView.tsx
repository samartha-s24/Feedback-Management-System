import React from 'react';
import { usePortal } from '../context/PortalContext';
import { getAccentClasses } from '../utils/theme';
import {
  Clock,
  CheckCircle2,
  Megaphone,
  CalendarCheck,
  ChevronRight,
  BookOpen,
  ArrowUpRight,
  Sparkles,
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    parent,
    student,
    activeForms,
    submissions,
    announcements,
    attendanceDetail,
    setActiveTab,
    openFeedbackModal,
    accentTheme,
  } = usePortal();

  const accent = getAccentClasses(accentTheme);

  const pendingForms = activeForms.filter((f) => !submissions.some((s) => s.formId === f.id));
  const pendingCount = pendingForms.length;
  const submittedCount = submissions.length;
  const totalCount = pendingCount + submittedCount;
  const completionPercent = totalCount === 0 ? 100 : Math.round((submittedCount / totalCount) * 100);

  const attPercent = attendanceDetail.total === 0 ? 0 : Math.round((attendanceDetail.present / attendanceDetail.total) * 100);

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Welcome Banner */}
      <div className={`relative overflow-hidden rounded-2xl p-5 ${accent.bgGradient} text-slate-950 shadow-xl`}>
        <div className="absolute top-0 right-0 -mr-6 -mt-6 w-32 h-32 rounded-full bg-white/10 blur-xl pointer-events-none" />
        <div className="relative z-10 flex items-start gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-slate-950/20 backdrop-blur-sm flex items-center justify-center text-2xl shrink-0 shadow-inner">
            📖
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-950/80">
              <Sparkles className="w-3 h-3" />
              <span>Parent Portal · AFMS</span>
            </div>
            <h1 className="text-xl font-extrabold tracking-tight text-slate-950 leading-tight">
              Welcome Back, {parent.name}!
            </h1>
            <p className="text-xs text-slate-950/90 font-medium leading-relaxed">
              Supporting <strong className="font-bold underline decoration-slate-950/30">{student.name}</strong> ({student.division}, {student.department}). You have{' '}
              <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-slate-950 text-white font-bold text-[11px]">
                {pendingCount} pending
              </span>{' '}
              feedback form{pendingCount === 1 ? '' : 's'}.
            </p>
          </div>
        </div>
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* Pending Feedback */}
        <button
          onClick={() => setActiveTab('forms')}
          className="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 text-left hover:border-amber-500/50 transition-all group active:scale-98 shadow-sm"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium block">Pending</span>
            <span className="text-xl font-extrabold text-slate-100 group-hover:text-amber-400 transition-colors">
              {pendingCount}
            </span>
          </div>
        </button>

        {/* Feedback Submitted */}
        <button
          onClick={() => setActiveTab('history')}
          className="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 text-left hover:border-emerald-500/50 transition-all group active:scale-98 shadow-sm"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium block">Submitted</span>
            <span className="text-xl font-extrabold text-slate-100 group-hover:text-emerald-400 transition-colors">
              {submittedCount}
            </span>
          </div>
        </button>

        {/* Announcements */}
        <button
          onClick={() => setActiveTab('announcements')}
          className="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 text-left hover:border-indigo-500/50 transition-all group active:scale-98 shadow-sm"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center shrink-0">
            <Megaphone className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium block">Notices</span>
            <span className="text-xl font-extrabold text-slate-100 group-hover:text-indigo-400 transition-colors">
              {announcements.length}
            </span>
          </div>
        </button>

        {/* Child Attendance */}
        <button
          onClick={() => setActiveTab('attendance')}
          className="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 text-left hover:border-cyan-500/50 transition-all group active:scale-98 shadow-sm"
        >
          <div className="w-10 h-10 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center shrink-0">
            <CalendarCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium block">Attendance</span>
            <span className="text-xl font-extrabold text-slate-100 group-hover:text-cyan-400 transition-colors">
              {attPercent}%
            </span>
          </div>
        </button>
      </div>

      {/* Priority Parent Feedback Section */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-3 shadow-md">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <span>Priority Feedback</span>
            {pendingCount > 0 && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 font-bold">
                {pendingCount} Active
              </span>
            )}
          </h2>
          <button
            onClick={() => setActiveTab('forms')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5"
          >
            <span>View All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {pendingForms.length === 0 ? (
          <div className="p-4 rounded-xl bg-slate-950/50 border border-slate-800/80 text-center space-y-1">
            <span className="text-2xl">🎉</span>
            <p className="text-xs font-semibold text-slate-200">All Feedback Completed!</p>
            <p className="text-[11px] text-slate-400">Thank you for sharing your feedback with the institution.</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {pendingForms.map((form) => (
              <div
                key={form.id}
                className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/90 flex flex-col gap-2 hover:border-slate-700 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-xl shrink-0">{form.icon}</span>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-100 truncate">{form.title}</p>
                      <p className="text-[10px] text-slate-400">Due: {form.dueDate} · Est: {form.estTime}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-800/60">
                  <span className="text-[10px] font-medium text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">
                    Pending Response
                  </span>
                  <button
                    onClick={() => openFeedbackModal(form.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold ${accent.primaryBtn} flex items-center gap-1 active:scale-95`}
                  >
                    <span>Start Now</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Latest Announcements Mini-List */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-3 shadow-md flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Latest Notices
            </h3>
            <button
              onClick={() => setActiveTab('announcements')}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300"
            >
              View All
            </button>
          </div>

          <div className="space-y-2">
            {announcements.slice(0, 3).map((item) => (
              <div
                key={item.id}
                onClick={() => setActiveTab('announcements')}
                className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/80 hover:border-slate-700 transition-colors cursor-pointer flex items-center gap-2.5"
              >
                <span className="text-base shrink-0">{item.icon}</span>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold text-slate-200 truncate">{item.title}</p>
                  <p className="text-[10px] text-slate-400">{item.date}</p>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={() => setActiveTab('announcements')}
          className="w-full mt-2 py-2 text-center text-xs font-semibold text-slate-300 bg-slate-800/60 rounded-xl hover:bg-slate-800 hover:text-white transition-colors"
        >
          Check Notice Board
        </button>
      </div>
    </div>
  );
};
