import React, { useState } from 'react';
import { 
  Menu, 
  Bell, 
  User,
  Settings,
  LogOut,
  Shield,
  Sparkles
} from 'lucide-react';
import { AdminNotification, TabType } from '../types';

interface HeaderProps {
  notifications: AdminNotification[];
  onOpenNotifications: () => void;
  onToggleSidebar: () => void;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  searchQuery?: string;
  setSearchQuery?: (val: string) => void;
  theme?: 'light' | 'dark' | 'system';
  setTheme?: (theme: 'light' | 'dark' | 'system') => void;
  onLogout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  notifications,
  onOpenNotifications,
  onToggleSidebar,
  activeTab,
  setActiveTab,
  theme = 'light',
  onLogout
}) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const unreadCount = notifications.filter(n => !n.read).length;

  const isDark = theme === 'dark';

  const formatTabTitle = (tab: TabType) => {
    switch(tab) {
      case 'overview': return 'Dashboard';
      case 'sessions': return 'Feedback Sessions';
      case 'questionnaires': return 'Questionnaires';
      case 'questions': return 'Question Bank';
      case 'responses': return 'Responses by Session';
      case 'analytics': return 'Analytics';
      case 'reports': return 'Reports';
      case 'announcements': return 'Announcements';
      case 'audit_log': return 'Audit Log';
      case 'settings': return 'Settings';
      case 'profile': return 'My Profile';
      default: return 'Portal';
    }
  };

  const toggleTheme = () => {
    if (setTheme) {
      setTheme(isDark ? 'light' : 'dark');
    }
  };

  return (
    <header className={`sticky top-0 z-40 transition-colors ${
      isDark 
        ? 'bg-[#181210] text-zinc-100 border-b border-[#2e2623]' 
        : 'bg-white text-zinc-900 border-b border-zinc-200 shadow-sm'
    } px-4 py-2.5`}>
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        
        {/* Left Side: Brand Logo + Menu Toggle + Breadcrumb */}
        <div className="flex items-center gap-3">
          {/* AFMS Logo Icon */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-md shadow-orange-500/20">
              <Shield className="w-4 h-4 text-white fill-white/20" />
            </div>
            <div className="hidden sm:block">
              <p className={`text-xs font-black tracking-wider leading-none ${isDark ? 'text-white' : 'text-zinc-900'}`}>
                AFMS
              </p>
              <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest leading-none mt-0.5">
                Admin Portal
              </p>
            </div>
          </div>

          <div className="h-5 w-px bg-zinc-300 dark:bg-zinc-800 hidden sm:block mx-1" />

          {/* Sidebar Toggle Button */}
          <button
            onClick={onToggleSidebar}
            className={`p-2 rounded-xl transition-colors ${
              isDark 
                ? 'hover:bg-zinc-800 text-zinc-300' 
                : 'hover:bg-zinc-100 text-zinc-700'
            }`}
            title="Open Navigation Menu"
            aria-label="Toggle navigation menu"
          >
            <Menu className="w-5 h-5 stroke-[2.2]" />
          </button>

          {/* Top Breadcrumb */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-zinc-400 font-medium">Autonomous College</span>
            <span className="text-zinc-400 dark:text-zinc-600">/</span>
            <span className={`font-bold ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {formatTabTitle(activeTab)}
            </span>
          </div>
        </div>

        {/* Right Side: Bell, ADMIN Avatar, Logout */}
        <div className="flex items-center gap-2.5">

          {/* Notification Bell Button */}
          <button
            onClick={onOpenNotifications}
            className={`relative p-2 rounded-xl transition-colors ${
              isDark ? 'hover:bg-zinc-800' : 'hover:bg-zinc-100'
            }`}
            title="Notifications"
          >
            <Bell className="w-4 h-4 text-zinc-400 hover:text-amber-500 transition-colors" />
            <span className="absolute top-1 right-1 flex h-2 w-2 rounded-full bg-orange-500" />
          </button>

          <div className="h-5 w-px bg-zinc-300 dark:bg-zinc-800 mx-0.5" />

          {/* ADMIN Avatar Pill matching screenshots */}
          <button 
            onClick={() => setActiveTab('profile')}
            className="flex items-center gap-2 p-1 rounded-2xl hover:bg-zinc-100 dark:hover:bg-zinc-800/60 transition-all cursor-pointer"
            title="View Admin Profile"
          >
            <div className="w-8 h-8 rounded-full bg-amber-600 text-white font-black text-xs flex items-center justify-center shadow-md shadow-amber-600/20">
              A
            </div>

            <div className="hidden md:block text-left pr-1">
              <p className={`text-xs font-bold leading-none ${isDark ? 'text-white' : 'text-zinc-900'}`}>
                ADMIN
              </p>
              <p className="text-[10px] text-zinc-400 font-medium leading-none mt-0.5">
                Administrator
              </p>
            </div>
          </button>

          {/* Header Logout Button matching screenshots */}
          <button
            onClick={onLogout}
            className="hidden sm:flex items-center gap-1 px-3 py-1.5 rounded-xl border border-rose-500/30 text-rose-500 hover:bg-rose-500/10 text-xs font-bold transition-all ml-1"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>

        </div>

      </div>
    </header>
  );
};

