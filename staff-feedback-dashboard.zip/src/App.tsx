import React, { useState } from 'react';
import {
  LayoutDashboard,
  User,
  ClipboardList,
  History,
  Megaphone,
  Settings,
  LogOut,
  Bell,
  Sun,
  Moon,
  CheckCircle2,
  FileCode,
  Copy,
  Download,
  Check,
  Send,
  X,
  ShieldCheck,
  Sparkles,
  ArrowRight
} from 'lucide-react';

// Raw PHP code representation for viewing & downloading
const rawPhpCode = `<?php
/**
 * Staff Feedback Dashboard - AFMS Staff Portal
 * PHP Version
 */

session_start();

// Page routing
$validPages = ['dashboard', 'profile', 'forms', 'history', 'announcements', 'settings'];
$currentPage = isset($_GET['page']) && in_array($_GET['page'], $validPages) ? $_GET['page'] : 'dashboard';

// Initialize session state if not set
if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = [
        'name' => 'Alex Carter',
        'staff_id' => 'STAF001',
        'department' => 'Operations',
        'email' => 'lionel.messi@zeal.edu',
        'phone' => '+123 456 7890',
        'courses_assigned' => 6
    ];
}

// Site Data Array
$siteData = [
    'dashboard' => [
        'pageTitle' => 'Welcome to Zeal',
        'pageSubtitle' => 'Staff Dashboard',
        'pageDescription' => 'Keep your staff feedback on track with the latest pending forms, announcements, and priority notifications.',
        'pendingForms' => 1,
        'formsSubmitted' => 6,
        'announcements' => 3,
        'priorityTitle' => 'Teacher Communication Feedback',
        'priorityDue' => '26 Jul 2026',
        'priorityMessage' => 'This is your highest-priority feedback item to review and complete.',
        'deadlines' => [
            'Midterm Survey - due 26 Jul 2026',
            'Project Review - due 02 Aug 2026',
            'Course Evaluation - due 05 Aug 2026'
        ],
        'adminNotification' => 'Admin assigned a new feedback form. Please review and submit by the due date.'
    ],
    'forms' => [
        ['id' => 1, 'course' => 'Advanced AI', 'form' => 'Midterm Survey', 'due' => '26 Jul 2026', 'priority' => 'High'],
        ['id' => 2, 'course' => 'Database Systems', 'form' => 'Project Review', 'due' => '02 Aug 2026', 'priority' => 'Medium'],
        ['id' => 3, 'course' => 'Software Engineering', 'form' => 'Course Evaluation', 'due' => '05 Aug 2026', 'priority' => 'Normal']
    ],
    'history' => [
        ['course' => 'Advanced AI', 'form' => 'Pre-final Feedback', 'status' => 'Submitted', 'submitted' => '20 Jul 2026'],
        ['course' => 'Database Systems', 'form' => 'Lab Feedback', 'status' => 'Submitted', 'submitted' => '18 Jul 2026'],
        ['course' => 'Software Engineering', 'form' => 'Assignment Review', 'status' => 'Submitted', 'submitted' => '16 Jul 2026']
    ],
    'announcements' => [
        ['title' => 'New feedback form available', 'body' => 'A staff feedback form has been released for review and completion soon.', 'date' => '22 Jul 2026'],
        ['title' => 'Policy update', 'body' => 'Review the updated feedback submission guidelines before the next team check-in.', 'date' => '20 Jul 2026'],
        ['title' => 'System maintenance', 'body' => 'The portal will be unavailable on 28 July from 10PM to 12AM.', 'date' => '18 Jul 2026']
    ]
];

// Handle Settings Update POST Request
$toastMessage = null;
$toastType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'save_settings') {
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!$email) {
            $toastMessage = 'Please enter a valid email address.';
            $toastType = 'error';
        } elseif (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $toastMessage = 'All password fields are required.';
            $toastType = 'error';
        } elseif ($newPassword !== $confirmPassword) {
            $toastMessage = 'New password and confirm password do not match.';
            $toastType = 'error';
        } else {
            $_SESSION['user']['email'] = $email;
            $toastMessage = 'Profile and password updated successfully!';
            $toastType = 'success';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo htmlspecialchars($siteData['dashboard']['pageSubtitle']); ?> - Staff Feedback Portal</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen font-sans antialiased">
  <!-- PHP HTML Content -->
</body>
</html>`;

export default function App() {
  const [activePage, setActivePage] = useState<
    'dashboard' | 'profile' | 'forms' | 'history' | 'announcements' | 'settings' | 'php-code'
  >('dashboard');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [copied, setCopied] = useState(false);
  const [fillModalForm, setFillModalForm] = useState<{ course: string; form: string } | null>(null);
  const [modalFeedback, setModalFeedback] = useState('');

  // Editable Profile / Settings State
  const [userProfile, setUserProfile] = useState({
    name: 'Alex Carter',
    staffId: 'STAF001',
    department: 'Operations',
    email: 'lionel.messi@zeal.edu',
    phone: '+123 456 7890',
    coursesAssigned: 6,
  });

  const [settingsForm, setSettingsForm] = useState({
    email: 'lionel.messi@zeal.edu',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  // Dynamic Forms and History
  const [formsList, setFormsList] = useState([
    { id: 1, course: 'Advanced AI', form: 'Midterm Survey', due: '26 Jul 2026' },
    { id: 2, course: 'Database Systems', form: 'Project Review', due: '02 Aug 2026' },
    { id: 3, course: 'Software Engineering', form: 'Course Evaluation', due: '05 Aug 2026' },
  ]);

  const [historyList, setHistoryList] = useState([
    { course: 'Advanced AI', form: 'Pre-final Feedback', status: 'Submitted', submitted: '20 Jul 2026' },
    { course: 'Database Systems', form: 'Lab Feedback', status: 'Submitted', submitted: '18 Jul 2026' },
    { course: 'Software Engineering', form: 'Assignment Review', status: 'Submitted', submitted: '16 Jul 2026' },
  ]);

  const announcementsList = [
    { title: 'New feedback form available', body: 'A staff feedback form has been released for review and completion soon.', date: '22 Jul 2026' },
    { title: 'Policy update', body: 'Review the updated feedback submission guidelines before the next team check-in.', date: '20 Jul 2026' },
    { title: 'System maintenance', body: 'The portal will be unavailable on 28 July from 10PM to 12AM.', date: '18 Jul 2026' },
  ];

  const showNotification = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const handleCopyPhp = () => {
    navigator.clipboard.writeText(rawPhpCode);
    setCopied(true);
    showNotification('PHP Code copied to clipboard!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadPhp = () => {
    const blob = new Blob([rawPhpCode], { type: 'text/x-php' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.php';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showNotification('Downloaded index.php file!', 'success');
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsForm.email || !settingsForm.currentPassword || !settingsForm.newPassword || !settingsForm.confirmPassword) {
      showNotification('Email, current password, new password, and confirm password are required.', 'error');
      return;
    }
    if (settingsForm.newPassword !== settingsForm.confirmPassword) {
      showNotification('New password and confirm password must match.', 'error');
      return;
    }
    setUserProfile((prev) => ({ ...prev, email: settingsForm.email }));
    setSettingsForm((prev) => ({ ...prev, currentPassword: '', newPassword: '', confirmPassword: '' }));
    showNotification('Email and password updated successfully.', 'success');
  };

  const handleFormSubmitModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fillModalForm) return;

    // Add to history
    const today = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    setHistoryList([
      { course: fillModalForm.course, form: fillModalForm.form, status: 'Submitted', submitted: today },
      ...historyList,
    ]);

    // Remove from available forms
    setFormsList(formsList.filter((f) => f.form !== fillModalForm.form));

    setFillModalForm(null);
    setModalFeedback('');
    showNotification(`Feedback submitted for ${fillModalForm.form}!`, 'success');
  };

  const isDark = theme === 'dark';

  return (
    <div className={`min-h-screen ${isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'} font-sans transition-colors duration-200`}>
      {/* Main Application UI */}
      <div className="flex min-h-screen">
          {/* Sidebar */}
          <aside className={`w-72 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'} border-r p-6 hidden md:flex flex-col justify-between`}>
            <div>
              <div className={`mb-8 rounded-[24px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'} p-4 border`}>
                <div className="flex items-center gap-4">
                  <div>
                    <p className="text-xs uppercase tracking-[0.35em] text-slate-500 font-bold">AFMS</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-cyan-400 text-xs font-bold text-slate-950">A</span>
                      <h2 className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>Staff Portal</h2>
                    </div>
                  </div>
                </div>
              </div>

              <nav className="space-y-2 text-sm">
                <button
                  onClick={() => setActivePage('dashboard')}
                  className={`flex w-full items-center gap-3 rounded-[24px] px-4 py-3 text-left transition-all ${
                    activePage === 'dashboard'
                      ? 'bg-cyan-500/15 text-cyan-400 font-semibold'
                      : isDark ? 'text-slate-300 hover:bg-slate-950' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span>Dashboard</span>
                </button>

                <button
                  onClick={() => setActivePage('profile')}
                  className={`flex w-full items-center gap-3 rounded-[24px] px-4 py-3 text-left transition-all ${
                    activePage === 'profile'
                      ? 'bg-cyan-500/15 text-cyan-400 font-semibold'
                      : isDark ? 'text-slate-300 hover:bg-slate-950' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <User className="w-4 h-4" />
                  <span>My Profile</span>
                </button>

                <div className="pt-6 uppercase tracking-[0.35em] text-xs font-bold text-slate-500 px-2">Feedback</div>
                <button
                  onClick={() => setActivePage('forms')}
                  className={`flex w-full items-center gap-3 rounded-[24px] px-4 py-3 text-left transition-all ${
                    activePage === 'forms'
                      ? 'bg-cyan-500/15 text-cyan-400 font-semibold'
                      : isDark ? 'text-slate-300 hover:bg-slate-950' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <ClipboardList className="w-4 h-4" />
                  <span>Available Forms</span>
                  {formsList.length > 0 && (
                    <span className="ml-auto bg-cyan-500/20 text-cyan-400 text-xs font-bold px-2 py-0.5 rounded-full">
                      {formsList.length}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActivePage('history')}
                  className={`flex w-full items-center gap-3 rounded-[24px] px-4 py-3 text-left transition-all ${
                    activePage === 'history'
                      ? 'bg-cyan-500/15 text-cyan-400 font-semibold'
                      : isDark ? 'text-slate-300 hover:bg-slate-950' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <History className="w-4 h-4" />
                  <span>Submission History</span>
                </button>

                <div className="pt-6 uppercase tracking-[0.35em] text-xs font-bold text-slate-500 px-2">Updates</div>
                <button
                  onClick={() => setActivePage('announcements')}
                  className={`flex w-full items-center gap-3 rounded-[24px] px-4 py-3 text-left transition-all ${
                    activePage === 'announcements'
                      ? 'bg-cyan-500/15 text-cyan-400 font-semibold'
                      : isDark ? 'text-slate-300 hover:bg-slate-950' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Megaphone className="w-4 h-4" />
                  <span>Announcements</span>
                </button>

                <div className="pt-6 uppercase tracking-[0.35em] text-xs font-bold text-slate-500 px-2">System</div>
                <button
                  onClick={() => setActivePage('settings')}
                  className={`flex w-full items-center gap-3 rounded-[24px] px-4 py-3 text-left transition-all ${
                    activePage === 'settings'
                      ? 'bg-cyan-500/15 text-cyan-400 font-semibold'
                      : isDark ? 'text-slate-300 hover:bg-slate-950' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  <span>Settings</span>
                </button>
              </nav>
            </div>

            <button
              onClick={() => showNotification('Logged out successfully.', 'info')}
              className={`mt-10 flex w-full items-center justify-center gap-2 rounded-[24px] ${
                isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
              } border px-4 py-3 text-sm text-rose-400 hover:bg-rose-500/10 font-medium transition-all`}
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </aside>

          {/* Main Area */}
          <main className="flex-1 flex flex-col min-w-0">
            {/* Header */}
            <header className={`flex items-center justify-between px-6 md:px-10 py-4 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'} border-b`}>
              <div className="flex items-center gap-3">
                <span className={`text-sm font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>Autonomous College</span>
                <span className="text-slate-400">/</span>
                <span className="text-xs px-2.5 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-semibold">Staff Portal</span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => showNotification('You have 3 high priority notifications.', 'info')}
                  className={`relative rounded-2xl ${isDark ? 'bg-slate-800 text-slate-100 hover:bg-slate-700' : 'bg-slate-100 text-slate-800 hover:bg-slate-200'} px-4 py-2 transition-all`}
                >
                  <Bell className="w-4 h-4" />
                  <span className="absolute -right-1 -top-1 inline-flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-rose-500 px-1.5 text-[11px] font-bold text-white">3</span>
                </button>

                <button
                  onClick={() => setTheme(isDark ? 'light' : 'dark')}
                  className={`rounded-2xl ${isDark ? 'bg-slate-800 text-slate-100 hover:bg-slate-700' : 'bg-slate-100 text-slate-800 hover:bg-slate-200'} px-4 py-2 text-sm flex items-center gap-2 transition-all`}
                >
                  {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
                  <span className="hidden sm:inline">{isDark ? 'Light Theme' : 'Dark Theme'}</span>
                </button>
              </div>
            </header>

            {/* Welcome Banner */}
            <div className={`${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'} border-b px-6 md:px-10 py-8`}>
              <div className={`rounded-[32px] ${isDark ? 'bg-cyan-500/10 border-cyan-500/20' : 'bg-cyan-50 border-cyan-200'} border p-6`}>
                <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
                  <div className="flex items-center gap-4">
                    <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-cyan-400 text-sm font-bold text-slate-950">A</span>
                    <div>
                      <h1 className={`text-3xl md:text-4xl font-bold ${isDark ? 'text-slate-100' : 'text-slate-900'}`}>Welcome Back, {userProfile.name}</h1>
                      <p className={`mt-2 ${isDark ? 'text-slate-300' : 'text-slate-600'} text-sm max-w-3xl leading-relaxed`}>
                        Keep your staff feedback and task tracking on track with the latest pending forms, announcements, and priority notifications.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats Cards */}
              <div className="mt-8 grid gap-4 sm:grid-cols-3">
                <div className={`rounded-[24px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                  <div className="flex items-center gap-3">
                    <div className="grid h-10 w-10 place-items-center rounded-2xl bg-cyan-500/10 text-cyan-400 font-bold">📝</div>
                    <div>
                      <p className="text-xs uppercase tracking-[0.2em] font-bold text-slate-400">Pending feedback</p>
                      <p className={`mt-1 text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>{formsList.length}</p>
                    </div>
                  </div>
                </div>

                <div className={`rounded-[24px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                  <div className="flex items-center gap-3">
                    <div className="grid h-10 w-10 place-items-center rounded-2xl bg-emerald-500/10 text-emerald-400 font-bold">✅</div>
                    <div>
                      <p class="text-xs uppercase tracking-[0.2em] font-bold text-slate-400">Forms submitted</p>
                      <p className={`mt-1 text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>{historyList.length}</p>
                    </div>
                  </div>
                </div>

                <div className={`rounded-[24px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                  <div className="flex items-center gap-3">
                    <div className="grid h-10 w-10 place-items-center rounded-2xl bg-rose-500/10 text-rose-400 font-bold">📢</div>
                    <div>
                      <p className="text-xs uppercase tracking-[0.2em] font-bold text-slate-400">Announcements</p>
                      <p className={`mt-1 text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>{announcementsList.length}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Dynamic Pages */}
            <div className="p-6 md:p-10 space-y-6">
              {activePage === 'dashboard' && (
                <div className="grid gap-6 xl:grid-cols-[1.7fr_1fr]">
                  <div className={`rounded-[32px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'} p-6 shadow-xl border space-y-6`}>
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-6">
                      <div>
                        <p className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Priority Parent Feedback</p>
                        <h2 className={`mt-2 text-2xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Teacher Communication Feedback</h2>
                        <p className="mt-1 text-sm text-slate-400">Due: 26 Jul 2026</p>
                      </div>
                      <button
                        onClick={() => setFillModalForm({ course: 'Advanced AI', form: 'Teacher Communication Feedback' })}
                        className="rounded-full bg-cyan-500 px-6 py-2.5 text-sm font-bold text-slate-950 hover:bg-cyan-400 transition-all shadow-lg shadow-cyan-500/20"
                      >
                        Start Now
                      </button>
                    </div>

                    <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'} text-sm leading-relaxed`}>
                      This is your highest-priority feedback item to review and complete.
                    </p>

                    <div className={`rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                      <p className="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Deadline status</p>
                      <ul className="mt-4 space-y-3 text-sm">
                        <li className="flex items-center gap-3">
                          <span className="h-2 w-2 rounded-full bg-cyan-400"></span>
                          <span>Midterm Survey - due 26 Jul 2026</span>
                        </li>
                        <li className="flex items-center gap-3">
                          <span className="h-2 w-2 rounded-full bg-cyan-400"></span>
                          <span>Project Review - due 02 Aug 2026</span>
                        </li>
                        <li className="flex items-center gap-3">
                          <span className="h-2 w-2 rounded-full bg-cyan-400"></span>
                          <span>Course Evaluation - due 05 Aug 2026</span>
                        </li>
                      </ul>
                    </div>

                    <div className="rounded-[24px] bg-emerald-500/10 p-5 border border-emerald-500/30 text-emerald-300">
                      <p className="text-xs font-bold uppercase tracking-[0.2em] text-emerald-400">Admin Notification</p>
                      <p className="mt-2 text-sm">Admin assigned a new feedback form. Please review and submit by the due date.</p>
                    </div>
                  </div>

                  {/* Right Column */}
                  <div className="space-y-6">
                    <div className={`rounded-[32px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'} p-6 shadow-xl border`}>
                      <p className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Feedback Completion</p>
                      <h2 className={`mt-2 text-2xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Completion Progress</h2>
                      <div className={`mt-6 flex items-center justify-center rounded-[28px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-8 border`}>
                        <div className="text-center">
                          <p className={`text-5xl font-extrabold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                            {Math.round((historyList.length / (historyList.length + formsList.length || 1)) * 100)}%
                          </p>
                          <p className="mt-2 text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">
                            {historyList.length} of {historyList.length + formsList.length} Forms Done
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className={`rounded-[32px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'} p-6 shadow-xl border`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Latest Announcements</p>
                          <h2 className={`mt-1 text-xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Updates</h2>
                        </div>
                        <button
                          onClick={() => setActivePage('announcements')}
                          className="rounded-full bg-slate-800 px-4 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700"
                        >
                          View All
                        </button>
                      </div>
                      <div className="mt-4 space-y-3">
                        {announcementsList.slice(0, 2).map((item, idx) => (
                          <div key={idx} className={`rounded-[20px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-4 border`}>
                            <h3 className={`text-sm font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>{item.title}</h3>
                            <p className="mt-1 text-xs text-slate-400 leading-relaxed">{item.body}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activePage === 'profile' && (
                <div className={`rounded-[32px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'} p-8 shadow-xl border space-y-6`}>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">My Profile</p>
                    <h2 className={`mt-2 text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>{userProfile.name}</h2>
                    <p className="mt-1 text-slate-400 text-sm">Staff ID: {userProfile.staffId} • {userProfile.department}</p>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2 pt-4">
                    <div className={`rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                      <p className="text-xs font-bold uppercase tracking-[0.1em] text-slate-400">Email Address</p>
                      <p className={`mt-2 font-medium ${isDark ? 'text-white' : 'text-slate-900'}`}>{userProfile.email}</p>
                    </div>
                    <div className={`rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                      <p className="text-xs font-bold uppercase tracking-[0.1em] text-slate-400">Phone Number</p>
                      <p className={`mt-2 font-medium ${isDark ? 'text-white' : 'text-slate-900'}`}>{userProfile.phone}</p>
                    </div>
                    <div className={`rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                      <p className="text-xs font-bold uppercase tracking-[0.1em] text-slate-400">Assigned Courses</p>
                      <p className={`mt-2 font-medium ${isDark ? 'text-white' : 'text-slate-900'}`}>{userProfile.coursesAssigned}</p>
                    </div>
                    <div className={`rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                      <p className="text-xs font-bold uppercase tracking-[0.1em] text-slate-400">Pending Feedback Tasks</p>
                      <p className="mt-2 text-cyan-400 font-medium">{formsList.length} Pending</p>
                    </div>
                  </div>
                </div>
              )}

              {activePage === 'forms' && (
                <div className={`rounded-[32px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'} p-8 shadow-xl border`}>
                  <p className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Available Forms</p>
                  <h2 className={`mt-2 text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Open Feedback Surveys</h2>

                  {formsList.length === 0 ? (
                    <div className="mt-8 p-12 text-center text-slate-400 bg-slate-900/50 rounded-2xl border border-dashed border-slate-800">
                      <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
                      <p className="text-lg font-semibold text-white">All caught up!</p>
                      <p className="text-sm">You have submitted all available feedback forms.</p>
                    </div>
                  ) : (
                    <div className="mt-6 overflow-x-auto">
                      <table className="min-w-full divide-y divide-slate-800 text-left">
                        <thead className={`text-xs font-bold uppercase ${isDark ? 'bg-slate-900 text-slate-400' : 'bg-slate-100 text-slate-600'}`}>
                          <tr>
                            <th className="px-6 py-4">Course</th>
                            <th className="px-6 py-4">Form Title</th>
                            <th className="px-6 py-4">Due Date</th>
                            <th className="px-6 py-4">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60">
                          {formsList.map((item) => (
                            <tr key={item.id} className="hover:bg-cyan-500/5 transition-colors">
                              <td className={`px-6 py-4 font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>{item.course}</td>
                              <td className="px-6 py-4 text-slate-300">{item.form}</td>
                              <td className="px-6 py-4 text-slate-400 text-sm">{item.due}</td>
                              <td className="px-6 py-4">
                                <button
                                  onClick={() => setFillModalForm({ course: item.course, form: item.form })}
                                  className="rounded-full bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 px-4 py-1.5 text-xs font-bold hover:bg-cyan-500 hover:text-slate-950 transition-all"
                                >
                                  Fill Form
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {activePage === 'history' && (
                <div className={`rounded-[32px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'} p-8 shadow-xl border`}>
                  <p className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Submission History</p>
                  <h2 className={`mt-2 text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Recent Feedback Activity</h2>
                  <div className="mt-6 overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-800 text-left">
                      <thead className={`text-xs font-bold uppercase ${isDark ? 'bg-slate-900 text-slate-400' : 'bg-slate-100 text-slate-600'}`}>
                        <tr>
                          <th className="px-6 py-4">Course</th>
                          <th className="px-6 py-4">Form</th>
                          <th className="px-6 py-4">Status</th>
                          <th className="px-6 py-4">Submitted Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {historyList.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/50 transition-colors">
                            <td className={`px-6 py-4 font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>{item.course}</td>
                            <td className="px-6 py-4 text-slate-300">{item.form}</td>
                            <td className="px-6 py-4">
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                {item.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-slate-400 text-sm">{item.submitted}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activePage === 'announcements' && (
                <div className={`rounded-[32px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'} p-8 shadow-xl border`}>
                  <p className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Announcements</p>
                  <h2 className={`mt-2 text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Official Notifications & Updates</h2>
                  <div className="mt-6 space-y-4">
                    {announcementsList.map((item, idx) => (
                      <div key={idx} className={`rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-6 border`}>
                        <div className="flex items-center justify-between">
                          <h3 className={`text-lg font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>{item.title}</h3>
                          <span className="text-xs text-slate-500 font-mono">{item.date}</span>
                        </div>
                        <p className={`mt-3 ${isDark ? 'text-slate-300' : 'text-slate-600'} text-sm leading-relaxed`}>{item.body}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activePage === 'settings' && (
                <div className={`rounded-[32px] ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'} p-8 shadow-xl border`}>
                  <p className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Settings</p>
                  <h2 className={`mt-2 text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Account & Password Security</h2>

                  <form onSubmit={handleSaveSettings} className="mt-8 space-y-6 max-w-2xl">
                    <label className={`block rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Email Address <span className="text-rose-400">*</span></span>
                      <input
                        type="email"
                        required
                        value={settingsForm.email}
                        onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                        className={`mt-3 w-full rounded-xl border ${isDark ? 'border-slate-700 bg-slate-950 text-white' : 'border-slate-300 bg-white text-slate-900'} px-4 py-3 outline-none focus:border-cyan-500`}
                      />
                    </label>

                    <label className={`block rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Current Password <span class="text-rose-400">*</span></span>
                      <input
                        type="password"
                        required
                        placeholder="Enter current password"
                        value={settingsForm.currentPassword}
                        onChange={(e) => setSettingsForm({ ...settingsForm, currentPassword: e.target.value })}
                        className={`mt-3 w-full rounded-xl border ${isDark ? 'border-slate-700 bg-slate-950 text-white' : 'border-slate-300 bg-white text-slate-900'} px-4 py-3 outline-none focus:border-cyan-500`}
                      />
                    </label>

                    <div className="grid gap-6 sm:grid-cols-2">
                      <label className={`block rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                        <span className="text-xs font-bold uppercase tracking-wider text-slate-400">New Password <span className="text-rose-400">*</span></span>
                        <input
                          type="password"
                          required
                          placeholder="Enter new password"
                          value={settingsForm.newPassword}
                          onChange={(e) => setSettingsForm({ ...settingsForm, newPassword: e.target.value })}
                          className={`mt-3 w-full rounded-xl border ${isDark ? 'border-slate-700 bg-slate-950 text-white' : 'border-slate-300 bg-white text-slate-900'} px-4 py-3 outline-none focus:border-cyan-500`}
                        />
                      </label>

                      <label className={`block rounded-[24px] ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} p-5 border`}>
                        <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Confirm New Password <span className="text-rose-400">*</span></span>
                        <input
                          type="password"
                          required
                          placeholder="Confirm new password"
                          value={settingsForm.confirmPassword}
                          onChange={(e) => setSettingsForm({ ...settingsForm, confirmPassword: e.target.value })}
                          className={`mt-3 w-full rounded-xl border ${isDark ? 'border-slate-700 bg-slate-950 text-white' : 'border-slate-300 bg-white text-slate-900'} px-4 py-3 outline-none focus:border-cyan-500`}
                        />
                      </label>
                    </div>

                    <button
                      type="submit"
                      className="inline-flex items-center justify-center rounded-[24px] bg-cyan-500 px-8 py-3.5 text-sm font-bold text-slate-950 hover:bg-cyan-400 transition-all shadow-lg shadow-cyan-500/20"
                    >
                      Save Changes
                    </button>
                  </form>
                </div>
              )}
            </div>
          </main>
        </div>

      {/* Fill Form Interactive Modal */}
      {fillModalForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-[32px] bg-slate-900 border border-slate-800 p-8 shadow-2xl relative space-y-6">
            <button
              onClick={() => setFillModalForm(null)}
              className="absolute top-6 right-6 text-slate-400 hover:text-white p-2"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-cyan-400">{fillModalForm.course}</p>
              <h3 className="text-2xl font-bold text-white mt-1">{fillModalForm.form}</h3>
              <p className="text-xs text-slate-400 mt-1">Submit your staff feedback response below.</p>
            </div>

            <form onSubmit={handleFormSubmitModal} className="space-y-4">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">Overall Rating</label>
                <div className="flex gap-2">
                  {['1', '2', '3', '4', '5'].map((star) => (
                    <button
                      key={star}
                      type="button"
                      className="flex-1 py-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500 text-sm font-bold text-white transition-all"
                    >
                      ⭐ {star}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">Your Detailed Feedback</label>
                <textarea
                  required
                  rows={4}
                  value={modalFeedback}
                  onChange={(e) => setModalFeedback(e.target.value)}
                  placeholder="Provide constructive feedback and recommendations..."
                  className="w-full rounded-2xl bg-slate-950 border border-slate-800 p-4 text-sm text-white outline-none focus:border-cyan-500"
                ></textarea>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setFillModalForm(null)}
                  className="px-5 py-2.5 rounded-full bg-slate-800 text-slate-300 text-sm font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-full bg-cyan-500 text-slate-950 text-sm font-bold hover:bg-cyan-400 transition-all flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  Submit Feedback
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Floating Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-4 shadow-2xl flex items-center gap-3 text-sm text-white">
          <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0" />
          <span>{toast.message}</span>
        </div>
      )}
    </div>
  );
}
