import React from 'react';
import { PortalProvider } from './context/PortalContext';
import { MobileFrame } from './components/MobileFrame';
import { AppContent } from './components/AppContent';

export default function App() {
  return (
    <PortalProvider>
      <MobileFrame>
        <AppContent />
      </MobileFrame>
    </PortalProvider>
  );
}
