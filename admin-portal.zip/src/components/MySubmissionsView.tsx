import React, { useState } from 'react';
import { Search, ChevronRight, Download, Filter, Eye, X } from 'lucide-react';

interface MySubmissionsViewProps {
  theme?: 'light' | 'dark' | 'system';
}

export const MySubmissionsView: React.FC<MySubmissionsViewProps> = ({ theme = 'light' }) => {
  const isDark = theme === 'dark';

  const [searchTitle, setSearchTitle] = useState('');
  const [selectedYear, setSelectedYear] = useState('All Years');
  const [selectedSem, setSelectedSem] = useState('All Semesters');
  const [selectedResponseItem, setSelectedResponseItem] = useState<any | null>(null);

  const responsesData = [
    {
      id: 'r1',
      title: 'parents test',
      yearSem: '2025-2026 - Sem 5',
      status: 'Active',
      forms: 1,
      totalResponses: 14,
      avgRating: '4.7',
      sampleAnswers: [
        { q: 'Academic Progress Reporting', score: '4.8 / 5' },
        { q: 'Campus Safety & Transport', score: '4.6 / 5' }
      ]
    },
    {
      id: 'r2',
      title: 'for faculty',
      yearSem: '2025-2026 - Sem 5',
      status: 'Active',
      forms: 1,
      totalResponses: 28,
      avgRating: '4.5',
      sampleAnswers: [
        { q: 'Curriculum Depth & Industry Relevance', score: '4.6 / 5' },
        { q: 'Research Support & Lab Facilities', score: '4.4 / 5' }
      ]
    },
    {
      id: 'r3',
      title: 'test 3',
      yearSem: '2025-2026 - Sem 1',
      status: 'Active',
      forms: 1,
      totalResponses: 19,
      avgRating: '4.2',
      sampleAnswers: [
        { q: 'Orientation & Course Delivery', score: '4.2 / 5' }
      ]
    },
    {
      id: 'r4',
      title: 'test67',
      yearSem: '2025-2026',
      status: 'Draft',
      forms: 1,
      totalResponses: 0,
      avgRating: '—',
      sampleAnswers: []
    },
    {
      id: 'r5',
      title: 'testcase',
      yearSem: '2025-2026',
      status: 'Active',
      forms: 1,
      totalResponses: 12,
      avgRating: '4.1',
      sampleAnswers: [
        { q: 'General Campus Facilities', score: '4.1 / 5' }
      ]
    }
  ];

  const handleExportSubmissionsCSV = () => {
    const header = ['Session ID', 'Title', 'Year / Semester', 'Status', 'Forms Count', 'Total Responses', 'Average Rating'];
    const rows = responsesData.map(r => [r.id, r.title, r.yearSem, r.status, r.forms.toString(), r.totalResponses.toString(), r.avgRating]);
    const csvContent = [header, ...rows].map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(",")).join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'AFMS_Submissions_Summary.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filtered = responsesData.filter((r) => 
    r.title.toLowerCase().includes(searchTitle.toLowerCase())
  );

  return (
    <div className="space-y-5 max-w-7xl mx-auto animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            Responses & Submissions by Session
          </h1>
          <p className="text-xs font-semibold text-zinc-500 mt-0.5">
            Aggregated feedback submission metrics grouped by session. Total sessions: {responsesData.length}
          </p>
        </div>

        <button 
          onClick={handleExportSubmissionsCSV}
          className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export Responses CSV</span>
        </button>
      </div>

      {/* Filter Bar Box */}
      <div className={`p-4 rounded-3xl border ${
        isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
      }`}>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Search Session</label>
            <input
              type="text"
              placeholder="Search by title..."
              value={searchTitle}
              onChange={(e) => setSearchTitle(e.target.value)}
              className={`w-full text-xs rounded-2xl px-3.5 py-2.5 border focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-white placeholder-zinc-500' : 'bg-slate-50 border-zinc-200 text-zinc-900'
              }`}
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Academic Year</label>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Years">All Years</option>
              <option value="2025-2026">2025-2026</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Semester</label>
            <select
              value={selectedSem}
              onChange={(e) => setSelectedSem(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3.5 py-2.5 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Semesters">All Semesters</option>
              <option value="Sem 1">Sem 1</option>
              <option value="Sem 5">Sem 5</option>
            </select>
          </div>
        </div>
      </div>

      {/* Responses Table */}
      <div className={`rounded-3xl border overflow-hidden ${
        isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
      }`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className={`text-[10px] font-black uppercase tracking-wider border-b ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-400' : 'bg-slate-50 border-zinc-200 text-zinc-500'
              }`}>
                <th className="py-3 px-4">SESSION TITLE</th>
                <th className="py-3 px-4">FORMS</th>
                <th className="py-3 px-4">TOTAL RESPONSES</th>
                <th className="py-3 px-4">AVG RATING</th>
                <th className="py-3 px-4 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800/60 text-xs">
              {filtered.map((item) => (
                <tr key={item.id} className="hover:bg-zinc-500/5 transition-colors">
                  <td className="py-4 px-4">
                    <p className="font-extrabold text-sm">{item.title}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-zinc-400 font-medium">{item.yearSem}</span>
                      <span className={`px-2 py-0.5 rounded text-[9px] font-extrabold ${
                        item.status === 'Active' 
                          ? 'bg-slate-800 text-zinc-300' 
                          : 'bg-zinc-800 text-zinc-400'
                      }`}>
                        {item.status}
                      </span>
                    </div>
                  </td>

                  <td className="py-4 px-4 font-bold">{item.forms}</td>

                  <td className="py-4 px-4 font-bold">{item.totalResponses}</td>

                  <td className="py-4 px-4 font-extrabold">
                    {item.avgRating === '—' ? (
                      <span className="text-zinc-400">—</span>
                    ) : (
                      <span className="text-amber-500 font-black">{item.avgRating} / 5.0</span>
                    )}
                  </td>

                  <td className="py-4 px-4 text-right">
                    <button 
                      onClick={() => setSelectedResponseItem(item)}
                      className="text-xs font-bold text-orange-500 hover:text-orange-400 transition-colors inline-flex items-center gap-1 cursor-pointer"
                    >
                      <span>View Responses</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Response Detail Modal */}
      {selectedResponseItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className={`w-full max-w-md rounded-3xl p-6 border shadow-2xl animate-in zoom-in-95 duration-150 ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-white' : 'bg-white border-zinc-200 text-zinc-900'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
              <h3 className="text-sm font-black flex items-center gap-2">
                <Eye className="w-4 h-4 text-orange-500" />
                {selectedResponseItem.title} - Submission Details
              </h3>
              <button onClick={() => setSelectedResponseItem(null)} className="p-1 rounded-lg text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-3">
              <p className="text-xs text-zinc-400">Total Submissions: <span className="font-bold text-white">{selectedResponseItem.totalResponses}</span></p>
              <p className="text-xs text-zinc-400">Overall Score: <span className="font-bold text-amber-500">{selectedResponseItem.avgRating}</span></p>

              <div className="space-y-2 pt-2">
                <p className="text-[10px] font-black uppercase text-zinc-400">Section Ratings Breakdown:</p>
                {selectedResponseItem.sampleAnswers?.length > 0 ? (
                  selectedResponseItem.sampleAnswers.map((sa: any, idx: number) => (
                    <div key={idx} className={`p-3 rounded-2xl text-xs font-medium border flex items-center justify-between ${
                      isDark ? 'bg-[#120e0d] border-[#221c19]' : 'bg-slate-50 border-zinc-200'
                    }`}>
                      <span>{sa.q}</span>
                      <span className="font-bold text-amber-500">{sa.score}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-zinc-500 italic">No responses logged for this draft session yet.</p>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800 flex justify-end">
              <button 
                onClick={() => setSelectedResponseItem(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-white font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
