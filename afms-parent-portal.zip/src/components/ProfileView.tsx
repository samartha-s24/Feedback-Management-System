import React from 'react';
import { usePortal } from '../context/PortalContext';
import { getAccentClasses } from '../utils/theme';
import { User, GraduationCap, Edit3, ShieldCheck, Mail, Phone, MapPin, CalendarCheck, FileCheck } from 'lucide-react';

export const ProfileView: React.FC = () => {
  const { parent, student, openEditProfileModal, setActiveTab, accentTheme } = usePortal();
  const accent = getAccentClasses(accentTheme);

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Header Profile Card */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3 min-w-0">
          <div className={`w-12 h-12 rounded-2xl ${accent.bgGradient} flex items-center justify-center text-slate-950 font-black text-lg shadow-md shrink-0`}>
            {parent.name.replace(/^Mr\.?|^Mrs\.?|^Ms\.?/i, '').trim().charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0">
            <h1 className="text-base font-bold text-slate-100 truncate">{parent.name}</h1>
            <p className="text-xs text-slate-400 font-mono">Parent ID: {parent.id}</p>
            <p className="text-[11px] text-cyan-400 font-medium">Relationship: {parent.relationship}</p>
          </div>
        </div>

        <button
          onClick={openEditProfileModal}
          className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-700 shrink-0 active:scale-95"
        >
          <Edit3 className="w-3.5 h-3.5 text-cyan-400" />
          <span>Edit</span>
        </button>
      </div>

      {/* Parent Information Panel */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-3 shadow-md">
        <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
          <User className="w-4 h-4 text-cyan-400" />
          <span>Parent Details</span>
        </h2>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 flex items-center gap-2">
              <User className="w-3.5 h-3.5 text-slate-500" />
              <span>Full Name</span>
            </span>
            <span className="font-semibold text-slate-100">{parent.name}</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-slate-500" />
              <span>Email Address</span>
            </span>
            <span className="font-semibold text-slate-100 truncate max-w-[180px]">{parent.email}</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-slate-500" />
              <span>Mobile Phone</span>
            </span>
            <span className="font-semibold text-slate-100">{parent.mobile}</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-slate-500" />
              <span>Residential Address</span>
            </span>
            <span className="font-semibold text-slate-100">{parent.address}</span>
          </div>
        </div>
      </div>

      {/* Student Information Panel */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 space-y-3 shadow-md">
        <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
          <GraduationCap className="w-4 h-4 text-emerald-400" />
          <span>Student Information</span>
        </h2>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400">Student Name</span>
            <span className="font-bold text-slate-100">{student.name}</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400">PRN Number</span>
            <span className="font-mono font-bold text-cyan-400">{student.prn}</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400">Year & Level</span>
            <span className="font-semibold text-slate-200">{student.yearLevel}</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400">Division</span>
            <span className="font-semibold text-slate-200">{student.division}</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400">Department</span>
            <span className="font-semibold text-slate-200">{student.department}</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400">Academic Year</span>
            <span className="font-semibold text-slate-200">{student.academicYear}</span>
          </div>
        </div>
      </div>

      {/* Quick Profile Shortcuts */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          onClick={() => setActiveTab('attendance')}
          className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-left hover:border-cyan-500/50 transition-all flex items-center gap-2.5 active:scale-98"
        >
          <CalendarCheck className="w-5 h-5 text-cyan-400 shrink-0" />
          <div>
            <span className="text-xs font-bold text-slate-100 block">Check Attendance</span>
            <span className="text-[10px] text-slate-400">{student.attendance} Overall</span>
          </div>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-left hover:border-emerald-500/50 transition-all flex items-center gap-2.5 active:scale-98"
        >
          <FileCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <span className="text-xs font-bold text-slate-100 block">Form History</span>
            <span className="text-[10px] text-slate-400">View submissions</span>
          </div>
        </button>
      </div>
    </div>
  );
};
