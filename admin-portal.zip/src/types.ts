export type TabType = 
  | 'overview' 
  | 'profile' 
  | 'sessions' 
  | 'questionnaires' 
  | 'questions' 
  | 'responses' 
  | 'analytics' 
  | 'reports' 
  | 'announcements' 
  | 'audit_log' 
  | 'settings' 
  | 'my_submissions';

export type SessionStatus = 'active' | 'urgent' | 'closed';

export interface FeedbackSession {
  id: string;
  title: string;
  department: string;
  targetAudience: string;
  responsesCount: number;
  totalTarget: number;
  averageRating: number;
  positivePercent: number;
  deadline: string;
  status: SessionStatus;
  questionsCount: number;
  createdAt: string;
}

export type QuestionCategory = 'Faculty & Teaching' | 'Curriculum & Syllabus' | 'Campus & Infrastructure' | 'Labs & Equipment' | 'Hostel & Canteen';

export interface QuestionItem {
  id: string;
  category: QuestionCategory;
  text: string;
  type: 'rating' | 'multiple_choice' | 'text_feedback';
  usageCount: number;
  addedBy: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  priority: 'high' | 'medium' | 'low';
  targetGroup: string;
  date: string;
  author: string;
}

export interface MetricCardData {
  id: string;
  label: string;
  value: string | number;
  subtext: string;
  change: string;
  isPositive: boolean;
  color: 'orange' | 'cyan' | 'purple' | 'green' | 'red' | 'yellow' | 'blue' | 'emerald';
  icon: string;
  category: TabType | 'all';
}

export interface SubmissionTrendPoint {
  date: string;
  responses: number;
  target: number;
}

export interface SentimentDataPoint {
  name: string;
  value: number;
  color: string;
  [key: string]: unknown;
}

export interface DepartmentRating {
  department: string;
  rating: number;
  responses: number;
  positivePct: number;
}

export interface AdminNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'urgent' | 'info' | 'success';
}

export interface AiSummaryResult {
  headline: string;
  keyStrengths: string[];
  areasOfConcern: string[];
  recommendations: string[];
}
