import React, { useState } from 'react';
import { Filter, TrendingUp, BarChart2, PieChart as PieIcon, Sparkles } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from 'recharts';

interface AiAnalyticsViewProps {
  theme?: 'light' | 'dark' | 'system';
}

export const AiAnalyticsView: React.FC<AiAnalyticsViewProps> = ({ theme = 'light' }) => {
  const isDark = theme === 'dark';

  const [department, setDepartment] = useState('All Departments');
  const [year, setYear] = useState('All Years');
  const [semester, setSemester] = useState('All Semesters');
  const [session, setSession] = useState('All Sessions');
  const [questionnaire, setQuestionnaire] = useState('All Questionnaires');

  const categoryRatingData = [
    { category: 'Course Delivery', rating: 3.5 },
    { category: 'Teaching Method', rating: 3.2 },
    { category: 'Lab & Infra', rating: 3.8 },
    { category: 'Course Materials', rating: 3.1 },
  ];

  const sentimentData = [
    { name: 'Positive', value: 60, color: '#10b981' },
    { name: 'Neutral', value: 25, color: '#f59e0b' },
    { name: 'Negative', value: 15, color: '#ef4444' },
  ];

  return (
    <div className="space-y-5 max-w-7xl mx-auto animate-in fade-in duration-200">
      
      {/* Header */}
      <div>
        <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
          Analytics Dashboard
        </h1>
        <p className="text-xs font-semibold text-zinc-500 mt-0.5">
          Deep dive into feedback data with department-wise filtering.
        </p>
      </div>

      {/* Filter Row Box */}
      <div className={`p-4 rounded-3xl border ${
        isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
      }`}>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2.5 items-end">
          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Department</label>
            <select
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Departments">All Departments</option>
              <option value="CSE">Computer Science</option>
              <option value="ECE">Electronics</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Academic Year</label>
            <select
              value={year}
              onChange={(e) => setYear(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Years">All Years</option>
              <option value="2025-2026">2025-2026</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Semester</label>
            <select
              value={semester}
              onChange={(e) => setSemester(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Semesters">All Semesters</option>
              <option value="Sem 1">Sem 1</option>
              <option value="Sem 5">Sem 5</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Session</label>
            <select
              value={session}
              onChange={(e) => setSession(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Sessions">All Sessions</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-400 mb-1 uppercase tracking-wider">Questionnaire</label>
            <select
              value={questionnaire}
              onChange={(e) => setQuestionnaire(e.target.value)}
              className={`w-full text-xs font-bold rounded-2xl px-3 py-2 border cursor-pointer ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-200' : 'bg-slate-50 border-zinc-200 text-zinc-800'
              }`}
            >
              <option value="All Questionnaires">All Questionnaires</option>
            </select>
          </div>

          <div>
            <button className="w-full text-xs font-bold py-2.5 px-4 rounded-2xl bg-[#ea580c] hover:bg-[#c2410c] text-white transition-all shadow-md shadow-orange-500/20">
              Filter
            </button>
          </div>
        </div>
      </div>

      {/* 4 Key Metric Cards matching Screenshot 4 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: ELIGIBLE in prominent Orange */}
        <div className="p-5 rounded-3xl bg-[#ea580c] text-white shadow-lg shadow-orange-500/20 flex flex-col justify-between">
          <p className="text-[10px] font-black uppercase tracking-wider opacity-80">ELIGIBLE</p>
          <p className="text-4xl font-black mt-2">32</p>
        </div>

        {/* Card 2: TOTAL RESPONSES */}
        <div className={`p-5 rounded-3xl border flex flex-col justify-between ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-black uppercase tracking-wider text-zinc-400">TOTAL RESPONSES</p>
            <span className="text-xs font-bold text-emerald-500">21.9% Rate</span>
          </div>
          <p className="text-4xl font-black mt-2">7</p>
        </div>

        {/* Card 3: AVERAGE SCORE */}
        <div className={`p-5 rounded-3xl border flex flex-col justify-between ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <p className="text-[10px] font-black uppercase tracking-wider text-zinc-400">AVERAGE SCORE</p>
          <p className="text-4xl font-black mt-2 text-amber-500">
            3.28<span className="text-sm text-zinc-400 font-bold">/5</span>
          </p>
        </div>

        {/* Card 4: COMPLETION */}
        <div className={`p-5 rounded-3xl border flex flex-col justify-between ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-black uppercase tracking-wider text-zinc-400">COMPLETION</p>
            <span className="text-xs font-bold text-zinc-400">5 Comments</span>
          </div>
          <p className="text-4xl font-black mt-2">100%</p>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Bar Chart: Average Rating by Category */}
        <div className={`lg:col-span-2 p-5 rounded-3xl border space-y-4 ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <h3 className="text-sm font-extrabold flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-indigo-500" />
            <span>Average Rating by Category</span>
          </h3>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryRatingData}>
                <XAxis dataKey="category" stroke="#888888" fontSize={10} tickLine={false} />
                <YAxis domain={[1, 5]} stroke="#888888" fontSize={10} tickLine={false} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: isDark ? '#181210' : '#ffffff', 
                    borderRadius: '12px',
                    borderColor: '#3b82f6',
                    color: isDark ? '#ffffff' : '#000000'
                  }} 
                />
                <Bar dataKey="rating" fill="#3b82f6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Donut Chart: Sentiment Balance */}
        <div className={`p-5 rounded-3xl border space-y-4 ${
          isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-100' : 'bg-white border-zinc-200 text-zinc-900 shadow-xs'
        }`}>
          <h3 className="text-sm font-extrabold flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-emerald-500" />
            <span>Sentiment Balance</span>
          </h3>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sentimentData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {sentimentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

    </div>
  );
};
