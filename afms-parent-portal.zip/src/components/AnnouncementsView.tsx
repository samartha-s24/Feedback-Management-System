import React, { useState } from 'react';
import { usePortal } from '../context/PortalContext';
import { getAccentClasses } from '../utils/theme';
import { Priority } from '../types';
import { Megaphone, Download, Eye, AlertCircle, FileText, Filter } from 'lucide-react';

export const AnnouncementsView: React.FC = () => {
  const { announcements, openInfoModal, showToast, accentTheme } = usePortal();
  const accent = getAccentClasses(accentTheme);

  const [filter, setFilter] = useState<Priority | 'all'>('all');

  const filtered = announcements.filter((a) => (filter === 'all' ? true : a.priority === filter));

  const priorityStyles: Record<Priority, { badge: string; text: string }> = {
    high: { badge: 'bg-rose-500/15 text-rose-400 border-rose-500/20', text: 'High Priority' },
    medium: { badge: 'bg-amber-500/15 text-amber-400 border-amber-500/20', text: 'Medium Priority' },
    low: { badge: 'bg-teal-500/15 text-teal-400 border-teal-500/20', text: 'Low Priority' },
  };

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Header */}
      <div className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 shadow-sm">
        <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <Megaphone className="w-5 h-5 text-indigo-400" />
          <span>School Announcements</span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Official circulars, exam timetables, and notices from Autonomous College.
        </p>
      </div>

      {/* Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-xs font-semibold text-slate-500 flex items-center gap-1 shrink-0 mr-1">
          <Filter className="w-3.5 h-3.5" />
        </span>
        {(['all', 'high', 'medium', 'low'] as const).map((p) => {
          const isActive = filter === p;
          return (
            <button
              key={p}
              onClick={() => setFilter(p)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold capitalize transition-all shrink-0 ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900/80 text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {p === 'all' ? 'All Notices' : `${p} Priority`}
            </button>
          );
        })}
      </div>

      {/* Notice List */}
      <div className="space-y-3">
        {filtered.map((item) => {
          const style = priorityStyles[item.priority];
          return (
            <div
              key={item.id}
              className="p-4 rounded-2xl bg-slate-900/90 dark:bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all space-y-2.5 shadow-md"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="text-xl shrink-0">{item.icon}</span>
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold text-slate-100 truncate">{item.title}</h3>
                    <span className="text-[10px] text-slate-400">{item.date}</span>
                  </div>
                </div>
                <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold border shrink-0 ${style.badge}`}>
                  {style.text}
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/60">
                {item.desc}
              </p>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  onClick={() => openInfoModal(item.title, item.desc)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors active:scale-95"
                >
                  <Eye className="w-3.5 h-3.5 text-cyan-400" />
                  <span>View Notice</span>
                </button>

                {item.pdf && (
                  <button
                    onClick={() => showToast(`📥 Downloading circular attachment for "${item.title}"...`)}
                    className="px-3 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-cyan-500/20 active:scale-95"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
