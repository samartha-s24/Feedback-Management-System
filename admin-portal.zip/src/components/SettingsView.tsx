import React from 'react';
import { 
  Sun,
  Moon,
  Monitor,
  Bell,
  Laptop
} from 'lucide-react';

interface SettingsViewProps {
  theme?: 'light' | 'dark' | 'system';
  setTheme?: (theme: 'light' | 'dark' | 'system') => void;
  emailNotifications: boolean;
  setEmailNotifications: (val: boolean) => void;
  showToast?: (msg: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  theme = 'light',
  setTheme,
  emailNotifications,
  setEmailNotifications,
  showToast
}) => {
  const isDark = theme === 'dark';

  const handleThemeChange = (newTheme: 'light' | 'dark' | 'system') => {
    if (setTheme) {
      setTheme(newTheme);
    }
    if (showToast) showToast(`Theme updated to ${newTheme} mode`);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-in fade-in duration-200">
      
      {/* Settings Page Title */}
      <div>
        <h1 className={`text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
          Settings
        </h1>
      </div>

      {/* Main Settings Card Container */}
      <div className={`rounded-3xl border p-6 sm:p-8 space-y-8 shadow-sm ${
        isDark 
          ? 'bg-[#0f172a] border-zinc-800 text-zinc-100' 
          : 'bg-white border-zinc-200 text-zinc-900'
      }`}>

        {/* APPEARANCE / THEME SELECTION SECTION */}
        <div className="space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-500">
            APPEARANCE
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Light Mode Button */}
            <button
              onClick={() => handleThemeChange('light')}
              className={`flex items-center justify-center gap-2 py-3 px-4 rounded-2xl border text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                theme === 'light'
                  ? 'bg-orange-50 border-orange-500 text-orange-700 shadow-sm font-bold ring-1 ring-orange-500 dark:bg-orange-950/40 dark:text-orange-300'
                  : isDark
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:text-zinc-900'
              }`}
            >
              <Sun className="w-4 h-4 text-amber-500" />
              <span>Light Mode</span>
            </button>

            {/* Dark Mode Button */}
            <button
              onClick={() => handleThemeChange('dark')}
              className={`flex items-center justify-center gap-2 py-3 px-4 rounded-2xl border text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                theme === 'dark'
                  ? 'bg-orange-50 border-orange-500 text-orange-700 shadow-sm font-bold ring-1 ring-orange-500 dark:bg-orange-950/40 dark:text-orange-300'
                  : isDark
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:text-zinc-900'
              }`}
            >
              <Moon className="w-4 h-4 text-indigo-400" />
              <span>Dark Mode</span>
            </button>

            {/* System Mode Button */}
            <button
              onClick={() => handleThemeChange('system')}
              className={`flex items-center justify-center gap-2 py-3 px-4 rounded-2xl border text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                theme === 'system'
                  ? 'bg-orange-50 border-orange-500 text-orange-700 shadow-sm font-bold ring-1 ring-orange-500 dark:bg-orange-950/40 dark:text-orange-300'
                  : isDark
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:text-zinc-900'
              }`}
            >
              <Monitor className="w-4 h-4 text-zinc-500" />
              <span>System Theme</span>
            </button>
          </div>
        </div>

        {/* NOTIFICATIONS SECTION */}
        <div className="space-y-3 pt-2 border-t border-zinc-200 dark:border-zinc-800/80">
          <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1.5">
            <Bell className="w-3.5 h-3.5" />
            NOTIFICATIONS
          </h2>

          <div className="flex items-center justify-between gap-4">
            <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400">
              Receive an email when new feedback forms are released to Employees.
            </p>

            {/* Toggle Switch */}
            <button
              onClick={() => {
                const nextVal = !emailNotifications;
                setEmailNotifications(nextVal);
                if (showToast) showToast(nextVal ? 'Email notifications enabled' : 'Email notifications disabled');
              }}
              className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                emailNotifications ? 'bg-orange-600' : 'bg-zinc-300 dark:bg-zinc-700'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  emailNotifications ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

      </div>

      {/* Settings Page Footer */}
      <div className="pt-6 border-t border-zinc-200 dark:border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-zinc-500">
        <div>
          © 2026 Autonomous Feedback Management System — Autonomous College
        </div>
        <div className="flex items-center gap-2">
          <span>Employee Portal v2.1</span>
          <span>•</span>
          <span className="text-emerald-500 font-semibold flex items-center gap-1">
            <Laptop className="w-3.5 h-3.5" />
            Laptop & Mobile Sync
          </span>
        </div>
      </div>

    </div>
  );
};
