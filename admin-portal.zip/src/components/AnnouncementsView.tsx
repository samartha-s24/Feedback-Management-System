import React, { useState } from 'react';
import { Plus, Link as LinkIcon, Edit3, Trash2, Filter, Download } from 'lucide-react';
import { Announcement } from '../types';

interface AnnouncementsViewProps {
  announcements?: Announcement[];
  onOpenNewAnnouncementModal: () => void;
  searchQuery?: string;
  theme?: 'light' | 'dark' | 'system';
}

export const AnnouncementsView: React.FC<AnnouncementsViewProps> = ({
  onOpenNewAnnouncementModal,
  theme = 'light'
}) => {
  const isDark = theme === 'dark';

  const [statusFilter, setStatusFilter] = useState('All Statuses');

  const [announcementRows, setAnnouncementRows] = useState([
    {
      id: 'a1',
      title: 'Welcome parents',
      link: 'parents test',
      audience: 'Parent',
      dates: '23 Jul – 31 Jul 2026',
      priority: 'High',
      status: 'Published'
    },
    {
      id: 'a2',
      title: 'welcome faculty',
      link: null,
      audience: 'Faculty',
      dates: '22 Jul – 30 Jul 2026',
      priority: 'High',
      status: 'Published'
    },
    {
      id: 'a3',
      title: 'pop up test 2',
      link: 'test67',
      audience: 'Student',
      dates: '22 Jul – 23 Jul 2026',
      priority: 'High',
      status: 'Expired'
    },
    {
      id: 'a4',
      title: 'pop up test',
      link: null,
      audience: 'Student',
      dates: '21 Jul – 22 Jul 2026',
      priority: 'High',
      status: 'Expired'
    },
    {
      id: 'a5',
      title: 'important',
      link: 'testcase',
      audience: 'Student',
      dates: '20 Jul – 25 Jul 2026',
      priority: 'High',
      status: 'Published'
    },
    {
      id: 'a6',
      title: 'test 3',
      link: null,
      audience: 'All',
      dates: '19 Jul – 22 Jul 2026',
      priority: 'High',
      status: 'Expired'
    }
  ]);

  const handleDeleteAnnouncement = (id: string) => {
    if (confirm('Are you sure you want to delete this announcement?')) {
      setAnnouncementRows(prev => prev.filter(a => a.id !== id));
    }
  };

  const handleToggleStatus = (id: string) => {
    setAnnouncementRows(prev => prev.map(a => {
      if (a.id === id) {
        return {
          ...a,
          status: a.status === 'Published' ? 'Expired' : 'Published'
        };
      }
      return a;
    }));
  };

  const handleExportAnnouncementsCSV = () => {
    const header = ['ID', 'Title', 'Associated Link', 'Audience', 'Dates', 'Priority', 'Status'];
    const rows = announcementRows.map(a => [a.id, a.title, a.link || 'N/A', a.audience, a.dates, a.priority, a.status]);
    const csvContent = [header, ...rows].map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(",")).join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'AFMS_Announcements.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filtered = announcementRows.filter(a => {
    if (statusFilter === 'All Statuses') return true;
    return a.status === statusFilter;
  });

  return (
    <div className="space-y-5 max-w-7xl mx-auto animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>
            Announcements
          </h1>
          <p className="text-xs font-semibold text-zinc-500 mt-0.5">
            Manage system-wide alerts and notifications.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button 
            onClick={handleExportAnnouncementsCSV}
            className="px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button 
            onClick={onOpenNewAnnouncementModal}
            className="px-4 py-2.5 rounded-2xl bg-[#ea580c] hover:bg-[#c2410c] text-white font-bold text-xs shadow-lg shadow-orange-500/20 transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>New Announcement</span>
          </button>
        </div>
      </div>

      {/* Filter Row */}
      <div className="flex items-center gap-2">
        <select 
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className={`text-xs font-bold rounded-2xl px-4 py-2.5 border cursor-pointer ${
            isDark ? 'bg-[#181210] border-[#2e2623] text-zinc-200' : 'bg-white border-zinc-200 text-zinc-800 shadow-xs'
          }`}
        >
          <option value="All Statuses">All Statuses</option>
          <option value="Published">Published</option>
          <option value="Expired">Expired</option>
        </select>
      </div>

      {/* Data Table */}
      <div className={`rounded-3xl border overflow-hidden ${
        isDark ? 'bg-[#181210] border-[#2e2623]' : 'bg-white border-zinc-200 shadow-xs'
      }`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className={`text-[10px] font-black uppercase tracking-wider border-b ${
                isDark ? 'bg-[#120e0d] border-[#221c19] text-zinc-400' : 'bg-slate-50 border-zinc-200 text-zinc-500'
              }`}>
                <th className="py-3.5 px-4">TITLE</th>
                <th className="py-3.5 px-4">AUDIENCE</th>
                <th className="py-3.5 px-4">DATES</th>
                <th className="py-3.5 px-4">PRIORITY</th>
                <th className="py-3.5 px-4">STATUS</th>
                <th className="py-3.5 px-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800/60 text-xs">
              {filtered.map((item) => (
                <tr key={item.id} className="hover:bg-zinc-500/5 transition-colors">
                  <td className="py-4 px-4">
                    <p className="font-extrabold text-sm">{item.title}</p>
                    {item.link && (
                      <p className="text-[10px] text-zinc-400 mt-0.5 flex items-center gap-1">
                        <LinkIcon className="w-3 h-3" />
                        <span>{item.link}</span>
                      </p>
                    )}
                  </td>

                  <td className="py-4 px-4 font-medium text-zinc-400">{item.audience}</td>

                  <td className="py-4 px-4 font-medium text-zinc-400">{item.dates}</td>

                  <td className="py-4 px-4">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-500 border border-amber-500/20">
                      {item.priority}
                    </span>
                  </td>

                  <td className="py-4 px-4">
                    <button 
                      onClick={() => handleToggleStatus(item.id)}
                      title="Click to toggle status"
                      className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold transition-all cursor-pointer ${
                        item.status === 'Published'
                          ? 'bg-blue-500/10 text-blue-500 border border-blue-500/20 hover:bg-blue-500/20'
                          : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 hover:bg-amber-500/20'
                      }`}
                    >
                      {item.status}
                    </button>
                  </td>

                  <td className="py-4 px-4 text-right">
                    <div className="flex items-center justify-end gap-1 text-zinc-400">
                      <button 
                        onClick={() => handleDeleteAnnouncement(item.id)}
                        className="p-1.5 rounded-lg hover:bg-rose-500/10 hover:text-rose-500"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
