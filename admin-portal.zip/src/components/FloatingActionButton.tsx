import React, { useState } from 'react';
import { Plus, Radio, HelpCircle, Megaphone, Zap, X } from 'lucide-react';

interface FloatingActionButtonProps {
  onOpenNewSession: () => void;
  onOpenNewQuestion: () => void;
  onOpenNewAnnouncement: () => void;
  onSimulateResponse: () => void;
}

export const FloatingActionButton: React.FC<FloatingActionButtonProps> = ({
  onOpenNewSession,
  onOpenNewQuestion,
  onOpenNewAnnouncement,
  onSimulateResponse,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-20 right-4 z-40 flex flex-col items-end gap-2.5">
      {/* Speed dial items */}
      {isOpen && (
        <div className="flex flex-col items-end gap-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <button
            onClick={() => { onSimulateResponse(); setIsOpen(false); }}
            className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-emerald-500 text-zinc-950 font-bold text-xs shadow-lg shadow-emerald-500/30 hover:scale-105 transition-transform"
          >
            <span>Simulate 5 Responses</span>
            <Zap className="w-4 h-4 fill-zinc-950" />
          </button>

          <button
            onClick={() => { onOpenNewSession(); setIsOpen(false); }}
            className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-orange-500 text-zinc-950 font-bold text-xs shadow-lg shadow-orange-500/30 hover:scale-105 transition-transform"
          >
            <span>New Session</span>
            <Radio className="w-4 h-4" />
          </button>

          <button
            onClick={() => { onOpenNewQuestion(); setIsOpen(false); }}
            className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-purple-500 text-zinc-950 font-bold text-xs shadow-lg shadow-purple-500/30 hover:scale-105 transition-transform"
          >
            <span>Add Question</span>
            <HelpCircle className="w-4 h-4" />
          </button>

          <button
            onClick={() => { onOpenNewAnnouncement(); setIsOpen(false); }}
            className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-rose-500 text-zinc-950 font-bold text-xs shadow-lg shadow-rose-500/30 hover:scale-105 transition-transform"
          >
            <span>Broadcast Notice</span>
            <Megaphone className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main trigger button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-12 h-12 rounded-2xl flex items-center justify-center text-zinc-950 font-black shadow-xl transition-all duration-300 active:scale-95 ${
          isOpen 
            ? 'bg-zinc-800 text-white rotate-45 border border-zinc-700' 
            : 'bg-gradient-to-tr from-orange-500 to-amber-400 shadow-orange-500/30 hover:scale-105'
        }`}
        aria-label="Quick Actions"
      >
        <Plus className="w-6 h-6" />
      </button>
    </div>
  );
};
