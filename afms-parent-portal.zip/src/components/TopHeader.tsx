import React, { useState } from 'react';
import { usePortal } from '../context/PortalContext';
import { getAccentClasses } from '../utils/theme';
import {
  Bell,
  Sun,
  Moon,
  Menu,
  X,
  GraduationCap,
  User,
  Settings,
  LogOut,
  ChevronRight,
  ClipboardList,
  CheckCircle2,
  Megaphone,
  CalendarCheck,
} from 'lucide-react';
import { TabType } from '../types';

export const TopHeader: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    parent,
    student,
    isDarkMode,
    toggleDarkMode,
    accentTheme,
    submissions,
    activeForms,
    announcements,
    openLogoutModal,
    showToast,
  } = usePortal();

  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isSideDrawerOpen, setIsSideDrawerOpen] = useState(false);

  const accent = getAccentClasses(accentTheme);
  const pendingFormsCount = activeForms.filter((f) => !submissions.some((s) => s.formId === f.id)).length;

  const pageTitleMap: Record<TabType, { main: string; sub: string }> = {
    dashboard: { main: 'Autonomous College', sub: 'Parent Portal · Dashboard' },
    forms: { main: 'Feedback Forms', sub: 'Parent Portal · Active Forms' },
    attendance: { main: 'Child Attendance', sub: 'Parent Portal · Attendance Record' },
    announcements: { main: 'Announcements', sub: 'Parent Portal · Notice Board' },
    history: { main: 'Submission History', sub: 'Parent Portal · Completed Feedback' },
    profile: { main: 'My Profile', sub: 'Parent Portal · Parent & Student Info' },
    settings: { main: 'Settings', sub: 'Parent Portal · App Preferences' },
  };

  const navItems: { id: TabType; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <GraduationCap className="w-5 h-5" /> },
    { id: 'forms', label: 'Available Feedback', icon: <ClipboardList className="w-5 h-5" />, badge: pendingFormsCount },
    { id: 'attendance', label: 'Child Attendance', icon: <CalendarCheck className="w-5 h-5" /> },
    { id: 'history', label: 'Submission History', icon: <CheckCircle2 className="w-5 h-5" />, badge: submissions.length },
    { id: 'announcements', label: 'Announcements', icon: <Megaphone className="w-5 h-5" />, badge: announcements.length },
    { id: 'profile', label: 'My Profile', icon: <User className="w-5 h-5" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" /> },
  ];

  const handleNavClick = (tab: TabType) => {
    setActiveTab(tab);
    setIsSideDrawerOpen(false);
    setIsProfileMenuOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-slate-900/95 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80 px-3 py-2.5 sm:px-4 sm:py-3 transition-colors">
        <div className="flex items-center justify-between gap-2 max-w-lg mx-auto">
          {/* Left: Hamburger & Page Title */}
          <div className="flex items-center gap-2 min-w-0">
            <button
              onClick={() => setIsSideDrawerOpen(true)}
              className="p-2 rounded-xl bg-slate-800/60 dark:bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors focus:outline-none"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex flex-col min-w-0 leading-tight">
              <span className="text-sm sm:text-base font-bold text-slate-100 truncate">
                {pageTitleMap[activeTab].main}
              </span>
              <span className="text-[10px] sm:text-xs text-slate-400 font-medium truncate uppercase tracking-wider">
                {pageTitleMap[activeTab].sub}
              </span>
            </div>
          </div>

          {/* Right: Theme Toggle, Notifications, Profile Avatar */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Theme Toggle */}
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-full bg-slate-800/60 dark:bg-slate-900/80 text-slate-300 hover:text-amber-400 transition-colors"
              title="Toggle theme"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-sky-400" />}
            </button>

            {/* Notification Bell */}
            <button
              onClick={() =>
                showToast(`📢 ${announcements.length} notices & ${pendingFormsCount} pending feedback form(s).`)
              }
              className="relative p-2 rounded-full bg-slate-800/60 dark:bg-slate-900/80 text-slate-300 hover:text-white transition-colors"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {(pendingFormsCount > 0 || announcements.length > 0) && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-cyan-400 ring-2 ring-slate-950 animate-pulse" />
              )}
            </button>

            {/* Profile Avatar Trigger */}
            <div className="relative">
              <button
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                className="flex items-center gap-1.5 p-1 rounded-full hover:bg-slate-800/50 transition-colors"
              >
                <div className={`w-8 h-8 rounded-full ${accent.bgGradient} flex items-center justify-center font-bold text-slate-950 text-xs shadow-sm ring-2 ring-slate-800`}>
                  {parent.name.replace(/^Mr\.?|^Mrs\.?|^Ms\.?/i, '').trim().charAt(0).toUpperCase() || 'P'}
                </div>
              </button>

              {/* Profile Dropdown */}
              {isProfileMenuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setIsProfileMenuOpen(false)}
                  />
                  <div className="absolute right-0 top-10 mt-1 w-48 z-50 bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-2 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-3 py-2 border-b border-slate-800 mb-1">
                      <p className="text-xs font-semibold text-slate-100 truncate">{parent.name}</p>
                      <p className="text-[10px] text-slate-400 font-mono">ID: {parent.id}</p>
                      <p className="text-[10px] text-slate-400 truncate mt-0.5">Ward: {student.name}</p>
                    </div>

                    <button
                      onClick={() => handleNavClick('profile')}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors"
                    >
                      <User className="w-3.5 h-3.5 text-cyan-400" />
                      <span>My Profile</span>
                    </button>

                    <button
                      onClick={() => handleNavClick('settings')}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors"
                    >
                      <Settings className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Settings</span>
                    </button>

                    <button
                      onClick={() => {
                        setIsProfileMenuOpen(false);
                        openLogoutModal();
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors mt-1"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Logout</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Side Drawer for Mobile Navigation */}
      {isSideDrawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Overlay */}
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
            onClick={() => setIsSideDrawerOpen(false)}
          />

          {/* Drawer Menu */}
          <div className="relative w-72 max-w-[80vw] bg-slate-900 border-r border-slate-800 h-full flex flex-col p-4 shadow-2xl z-50">
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className={`w-9 h-9 rounded-xl ${accent.bgGradient} flex items-center justify-center font-bold text-slate-950`}>
                  🎓
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-100 leading-tight">AFMS Portal</h3>
                  <span className="text-[11px] text-slate-400">Parent Dashboard</span>
                </div>
              </div>
              <button
                onClick={() => setIsSideDrawerOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Nav list */}
            <nav className="flex-1 overflow-y-auto py-4 space-y-1">
              <p className="px-3 text-[10px] uppercase font-bold tracking-wider text-slate-500 mb-2">Navigation</p>
              {navItems.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                      isActive
                        ? `${accent.bgGradient} text-slate-950 font-bold shadow-md`
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {item.icon}
                      <span>{item.label}</span>
                    </div>

                    {item.badge !== undefined && item.badge > 0 && (
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                          isActive ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-cyan-400'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Footer Profile summary */}
            <div className="pt-4 border-t border-slate-800">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`w-8 h-8 rounded-full ${accent.bgGradient} flex items-center justify-center font-bold text-slate-950 text-xs shrink-0`}>
                    {parent.name.replace(/^Mr\.?|^Mrs\.?|^Ms\.?/i, '').trim().charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-100 truncate">{parent.name}</p>
                    <p className="text-[10px] text-slate-400 truncate">{student.name} ({student.division})</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setIsSideDrawerOpen(false);
                    openLogoutModal();
                  }}
                  className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
